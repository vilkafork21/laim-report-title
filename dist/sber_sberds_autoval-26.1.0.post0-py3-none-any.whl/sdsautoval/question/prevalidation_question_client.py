import abc
import json

from sdsautoval.base_requester import BaseRequester
from sdsautoval.utils.retry import withretry


class IPreValidationQuestionWebClient:
    @abc.abstractmethod
    def send_question(self, prevalidation_id, node_id, parameters: dict) -> dict:
        """
        Send question on server (POST /api/prevalidation/{preValidationId}/question)

        :param prevalidation_id prevalidation id
        :param node_id node id
        :param parameters: question body, e.g.
            {
              "nodeId": "uuid",
              "questionType": "INPUT",
              "questionKey": "1",
              "questionText": "What's up, doc?",
              "questionSelection": [
                "good", "bad"
              ],
              "timeout": 600
            }
        :return:
            {
                "questionRequestId": "3fa85f64-5717-4562-b3fc-2c963f66afa6"
            }
        """
        pass

    @abc.abstractmethod
    def send_answer(self, prevalidation_id, parameters: dict) -> dict:
        """
        Send answer on server (POST /api/prevalidation/{preValidationId}/answer)

        :param prevalidation_id prevalidation id
        :param parameters: question body, e.g.
            {
              "questionRequestId": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
              "answerText": "string"
            }
        :return:
            {
                "questionRequestId": "3fa85f64-5717-4562-b3fc-2c963f66afa6"
            }
        """
        pass

    @abc.abstractmethod
    def get_questions(self,  prevalidation_id, node_id, question_request_id) -> dict:
        """
        Get questions by filter (POST /api/prevalidation/{preValidationId}/question)

        :param prevalidation_id prevalidation id
        :param node_id node id
        :param question_request_id question id
        :return:
             [
                  {
                    "preValidationId": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
                    "nodeId": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
                    "questionRequestId": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
                    "questionKey": "string",
                    "alive": true,
                    "answered": true,
                    "answerText": "string"
                  }
            ]
        """
        pass


class PreValidationQuestionWebClient(IPreValidationQuestionWebClient):
    _SERVICE_PATH = 'template-selector'
    _END_POINT = '/api/prevalidation'

    def __init__(self, host, session, token, is_internal=False):
        self._requester = BaseRequester(host, session, service_name=self.__class__._SERVICE_PATH)
        self._is_internal = is_internal
        self._token = token

    @withretry()
    def send_question(self, prevalidation_id, parameters: dict) -> dict:
        end_point = f"{self._base_path()}/{prevalidation_id}/question"
        data = json.dumps(parameters)

        response = self._requester.request(
            method='post',
            endpoint=end_point,
            headers=self._headers(self._token),
            data=data
        )

        return response.json()

    @withretry()
    def send_answer(self, prevalidation_id, parameters: dict) -> dict:
        end_point = f"{self._base_path()}/{prevalidation_id}/answer"
        data = json.dumps(parameters)

        response = self._requester.request(
            method='post',
            endpoint=end_point,
            headers=self._headers(self._token),
            data=data
        )

        return response.json()

    @withretry()
    def get_questions(self, prevalidation_id, node_id, question_request_id=None) -> dict:
        end_point = f"{self._base_path()}/{prevalidation_id}/question?nodeId={node_id}"
        if question_request_id is not None:
            end_point += f"&questionRequestId={question_request_id}"

        response = self._requester.request(
            method='get',
            endpoint=end_point,
            headers=self._headers(self._token),
        )

        return response.json()

    def _base_path(self):
        return self._SERVICE_PATH + self._END_POINT if not self._is_internal else self._END_POINT

    @staticmethod
    def _headers(token):
        return {
            'Accept': 'application/json',
            'Authorization': f'Bearer {token}',
            'Content-Type': 'application/json'
        }
