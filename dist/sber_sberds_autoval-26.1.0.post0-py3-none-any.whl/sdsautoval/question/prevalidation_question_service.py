import json
from time import sleep

from .prevalidation_question_client import PreValidationQuestionWebClient


class PreValidationQuestionService:

    def __init__(self, host, session, token, is_internal=False):
        self._host = host
        self._session = session
        self._token = token
        self._client = PreValidationQuestionWebClient(host, session, token, is_internal)

    def send_question(self, prevalidation_id, node_id, q_key: str, q_type: str, q_text: str, q_selection: list, timeout=600):
        print(f"Send question: pv_id={prevalidation_id}, node_id={node_id}, key={q_key}, type={q_type}, text={q_text}, selection={q_selection}")
        body = {
                "nodeId": node_id,
                "questionType": q_type,
                "questionKey": q_key,
                "questionText": q_text,
                "questionSelection": q_selection,
                "timeout": timeout
            }

        json = self._client.send_question(prevalidation_id, body)
        return json.get("questionRequestId", None)

    def send_notification(self, prevalidation_id, node_id, q_key: str, q_text: str):
        print(f"Send notification: pv_id={prevalidation_id}, node_id={node_id}, key={q_key}, text={q_text}")
        body = {
            "nodeId": node_id,
            "questionType": 'NOTIFICATION',
            "questionKey": q_key,
            "questionText": q_text,
            "questionSelection": None,
            "timeout": 600
        }

        json = self._client.send_question(prevalidation_id, body)
        return json.get("questionRequestId", None)

    def send_answer(self, prevalidation_id, question_request_id, a_text: str):
        body = {
            "questionRequestId": question_request_id,
            "answerText": a_text
        }
        json = self._client.send_answer(prevalidation_id, body)
        return json.get("questionRequestId", None)

    def get_questions(self, prevalidation_id, node_id, question_request_id=None):
        return self._client.get_questions(prevalidation_id, node_id, question_request_id)

    def send_question_and_wait(self, prevalidation_id, node_id, q_key: str, q_type: str, q_text: str, q_selection: list, timeout=600):
        request_id = self.send_question(prevalidation_id, node_id, q_key, q_type, q_text, q_selection, timeout)
        print(f"question_request_id={request_id}. Waiting for answer...")
        while True:
            sleep(15)
            questions = self.get_questions(prevalidation_id, node_id, request_id)
            if questions is None or len(questions)==0:
                print(f"No data about question {request_id}, something went wrong!")
                return "error", None
            question = questions[0]
            if not question.get("alive", False):
                print("Got timeout on waiting answer!")
                return "timeout", None
            if question.get("answered", False):
                try:
                    text1 = json.loads(question.get("answerText", "{}")).get("answerText", "")
                    return "success", text1
                except:
                    return "bad_format", question.get("answerText", "")
