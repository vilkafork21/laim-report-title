import time
from datetime import datetime, timedelta

from .utils import DateTimeInterval
from ..context.constants import SBERDS_MAIL, AUTOVALIDATION_MAIL
from ..context.user_context import UserContext


class EventModel:
    """ Incident event model.

       Attributes:
           type         event type
           summary      event summary
           notification event text
           start_at     event start datetime
           end_at       event end datetime (nullable)
       """
    def __init__(self, type, summary, notification, start_at, end_at=None):
        self.type = type
        self.summary = summary
        self.notification = notification
        self.start_at = datetime.strptime(start_at, '%Y-%m-%dT%H:%M:%SZ')
        if end_at is not None:
            self.end_at = datetime.strptime(end_at, '%Y-%m-%dT%H:%M:%SZ')
        else:
            self.end_at = None

    def date_time_interval(self):
        return DateTimeInterval(self.start_at, self.end_at)

    def print_text(self, file=None):
        service_name = UserContext.get().job_name.get(1, capital=True, synonym_index=1)
        job_name = UserContext.get().job_name.get(0, plural=True, synonym_index=0)
        print(
            f'\nС {self._start_at_text()}{self._end_at_text()} на платформе SberDS {self._time_text()} {self.work_text()}, '
            f'приводящие к недоступности сервиса {service_name}.{self._end_at_text_add()}', file=file)
        print(f'В этот период новые {job_name} запускаться не будут, '
              f'а уже запущенные будут остановлены и дозапущены после завершения работ.', file=file)
        if self.summary is not None and len(self.summary) > 0 or \
                self.notification is not None and len(self.notification) > 0:
            print(f"Детали по работам:", file=file)
            if self.summary is not None and len(self.summary) > 0:
                print(f" описание: {self.summary}", file=file)
            if self.notification is not None and len(self.notification) > 0:
                print(f" уведомление для пользователей: {self.notification}", file=file)

    def work_text(self):
        if self.type == 'DEPLOYMENT':
            return "технические работы по обновлению SberDS"
        elif self.type == 'MAINTENANCE':
            return "технические работы на смежной инфраструктуре банка"
        elif self.type == 'UNAVAILABILITY':
            return "технические работы c частичной или полной недоступностью SberDS"
        else:
            return "технические работы"

    def _start_at_text(self):
        return self._get_as_local(self.start_at)

    def _end_at_text(self):
        if self.end_at is not None:
            return f" по {self._get_as_local(self.end_at)}"
        else:
            return ""

    def _end_at_text_add(self):
        if self.end_at is not None:
            return ""
        else:
            return f" Срок работ пока не определен. Подробности можно узнать в поддержке: {SBERDS_MAIL} или {AUTOVALIDATION_MAIL}"

    def _time_text(self):
        if self.start_at <= datetime.utcnow():
            return "проводятся"
        else:
            return "будут проводиться"

    @staticmethod
    def _get_as_local(utc):
        epoch = time.mktime(utc.timetuple())
        offset = datetime.fromtimestamp(epoch) - datetime.utcfromtimestamp(epoch)
        return utc + offset

    def is_happening_at(self, date=datetime.utcnow(),
                        interval_before=timedelta(days=0,
                                                  seconds=0,
                                                  microseconds=0,
                                                  milliseconds=0,
                                                  minutes=0,
                                                  hours=0,
                                                  weeks=0),
                        interval_after=timedelta(days=0,
                                                 seconds=0,
                                                 microseconds=0,
                                                 milliseconds=0,
                                                 minutes=0,
                                                 hours=0,
                                                 weeks=0)):
        return self.is_happening_between(date - interval_before, date + interval_after)

    def is_happening_between(self, start_date, end_date):
        return self.date_time_interval().overlaps(DateTimeInterval(start_date, end_date))

    def _is_happening_at_fixed_date(self, date):
        if self.end_at is not None:
            return self.start_at <= date <= self.end_at
        else:
            return date >= self.start_at
