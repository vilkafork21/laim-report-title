from ..base_requester import BaseRequester
from ..utils.retry import withretry


class IEventWebClient:
    def get_all(self):
        """
        Get all active incident events (GET /api/events)

        :return: events list
        """
        pass

    def get_by_method(self, method_id):
        """
        Get active incident events related to method (GET /api/events/method/{method_id})

        :param method_id method id
        :return: events list
        """
        pass

    def get_by_prevalidation(self, prevalidation_id):
        """
        Get active incident events related to prevalidation (GET /api/events/preValidation/{prevalidation_id})

        :param prevalidation_id prevalidation id
        :return: events list
        """
        pass


class EventWebClient(IEventWebClient):
    _SERVICE_PATH = 'template-selector'
    _END_POINT = '/api/events'

    def __init__(self, host, session, token, is_internal=False):
        self._requester = BaseRequester(host, session, service_name='incident-service')
        self._is_internal = is_internal
        self._token = token

    @withretry()
    def get_all(self):
        response = self._requester.request(
            method='get',
            endpoint=f"{self._base_path()}",
            headers=self._headers(self._token)
        )

        return response.json()

    @withretry()
    def get_by_method(self, method_id):
        response = self._requester.request(
            method='get',
            endpoint=f"{self._base_path()}/method/{method_id}",
            headers=self._headers(self._token)
        )

        return response.json()

    @withretry()
    def get_by_prevalidation(self, prevalidation_id):
        response = self._requester.request(
            method='get',
            endpoint=f"{self._base_path()}/preValidation/{prevalidation_id}",
            headers=self._headers(self._token)
        )

        return response.json()

    def _base_path(self):
        return self._SERVICE_PATH + self._END_POINT if not self._is_internal else self._END_POINT

    @staticmethod
    def _headers(token):
        return {
            'Authorization': f'Bearer {token}',
        }
