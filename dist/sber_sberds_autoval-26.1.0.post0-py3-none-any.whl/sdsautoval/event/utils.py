from datetime import datetime


class DateTimeInterval:
    def __init__(self, start_at: datetime = None, end_at: datetime = None):
        if start_at is None:
            start_at = datetime.min
        if end_at is None:
            end_at = datetime.max
        self.start_at = start_at
        self.end_at = end_at

    def overlaps(self, other):
        latest_start = max(self.start_at, other.start_at)
        earliest_end = min(self.end_at, other.end_at)
        return latest_start <= earliest_end


