from datetime import datetime, timedelta

from sdsautoval.context.constants import SBERDS_MAIL
from .event_model import EventModel
from .event_web_client import EventWebClient


class EventService:

    def __init__(self, host, session, token, is_internal=False):
        self._host = host
        self._session = session
        self._token = token
        self._last_request_time = None
        self._last_request_time_internal = datetime.min
        self._is_internal = is_internal

        self._client = EventWebClient(host, session, token, is_internal)

    def should_abort_by_method(self, method_id, interval_before=timedelta(minutes=5),
                               interval_after=timedelta(minutes=5)) -> (bool, [EventModel]):
        if self.early_to_request(self._last_request_time_internal, delay=timedelta(minutes=1)):
            return False, []
        events = self.get_sorted_events_by_method_id(method_id, force=True)
        self._last_request_time_internal = datetime.now()
        should_abort = False
        cause_events = []
        for event in events:
            should_abort_because_of_event = event.is_happening_at(interval_before=interval_before,
                                                                  interval_after=interval_after)
            should_abort = should_abort or should_abort_because_of_event
            if should_abort_because_of_event:
                cause_events.append(event)
        return should_abort, cause_events

    def print_all(self):
        if self.early_to_request():
            return
        self._call_print_events(self._client.get_all())

    def print_by_method(self, method_id):
        if self.early_to_request():
            return
        self._call_print_events(self._client.get_by_method(method_id))

    def print_by_prevalidation(self, prevalidation_id):
        if self.early_to_request():
            return
        self._call_print_events(self._client.get_by_prevalidation(prevalidation_id))

    def _call_print_events(self, func) -> []:

        if self.early_to_request():
            return

        sorted_events = self.get_sorted_events_by_getter(func)
        self.print_events_list(sorted_events)

        self._last_request_time = datetime.now()

    # noinspection PyMethodMayBeStatic
    def print_events_list(self, sorted_events: [EventModel], file=None):
        if len(sorted_events) > 0:
            for event in sorted_events:
                event.print_text(file=file)
            print(f"\nЕсли вы не получаете рассылку о технических работах, но хотите получать, "
                  f"то напишите на почту {SBERDS_MAIL}\n", file=file)

    def get_sorted_events_by_getter(self, func, force=False):
        events = []
        if self.early_to_request() and not force:
            return events
        sorted_events = sorted(func, key=lambda d: d['start_at'])
        if len(sorted_events) > 0:
            for sorted_event in sorted_events:
                events.append(EventService.convert_response(sorted_event))
        return events

    def early_to_request(self, last_request_time=None, delay=timedelta(minutes=5)) -> bool:
        if self._is_internal:
            return True
        if last_request_time is None:
            last_request_time = self._last_request_time
        if last_request_time is None:
            return False
        return last_request_time + delay >= datetime.now()

    def get_all_sorted_events(self, force=False):
        return self.get_sorted_events_by_getter(self._client.get_all(), force=force)

    def get_sorted_events_by_prevalidation(self, prevalidation_id, force=False):
        return self.get_sorted_events_by_getter(self._client.get_by_prevalidation(prevalidation_id), force=force)

    def get_sorted_events_by_method_id(self, method_id, force=False) -> [EventModel]:
        return self.get_sorted_events_by_getter(self._client.get_by_method(method_id), force=force)

    @staticmethod
    def convert_response(response) -> EventModel:
        return EventModel(
            type=response['type'],
            summary=response['summary'],
            notification=response['notification'],
            start_at=response['start_at'],
            end_at=response.get('end_at', None))
