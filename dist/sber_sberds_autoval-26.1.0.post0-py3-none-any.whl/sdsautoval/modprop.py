from urllib.parse import urlparse

from sdsautoval.context.user_context import UserContext
from .exceptions.exception_decorator import exception_logger
from .exceptions.sds_exceptions import SdsParamValidationError, \
    SdsExceptionLogPrinter, SdsDatasourceDescriptionError
from .file_upload import CsvUploader, UserSession
from .utils.collections import invert_dict
from .utils.correction import Corrector
from .utils.exception import Validatable
from .utils.fuzzy_dict import fuzzy_dict


class ConnectionPreprocessor:
    # noinspection PyMethodMayBeStatic
    def apply(self, connection, file):
        return connection


class ConnectionPreprocessorEngine:
    def __init__(self):
        self.connection_preprocessors = set()

    @staticmethod
    def instance():
        return ConnectionPreprocessorEngine_INSTANCE

    def register(self, connection_preprocessor: ConnectionPreprocessor):
        self.connection_preprocessors.add(connection_preprocessor)

    def preprocess_connection(self, connection, file):
        for connection_preprocessor in self.connection_preprocessors:
            connection = connection_preprocessor.apply(connection, file)
        return connection


ConnectionPreprocessorEngine_INSTANCE = ConnectionPreprocessorEngine()


class ModelConstants:
    metric_gini = "Gini"
    metric_mae = "MAE"
    metric_precision = "Precision"
    metric_r2 = "R2"
    metric_mape = "MAPE"
    metric_f1_macro = "F1 macro"
    metrics = [metric_gini, metric_mae, metric_precision, metric_r2,
               metric_mape, metric_f1_macro]

    tasktype_binary = "Бинарная классификация"
    tasktype_temp = "Временные ряды"
    tasktype_regress = "Регрессия"
    tasktype_multi_class = "Многоклассовая классификация"
    tasktypes = [tasktype_binary, tasktype_temp, tasktype_regress,
                 tasktype_multi_class]

    markuproles_dict = fuzzy_dict({
        # general
        'EXCLUDED': 'Excluded',
        "excluded": "Excluded",
        "input": "Input",
        "target": "Target",
        "score": "Score",
        "weight": "Weight",
        "predicted_class": "Predicted Class",
        "text": "Text",
        "treatment": "Treatment",
        "control": "Control",
        "uplift": "Uplift",
        # model risk
        "reject_sf_flag": "Reject SF Flag",
        "c": "C",
        "rc": "RC",
        "npv": "NPV",
        "loan_rate": "Loan rate",
        "commission_rate": "Commission Rate",
        "capital_rate": "Capital Rate",
        "k_discount": "K Discount",
        "zone": "Zone",
        "sum_request": "Sum Request",
        "mr1": "MR1",
        "mr2": "MR2",
        "mr3": "MR3",
        "mr4": "MR4",
        "mr5": "MR5",
        # validation
        "id": "ID",
        "embedding": "Embedding",
        "baseline": "Baseline",
        "group": "Group",
        "pd": "PD",
        "rating": "Rating",
        "date": "Date",
        "sample": "Sample",
        "other": "Other",
        "scored_factor": "Scored Factor",
        "raw_factor": "Raw Factor",
        "calibration_weight": "Calibration Weight"
    })


    markuproles_dict_inverted = fuzzy_dict(invert_dict(markuproles_dict))

    markuptypes_dict = fuzzy_dict({
        "interval": "Interval",
        "nominal": "Nominal",
        "time": "Time",
        "auto": "Auto"
    })

    markuptypes_dict_inverted = fuzzy_dict(invert_dict(markuptypes_dict))

    datatype_structured = "Структурированные данные"
    datatypes = [datatype_structured]

    fb_subject_auto_validation = "AutoValidation"
    fb_subject_ab_testing = 'AB_Testing'
    fb_subject_auto_model = "Auto_Model"
    fb_subjects = [fb_subject_auto_validation, fb_subject_ab_testing, fb_subject_auto_model]

    visual_allowed_host_list = ['arnsdpldbr2', 'arnsdpsbx']
    allowed_host_list = visual_allowed_host_list + [
        'SDP-19115654-ipa-sds-dev-sdp-hadoop-452fae',
        'SDP-19115654-ipa-sds-ift-sdp-hadoop-1-0cd162',
        'SDP-01535693-omega-sbrf-ru-sds-de-sdp-prom-644923',
        'SDP-19115654-ipa-sds-lt-sdp-hadoop-1-29757a',
        'hdfsgw',
        'devsdpsbx',
        'arnsdpsdsre',
        # PSI
        'SDP-sidorova5-nv-PSI-74a0e8',
        'clsklsbxpsi',
        'supermarket',
        'clatsklod',
        'atdisdpcap',
        'atdisdpsmd',
        'atdisdprozn'
    ]


class DataConnection(Validatable):
    """ Настройка источника данных в ЛД 3.0 (hive) или разделяемом хранилище (hdfs)

    Указанные параметры используются при конфигурировании нод Data Source.
    В ноду Data Source будет добавлен источник данных.

    Функция DataConnection используется перед вызовом функций DataSample и DataArtifact

    Текущие ограничения функции:
    Источник данных должен быть в ЛД 3.0 (hive) или разделяемом хранилище (hdfs)


    Parameters
    ----------
    host : str
        host источника данных. Для ЛД 3.0 имя хоста для hive. Для разделяемого
        хранилища допустимые значения arnsdpldbr2 или arnsdpsbx.

    port : str, optional
        port источника данных, используется для конфигурирования ноды Data Source.
        Указывается только для соединений типа hive.

    schema : str, optional
        schema источника данных, используется для конфигурирования ноды Data Source.
        Указывается только для соединений типа hive.


    Examples
    --------
    # Настройка разметки колонок для структурированных данных
        columns = ColumnsSelector(default_type="auto", default_role="input")
        columns.excluded(['id','ap_lo','ap_hi'])
        columns.score('predicted_prob_cardio')
        columns.target('cardio')
        columns.scored_factor(['weight','height','smoke'])
        columns.add(['alco','gluc','cholesterol'], role='raw_factor')

    # Настройка подключения источника данных
        data_source=DataConnection(host='tkle-mvp1133.vm.esrt.cloud.sbrf.ru', schema='sdsdh_validationmanag')
        hdfs_source=DataConnection(host='arnsdpldbr2')

        data=[
                DataSample(key="train", sql='heart_dis_predicted_train', selector=columns, connection=data_source),
                DataSample(key="out_of_sample", sql='heart_dis_predicted_oos', selector=columns, connection=data_source),
                DataSample(key="out_of_time", file='/data/my_sources/heart_disease.parquet', selector=columns, connection=hdfs_source),
                DataArtifact(key="model", file='/data/lib/sds/risk/validationmanag/pkl_test/test_path_1.pkl', connection=hdfs_source)
                ]

    """

    def __init__(self, host: str = None, schema: str = None, port: int = 10000):
        super().__init__()
        self.host = host
        self.port = port
        self.schema = schema

    # todo: перенести в DataSample
    def to_dict(self):
        return {
            "host": self.host,
            "port": self.port,
            "schemaName": self.schema,
        }

    def get_csv_file_data(self):
        return None

    def validate(self):
        super().validate()
        if not self.host:
            self.raise_and_store(SdsParamValidationError('DataConnection.host',
                                                         f"datasource.host должен быть заполнен"))
        if not self.port:
            self.raise_and_store(SdsParamValidationError('DataConnection.port',
                                                         f"datasource.port должен быть заполнен"))

    def prepare(self, user_session: UserSession, method=None, event_service=None):
        # Nothing to prepare by default.
        pass

    def __repr__(self):
        return self.__str__()

    def __str__(self):
        return self.__class__.__name__ + ' ' + self.to_dict().__str__()


def remove_prefix(text, prefix):
    if text and text.startswith(prefix):
        return text[len(prefix):]
    return text


class OuterDataConnection(DataConnection):
    class OuterDataConnectionPreprocessorFileOnly(ConnectionPreprocessor):
        MLS_HOSTS = ['s3.mls.ift.delta.sbrf.ru', 's3.mls.iaz.omega.sbrf.ru']

        def apply(self, connection, file):
            try:
                if connection is None:
                    parsed_url = urlparse(file)
                    if parsed_url.scheme == 'http' or parsed_url.scheme == 'https':
                        if parsed_url.netloc in self.__class__.MLS_HOSTS:
                            if parsed_url.path.startswith('/s3/'):
                                parsed_host = parsed_url.netloc
                                parsed_file = parsed_url.path[len('/s3/'):]
                                return FilledOuterDataConnection(parsed_host, parsed_file)
            except Exception:
                return connection
            return connection

    ConnectionPreprocessorEngine.instance().register(OuterDataConnectionPreprocessorFileOnly())

    class OuterDataConnectionPreprocessor(ConnectionPreprocessor):
        def apply(self, connection, file):
            if isinstance(connection, OuterDataConnection):
                connection = FilledOuterDataConnection(connection.host, file)
            return connection

    ConnectionPreprocessorEngine.instance().register(OuterDataConnectionPreprocessor())

    def __init__(self, host: str):
        super().__init__(host)
        self.port = None

    def validate(self):
        if not self.host:
            raise SdsParamValidationError('DataConnection.host',
                                          f"datasource.host должен быть заполнен")

    def to_dict(self):
        return {
            "host": self.host
        }


class FilledOuterDataConnection(DataConnection):
    def __init__(self, host: str, artifact_absolute_path: str):
        super().__init__(host)
        self.artifact_absolute_path = artifact_absolute_path
        self.port = None

    def validate(self):
        if not self.host:
            raise SdsParamValidationError('DataConnection.host',
                                          f"datasource.host должен быть заполнен")
        if not self.artifact_absolute_path:
            raise SdsParamValidationError('DataConnection.artifact_absolute_path',
                                          f"datasource.artifact_absolute_path должен быть заполнен")

    def to_dict(self):
        return {
            "host": self.host,
            "artifactAbsolutePath": self.artifact_absolute_path
        }

class LocalDataConnection(DataConnection):
    def __init__(self, file):
        super().__init__(None, 'file', 0)
        self.csv_uploader = None
        self.file = file
        self.upload_file_result = None
        self.file = remove_prefix(self.file, 'file:\\\\')
        self.file = remove_prefix(self.file, 'file:\\')
        self.file = remove_prefix(self.file, 'file://')
        self.file = remove_prefix(self.file, 'file:/')
        self.file = remove_prefix(self.file, 'file:')

    def validate(self):
        # suppressing parent class validation
        pass

    def prepare(self, user_session: UserSession, method=None, event_service=None):
        # Uploading the file
        self.csv_uploader = CsvUploader(user_session,
                                        '00000000-0000-0000-0000-00000000000',
                                        '00000000-0000-0000-0000-00000000000',
                                        method=method,event_service=event_service)
        self.upload_file_result = self.csv_uploader.upload_file(file=self.file,
                                                                file_folder='_temp_av')

    def get_csv_file_data(self):
        return self.upload_file_result


class LocalFileConnection(LocalDataConnection):
    def __init__(self, file):
        super().__init__(file)


class RoleAndType(Validatable):
    """ RoleAndType model.

    Parameters
    ----------
    role: str, роль колонки

    type: str, тип колонки
    """

    def __init__(self, role: str = "input", type: str = "interval"):
        super().__init__()
        self.original_role = role
        self.original_type = type
        self.role = correct_role(role)
        self.type = correct_type(type)

    def __str__(self):
        return str({'role': self.role, 'type': self.type})

    def get_role(self):
        if self.role is None:
            return None
        return ModelConstants.markuproles_dict.get(self.role.lower(), self.role)

    def get_type(self):
        if self.type is None:
            return None
        return ModelConstants.markuptypes_dict.get(self.type.lower(), self.type)

    def validate(self):
        super().validate()
        if not self.role:
            self.raise_and_store(SdsParamValidationError('ColumnsSelector.role',
                                                         f"role должен быть заполнен"))
        if not self.type:
            self.raise_and_store(SdsParamValidationError('ColumnsSelector.type',
                                                         f"type должен быть заполнен"))


class ColumnsSelector(Validatable):
    """ Дефолтная разметка колонок датасета.

    Указанные параметры используются при конфигурировании нод Data Profiling в SberDS.
    К каждой колонке датасета применяются правила указанные в параметрах функции
    default_role (по умолчанию input) и default_type (по умолчанию auto).


    Parameters
    ----------
    default_role : str
        роль колонки, используется для конфигурирования ноды Data Profiling.
        допустимые варианты: ['excluded', 'input', 'target', 'score', 'weight', 'predicted_class', 'text', 'treatment', 'control', 'uplift', 'reject_sf_flag', 'c', 'rc', 'npv', 'loan_rate', 'commission_rate', 'capital_rate', 'k_discount', 'zone', 'sum_request', 'mr1',      'mr2', 'mr3', 'mr4', 'mr5', 'pd', 'rating', 'date', 'sample', 'other', 'scored_factor', 'raw_factor', 'calibration_weight', 'id', 'group', 'embedding', 'baseline']

    default_type : str
        тип колонки, используется для конфигурирования ноды Data Profiling.
        допустимые варианты: ['interval', 'nominal', 'time', 'auto']


    Returns
    -------
    sdsautoval.modprop.ColumnsSelector object
        функция добавляет разметку по умолчанию для обьекта, который необходимо передать в параметр "selector" функции "DataSample"


    Examples
    --------
    # Настройка разметки колонок
        columns = ColumnsSelector(default_type="auto", default_role="input")
        columns.excluded(['id','ap_lo','ap_hi'])
        columns.score('predicted_prob_cardio')
        columns.target('cardio')
        columns.scored_factor(['weight','height','smoke'])
        columns.add(['alco','gluc','cholesterol'], role='raw_factor')

    """

    def __init__(self, default_role: str = "input", default_type: str = "auto"):
        super().__init__()
        self.original_defaultRole = default_role
        self.original_defaultType = default_type
        self.defaultRole = correct_role(default_role)
        self.defaultType = correct_type(default_type)
        self.rolesAndTypes = {}

    def get_default_role(self):
        return ModelConstants.markuproles_dict.get(self.defaultRole.lower())

    def get_default_type(self):
        return ModelConstants.markuptypes_dict.get(self.defaultType)

    def add(self, columns=None, role=None, column_type=None):
        """ Назначение разметки для колонки/колонок.

        Указанные параметры используются при конфигурировании нод Data Profiling в SberDS.


        Parameters
        ----------
        columns : str или list
            колонка или список колонок датасета, используется для конфигурирования ноды Data Profiling.

        role : str
            роль колонки/колонок, используется для конфигурирования ноды Data Profiling.
            допустимые варианты: ['excluded', 'input', 'target', 'score', 'weight', 'predicted_class', 'text', 'treatment', 'control', 'uplift', 'reject_sf_flag', 'c', 'rc', 'npv', 'loan_rate', 'commission_rate', 'capital_rate', 'k_discount', 'zone', 'sum_request', 'mr1',      'mr2', 'mr3', 'mr4', 'mr5', 'pd', 'rating', 'date', 'sample', 'other', 'scored_factor', 'raw_factor', 'calibration_weight', 'id', 'group', 'embedding', 'baseline']

        column_type : str
            тип колонки/колонок, используется для конфигурирования ноды Data Profiling.
            допустимые варианты: ['interval', 'nominal', 'time', 'auto']


        Returns
        -------
        sdsautoval.modprop.ColumnsSelector object
        метод добавляет разметку в обьект, который необходимо передать в параметр "selector" функции "DataSample"


        Examples
        --------
        # Настройка разметки колонок для Samples
            columns = ColumnsSelector(default_type="auto", default_role="input")
            columns.excluded(['id','ap_lo','ap_hi'])
            columns.score('predicted_prob_cardio')
            columns.target('cardio')
            columns.scored_factor(['weight','height','smoke'])
            columns.add(['alco','gluc','cholesterol'], role='raw_factor',column_type='interval')

        # Настройка подключения источника данных
            data_source=DataConnection(host='tkle-mvp1133.vm.esrt.cloud.sbrf.ru', schema='sdsdh_validationmanag')
            samples=[
                    DataSample(sample_type="train", sql='heart_dis_predicted_train', selector=columns, connection=data_source),
                    DataSample(sample_type="out_of_sample", sql='heart_dis_predicted_oos', selector=columns, connection=data_source),
                    DataSample(sample_type="out_of_time", sql='heart_dis_predicted_oot', selector=columns, connection=data_source)
                    ]

        """
        if isinstance(columns, list):
            if len(columns) > 0:
                for column_name in columns:
                    self.__add(column_name, role, column_type)
            else:
                ex = SdsParamValidationError('role/column_type',
                                             f'в списке нужно передать хотя бы одну колонку')
                SdsExceptionLogPrinter().print(ex)
                self.raise_and_store(ex)
        else:
            self.__add(columns, role, column_type)

        return self

    @exception_logger(logger=SdsExceptionLogPrinter())
    def __add(self, column_name: str, role=None, column_type=None):
        if role is None and column_type is None:
            self.store(SdsParamValidationError('role/column_type',
                                                         f'role and column_type одновременно равны None для {column_name}'))
        old = self.rolesAndTypes.get(column_name)
        if old is not None:
            self.store(SdsParamValidationError('role/column_type',
                                                         f'колонка уже заполнена {column_name} = {old}'))

        role = role if role is not None else self.defaultRole
        column_type = column_type if column_type is not None else self.defaultType
        self.rolesAndTypes[column_name] = RoleAndType(role, column_type)
        return self

    def excluded(self, columns=None, column_type='auto'):
        """ Назначение разметки для колонки/колонок.

        Аналог метода add.
        Метод размечает колонки: role = 'excluded', column_type = 'auto'
        excluded - это поля, которые нельзя использовать для построения модели.

        Указанные параметры используются при конфигурировании нод Data Profiling в SberDS.

        Parameters
        ----------
        columns : str или list
            колонка или список колонок датасета, используется для конфигурирования ноды Data Profiling.

        column_type : str
            тип колонки/колонок, используется для конфигурирования ноды Data Profiling.
            допустимые варианты: ['interval', 'nominal', 'time', 'auto'], по умолчанию - 'auto'

        Returns
        -------
        sdsautoval.modprop.ColumnsSelector object
        метод добавляет разметку в обьект, который необходимо передать в параметр "selector" функции "DataSample"


        Examples
        --------
        columns.excluded(['column1','column2','column3'])
        columns.excluded('column')
        """
        return self.add(columns=columns, role='excluded',
                        column_type=column_type)

    def target(self, columns=None, column_type='auto'):
        """ Назначение разметки для колонки/колонок.

        Аналог метода add.
        Метод размечает колонки: role = 'target', column_type = 'auto'
        target - это целевая переменная (бинарная).

        Указанные параметры используются при конфигурировании нод Data Profiling в SberDS.

        Parameters
        ----------
        columns : str или list
            колонка или список колонок датасета, используется для конфигурирования ноды Data Profiling.

        column_type : str
            тип колонки/колонок, используется для конфигурирования ноды Data Profiling.
            допустимые варианты: ['interval', 'nominal', 'time', 'auto'], по умолчанию - 'auto'

        Returns
        -------
        sdsautoval.modprop.ColumnsSelector object
        метод добавляет разметку в обьект, который необходимо передать в параметр "selector" функции "DataSample"


        Examples
        --------
        columns.target('column')
        """
        return self.add(columns=columns, role='target', column_type=column_type)

    def input(self, columns=None, column_type='auto'):
        """ Назначение разметки для колонки/колонок.

        Аналог метода add.
        Метод размечает колонки: role = 'input', column_type = 'auto'
        input - это короткий список факторов.

        Указанные параметры используются при конфигурировании нод Data Profiling в SberDS.

        Parameters
        ----------
        columns : str или list
            колонка или список колонок датасета, используется для конфигурирования ноды Data Profiling.

        column_type : str
            тип колонки/колонок, используется для конфигурирования ноды Data Profiling.
            допустимые варианты: ['interval', 'nominal', 'time', 'auto'], по умолчанию - 'auto'

        Returns
        -------
        sdsautoval.modprop.ColumnsSelector object
        метод добавляет разметку в обьект, который необходимо передать в параметр "selector" функции "DataSample"


        Examples
        --------
        columns.input(['column1','column2','column3'])
        columns.input('column')
        """
        return self.add(columns=columns, role='input', column_type=column_type)

    def score(self, columns=None, column_type='auto'):
        """ Назначение разметки для колонки/колонок.

        Аналог метода add.
        Метод размечает колонки: role = 'score', column_type = 'auto'
        score - это прогноз модели.

        Указанные параметры используются при конфигурировании нод Data Profiling в SberDS.

        Parameters
        ----------
        columns : str или list
            колонка или список колонок датасета, используется для конфигурирования ноды Data Profiling.

        column_type : str
            тип колонки/колонок, используется для конфигурирования ноды Data Profiling.
            допустимые варианты: ['interval', 'nominal', 'time', 'auto'], по умолчанию - 'auto'

        Returns
        -------
        sdsautoval.modprop.ColumnsSelector object
        метод добавляет разметку в обьект, который необходимо передать в параметр "selector" функции "DataSample"


        Examples
        --------
        columns.score('column')
        """
        return self.add(columns=columns, role='score', column_type=column_type)

    def weight(self, columns=None, column_type='auto'):
        """ Назначение разметки для колонки/колонок.

        Аналог метода add.
        Метод размечает колонки: role = 'weight', column_type = 'auto'

        Указанные параметры используются при конфигурировании нод Data Profiling в SberDS.

        Parameters
        ----------
        columns : str или list
            колонка или список колонок датасета, используется для конфигурирования ноды Data Profiling.

        column_type : str
            тип колонки/колонок, используется для конфигурирования ноды Data Profiling.
            допустимые варианты: ['interval', 'nominal', 'time', 'auto'], по умолчанию - 'auto'

        Returns
        -------
        sdsautoval.modprop.ColumnsSelector object
        метод добавляет разметку в обьект, который необходимо передать в параметр "selector" функции "DataSample"


        Examples
        --------
        columns.weight(['column1','column2','column3'])
        columns.weight('column')
        """
        return self.add(columns=columns, role='weight', column_type=column_type)

    def predicted_class(self, columns=None, column_type='auto'):
        """ Назначение разметки для колонки/колонок.

        Аналог метода add.
        Метод размечает колонки: role = 'predicted_class', column_type = 'auto'
        predicted_class - это длинный список факторов.

        Указанные параметры используются при конфигурировании нод Data Profiling в SberDS.

        Parameters
        ----------
        columns : str или list
            колонка или список колонок датасета, используется для конфигурирования ноды Data Profiling.

        column_type : str
            тип колонки/колонок, используется для конфигурирования ноды Data Profiling.
            допустимые варианты: ['interval', 'nominal', 'time', 'auto'], по умолчанию - 'auto'

        Returns
        -------
        sdsautoval.modprop.ColumnsSelector object
        метод добавляет разметку в обьект, который необходимо передать в параметр "selector" функции "DataSample"


        Examples
        --------
        columns.predicted_class(['column1','column2','column3'])
        columns.predicted_class('column')
        """
        return self.add(columns=columns, role='predicted_class',
                        column_type=column_type)

    def rating(self, columns=None, column_type='auto'):
        """ Назначение разметки для колонки/колонок.

        Аналог метода add.
        Метод размечает колонки: role = 'rating', column_type = 'auto'

        Указанные параметры используются при конфигурировании нод Data Profiling в SberDS.

        Parameters
        ----------
        columns : str или list
            колонка или список колонок датасета, используется для конфигурирования ноды Data Profiling.

        column_type : str
            тип колонки/колонок, используется для конфигурирования ноды Data Profiling.
            допустимые варианты: ['interval', 'nominal', 'time', 'auto'], по умолчанию - 'auto'

        Returns
        -------
        sdsautoval.modprop.ColumnsSelector object
        метод добавляет разметку в обьект, который необходимо передать в параметр "selector" функции "DataSample"


        Examples
        --------
        columns.rating(['column1','column2','column3'])
        columns.rating('column')
        """
        return self.add(columns=columns, role='rating', column_type=column_type)

    def date(self, columns=None, column_type='auto'):
        """ Назначение разметки для колонки/колонок.

        Аналог метода add.
        Метод размечает колонки: role = 'date', column_type = 'auto'

        Указанные параметры используются при конфигурировании нод Data Profiling в SberDS.

        Parameters
        ----------
        columns : str или list
            колонка или список колонок датасета, используется для конфигурирования ноды Data Profiling.

        column_type : str
            тип колонки/колонок, используется для конфигурирования ноды Data Profiling.
            допустимые варианты: ['interval', 'nominal', 'time', 'auto'], по умолчанию - 'auto'

        Returns
        -------
        sdsautoval.modprop.ColumnsSelector object
        метод добавляет разметку в обьект, который необходимо передать в параметр "selector" функции "DataSample"


        Examples
        --------
        columns.date(['column1','column2','column3'])
        columns.date('column')
        """
        return self.add(columns=columns, role='date', column_type=column_type)

    def sample(self, columns=None, column_type='auto'):
        """ Назначение разметки для колонки/колонок.

        Аналог метода add.
        Метод размечает колонки: role = 'sample', column_type = 'auto'
        sample - это категориальные переменные для длинного списка факторов

        Указанные параметры используются при конфигурировании нод Data Profiling в SberDS.

        Parameters
        ----------
        columns : str или list
            колонка или список колонок датасета, используется для конфигурирования ноды Data Profiling.

        column_type : str
            тип колонки/колонок, используется для конфигурирования ноды Data Profiling.
            допустимые варианты: ['interval', 'nominal', 'time', 'auto'], по умолчанию - 'auto'

        Returns
        -------
        sdsautoval.modprop.ColumnsSelector object
        метод добавляет разметку в обьект, который необходимо передать в параметр "selector" функции "DataSample"


        Examples
        --------
        columns.sample(['column1','column2','column3'])
        columns.sample('column')
        """
        return self.add(columns=columns, role='sample', column_type=column_type)

    def other(self, columns=None, column_type='auto'):
        """ Назначение разметки для колонки/колонок.

        Аналог метода add.
        Метод размечает колонки: role = 'other', column_type = 'auto'
        other - это ключ

        Указанные параметры используются при конфигурировании нод Data Profiling в SberDS.

        Parameters
        ----------
        columns : str или list
            колонка или список колонок датасета, используется для конфигурирования ноды Data Profiling.

        column_type : str
            тип колонки/колонок, используется для конфигурирования ноды Data Profiling.
            допустимые варианты: ['interval', 'nominal', 'time', 'auto'], по умолчанию - 'auto'

        Returns
        -------
        sdsautoval.modprop.ColumnsSelector object
        метод добавляет разметку в обьект, который необходимо передать в параметр "selector" функции "DataSample"


        Examples
        --------
        columns.other('column')
        """
        return self.add(columns=columns, role='other', column_type=column_type)

    def scored_factor(self, columns=None, column_type='auto'):
        """ Назначение разметки для колонки/колонок.

        Аналог метода add.
        Метод размечает колонки: role = 'scored_factor', column_type = 'auto'
        scored_factor - это длинный список факторов

        Указанные параметры используются при конфигурировании нод Data Profiling в SberDS.

        Parameters
        ----------
        columns : str или list
            колонка или список колонок датасета, используется для конфигурирования ноды Data Profiling.

        column_type : str
            тип колонки/колонок, используется для конфигурирования ноды Data Profiling.
            допустимые варианты: ['interval', 'nominal', 'time', 'auto'], по умолчанию - 'auto'

        Returns
        -------
        sdsautoval.modprop.ColumnsSelector object
        метод добавляет разметку в обьект, который необходимо передать в параметр "selector" функции "DataSample"


        Examples
        --------
        columns.scored_factor(['column1','column2','column3'])
        columns.scored_factor('column')
        """
        return self.add(columns=columns, role='scored_factor',
                        column_type=column_type)

    def raw_factor(self, columns=None, column_type='auto'):
        """ Назначение разметки для колонки/колонок.

        Аналог метода add.
        Метод размечает колонки: role = 'raw_factor', column_type = 'auto'
        raw_factor - это категориальные переменные для короткого списка факторов

        Указанные параметры используются при конфигурировании нод Data Profiling в SberDS.

        Parameters
        ----------
        columns : str или list
            колонка или список колонок датасета, используется для конфигурирования ноды Data Profiling.

        column_type : str
            тип колонки/колонок, используется для конфигурирования ноды Data Profiling.
            допустимые варианты: ['interval', 'nominal', 'time', 'auto'], по умолчанию - 'auto'

        Returns
        -------
        sdsautoval.modprop.ColumnsSelector object
        метод добавляет разметку в обьект, который необходимо передать в параметр "selector" функции "DataSample"


        Examples
        --------
        columns.raw_factor(['column1','column2','column3'])
        columns.raw_factor('column')
        """
        return self.add(columns=columns, role='raw_factor',
                        column_type=column_type)

    def calibration_weight(self, columns=None, column_type='auto'):
        """ Назначение разметки для колонки/колонок.

        Аналог метода add.
        Метод размечает колонки: role = 'calibration_weight', column_type = 'auto'

        Указанные параметры используются при конфигурировании нод Data Profiling в SberDS.

        Parameters
        ----------
        columns : str или list
            колонка или список колонок датасета, используется для конфигурирования ноды Data Profiling.

        column_type : str
            тип колонки/колонок, используется для конфигурирования ноды Data Profiling.
            допустимые варианты: ['interval', 'nominal', 'time', 'auto'], по умолчанию - 'auto'

        Returns
        -------
        sdsautoval.modprop.ColumnsSelector object
        метод добавляет разметку в обьект, который необходимо передать в параметр "selector" функции "DataSample"


        Examples
        --------
        columns.calibration_weight(['column1','column2','column3'])
        columns.calibration_weight('column')
        """
        return self.add(columns=columns, role='calibration_weight',
                        column_type=column_type)

    def pd(self, columns=None, column_type='auto'):
        """ Назначение разметки для колонки/колонок.

        Аналог метода add.
        Метод размечает колонки: role = 'pd', column_type = 'auto'

        Указанные параметры используются при конфигурировании нод Data Profiling в SberDS.

        Parameters
        ----------
        columns : str или list
            колонка или список колонок датасета, используется для конфигурирования ноды Data Profiling.

        column_type : str
            тип колонки/колонок, используется для конфигурирования ноды Data Profiling.
            допустимые варианты: ['interval', 'nominal', 'time', 'auto'], по умолчанию - 'auto'

        Returns
        -------
        sdsautoval.modprop.ColumnsSelector object
        метод добавляет разметку в обьект, который необходимо передать в параметр "selector" функции "DataSample"


        Examples
        --------
        columns.pd(['column1','column2','column3'])
        columns.pd('column')
        """
        return self.add(columns=columns, role='pd', column_type=column_type)

    def treatment(self, columns=None, column_type='auto'):
        """ Назначение разметки для колонки/колонок.

        Аналог метода add.
        Метод размечает колонки: role = 'treatment', column_type = 'auto'

        Указанные параметры используются при конфигурировании нод Data Profiling в SberDS.

        Parameters
        ----------
        columns : str или list
            колонка или список колонок датасета, используется для конфигурирования ноды Data Profiling.

        column_type : str
            тип колонки/колонок, используется для конфигурирования ноды Data Profiling.
            допустимые варианты: ['interval', 'nominal', 'time', 'auto'], по умолчанию - 'auto'

        Returns
        -------
        sdsautoval.modprop.ColumnsSelector object
        метод добавляет разметку в обьект, который необходимо передать в параметр "selector" функции "DataSample"


        Examples
        --------
        columns.treatment(['column1','column2','column3'])
        columns.treatment('column')
        """
        return self.add(columns=columns, role='treatment', column_type=column_type)

    def text(self, columns=None, column_type='auto'):
        """ Назначение разметки для колонки/колонок.

        Аналог метода add.
        Метод размечает колонки: role = 'text', column_type = 'auto'

        Указанные параметры используются при конфигурировании нод Data Profiling в SberDS.

        Parameters
        ----------
        columns : str или list
            колонка или список колонок датасета, используется для конфигурирования ноды Data Profiling.

        column_type : str
            тип колонки/колонок, используется для конфигурирования ноды Data Profiling.
            допустимые варианты: ['interval', 'nominal', 'time', 'auto'], по умолчанию - 'auto'

        Returns
        -------
        sdsautoval.modprop.ColumnsSelector object
        метод добавляет разметку в обьект, который необходимо передать в параметр "selector" функции "DataSample"


        Examples
        --------
        columns.text(['column1','column2','column3'])
        columns.text('column')
        """
        return self.add(columns=columns, role='text', column_type=column_type)

    def embedding(self, columns=None, column_type='auto'):
        """ Назначение разметки для колонки/колонок.

        Аналог метода add.
        Метод размечает колонки: role = 'embedding', column_type = 'auto'

        Указанные параметры используются при конфигурировании нод Data Profiling в SberDS.

        Parameters
        ----------
        columns : str или list
            колонка или список колонок датасета, используется для конфигурирования ноды Data Profiling.

        column_type : str
            тип колонки/колонок, используется для конфигурирования ноды Data Profiling.
            допустимые варианты: ['interval', 'nominal', 'time', 'auto'], по умолчанию - 'auto'

        Returns
        -------
        sdsautoval.modprop.ColumnsSelector object
        метод добавляет разметку в обьект, который необходимо передать в параметр "selector" функции "DataSample"


        Examples
        --------
        columns.embedding(['column1','column2','column3'])
        columns.embedding('column')
        """
        return self.add(columns=columns, role='embedding', column_type=column_type)

    def group(self, columns=None, column_type='auto'):
        """ Назначение разметки для колонки/колонок.

        Аналог метода add.
        Метод размечает колонки: role = 'group', column_type = 'auto'

        Указанные параметры используются при конфигурировании нод Data Profiling в SberDS.

        Parameters
        ----------
        columns : str или list
            колонка или список колонок датасета, используется для конфигурирования ноды Data Profiling.

        column_type : str
            тип колонки/колонок, используется для конфигурирования ноды Data Profiling.
            допустимые варианты: ['interval', 'nominal', 'time', 'auto'], по умолчанию - 'auto'

        Returns
        -------
        sdsautoval.modprop.ColumnsSelector object
        метод добавляет разметку в обьект, который необходимо передать в параметр "selector" функции "DataSample"


        Examples
        --------
        columns.group(['column1','column2','column3'])
        columns.group('column')
        """
        return self.add(columns=columns, role='group', column_type=column_type)

    def baseline(self, columns=None, column_type='auto'):
        """ Назначение разметки для колонки/колонок.

        Аналог метода add.
        Метод размечает колонки: role = 'baseline', column_type = 'auto'

        Указанные параметры используются при конфигурировании нод Data Profiling в SberDS.

        Parameters
        ----------
        columns : str или list
            колонка или список колонок датасета, используется для конфигурирования ноды Data Profiling.

        column_type : str
            тип колонки/колонок, используется для конфигурирования ноды Data Profiling.
            допустимые варианты: ['interval', 'nominal', 'time', 'auto'], по умолчанию - 'auto'

        Returns
        -------
        sdsautoval.modprop.ColumnsSelector object
        метод добавляет разметку в обьект, который необходимо передать в параметр "selector" функции "DataSample"


        Examples
        --------
        columns.baseline(['column1','column2','column3'])
        columns.baseline('column')
        """
        return self.add(columns=columns, role='baseline', column_type=column_type)

    def validate(self):
        super().validate()
        if self.defaultRole not in ModelConstants.markuproles_dict.keys() and self.defaultRole.upper() != "EXCLUDED":
            self.raise_and_store(SdsParamValidationError('ColumnsSelector.default_role',
                                                         f"default_role должен быть из {', '.join(ModelConstants.markuproles_dict)}"))
        if self.defaultType not in ModelConstants.markuptypes_dict.keys():
            self.raise_and_store(SdsParamValidationError('ColumnsSelector.default_type',
                                                         f"default_type должен быть из {', '.join(ModelConstants.markuptypes_dict)}"))
        for roleAndType in self.rolesAndTypes.values():
            roleAndType.validate()


def is_windows_drive(netloc):
    return netloc is not None and \
           (len(netloc) == 1) or (len(netloc) == 2 and netloc.endswith(':'))


class AbstractData(Validatable):

    def __init__(
        self,
        key,
        file: str,
        connection: DataConnection = None,
        port_name: str = None,
        project_id: str = None,
        node_id: str = None,
        cached_pv_id: str = None,
    ):
        super().__init__()
        self.key = key
        self.file = file
        self.connection = ConnectionPreprocessorEngine.instance().preprocess_connection(connection, file)
        self.port_name = port_name
        self.project_id = project_id
        self.node_id = node_id
        self.cached_pv_id = cached_pv_id

        self.link_data = False

    def get_key(self) -> str:
        return self.key

    def get_type(self) -> str:
        pass

    def prepare(self, user_session: UserSession, method=None, event_service=None):
        if self.connection:
            self.connection.prepare(user_session, method=method, event_service=event_service)

    def validate(self):
        super().validate()
        if not self.key:
            self.raise_and_store(SdsParamValidationError('key', f"key должен быть заполнен"))

    def validate_file_and_connection(self):
        if isinstance(self.connection, FilledOuterDataConnection):
            if self.connection.artifact_absolute_path:
                self.file = self.connection.artifact_absolute_path
        if self.file:
            self.file = self.file.replace('\\', '/')
        parsed_url = urlparse(self.file)

        if parsed_url.hostname is not None and not is_windows_drive(
            parsed_url.netloc):
            if parsed_url.scheme != 'hdfs':
                self.raise_and_store(SdsDatasourceDescriptionError(
                    'допускается только схема hdfs',
                    advice='Укажите в начале hdfs://'))
            if self.connection is not None:
                self.raise_and_store(SdsDatasourceDescriptionError(
                    'Нельзя указывать одновременно и connection и полный путь к файлу',
                    advice='Уберите connection'))
            if parsed_url.port is not None:
                self.raise_and_store(SdsDatasourceDescriptionError(
                    'Указание порта в полном пути не допускается',
                    advice='уберите порт из пути'))
            # create connection from file
            self.connection = DataConnection(host=parsed_url.netloc)
            self.file = parsed_url.path
        elif parsed_url.scheme == 'file' or is_windows_drive(parsed_url.scheme) or ((
                                                 parsed_url.scheme is None or parsed_url.scheme == '') and self.connection is None):
            self.connection = LocalDataConnection(self.file)
        elif self.link_data:
            return
        else:
            if self.connection is None:
                self.raise_and_store(SdsDatasourceDescriptionError(
                    'Для локального пути к файлу нужно указывать connection',
                    advice='Укажите connection'))


class DataSample(AbstractData):
    """ Настройка одного источника данных.

    Указанные параметры используются при конфигурировании нод Data Source и Data Profiling в SberDS.
    В ноду Data Source с названием sample_type, будет загружена  table.
    В последующей ноде Data Profiling будет использована разметка сохраненная в обьекте selector.


    Parameters
    ----------
    key : str
        тип выборки, допустимые варианты: ['train', 'out_of_sample', 'out_of_time']

    sql : str
        название таблицы или hive sql запрос к источнику данных, результатом
        которых будет выгрузка данных в ноду Data Source с названием, указанным
        в параметре sample_type.

    file : str, optional
        путь к файлу вида /data/my_sources/heart_disease.parquet. Можно
        использовать файлы типа csv и Parquet. Указывается только для соединений типа hdfs.
        также можно указать полный url вида hdfs://arnsdpldbr2/data/source.parquet
        в таком случае указание connection не требуется

    selector : ColumnsSelector object
        разметка колонок, которая назначается функцией ColumnSelector

    connection: DataConnection object
        источник данных, определяется функцией DataConnection

    port_name: str, optional
        Название порта ноды СберДС, из которого берутся данные

    project_id: str, optional
        uuid проекта СберДС, из которого берутся данные

    node_id: str, optional
        uuid ноды СберДС, из которой берутся данные

    encoding : str
        кодировка файла csv. Допустимые значения 'UTF-8', 'windows-1251',
        'MacCyrillic' и другие поддерживаемые в java
        https://docs.oracle.com/javase/8/docs/technotes/guides/intl/encoding.doc.html
        По-умолчанию 'utf-8'.

    delimiter : str, optional
        разделитель полей в csv, допустимые значения ',', '|', ':', ';', ' ', '\t', '-'.
        По-умолчанию ','

    row_delimiter : str, optional
        разделитель строк в csv, допустимые значения '\n', '\r\n' и '\r'.
        По-умолчанию '\n'

    escape_char : str, optional
        Символ для маскирования
        По-умолчанию '\''

    first_row_as_header : boolean, optional
        первая строка csv - заголовок, по-умолчанию False.

    first_column_as_index : boolean, optional
        использовать первую колонку csv как номер строки, по-умолчанию False.

    cached_pv_id: str, optional
        uuid Cached PV

    Returns
    -------
    функция возвращает обьект, который необходимо передать в параметр "data" функции "run"


    Examples
    --------
    data_source1=DataConnection(host='tkle-mvp1133.vm.esrt.cloud.sbrf.ru', schema='sdsdh_validationmanag')
    data_source2=DataConnection(host='SDP-19115654-ipa-sds-dev-sdp-hadoop-452fae')

    DataSample(key="out_of_sample", sql='heart_dis_predicted_100', selector=columns, connection=data_source1),
    DataSample(key="train", file='/data/lib/sds/risk/validationmanag/heart_diseases_predicted_500.csv', selector=columns, connection=data_source2)
    # local file
    DataSample(key="train", file='file:///Users/my_user/data/heart_diseases_predicted_500.csv', selector=columns)
    DataSample(key="train", file='/home/my_user/data/heart_diseases_predicted_500.csv', selector=columns)
    DataSample(key="train", file='C:\\work\\data\\heart_diseases_predicted_500.csv', selector=columns)
    DataSample(key="train", file='file://C:/work/data/heart_diseases_predicted_500.csv', selector=columns)

    """

    def __init__(
        self,
        key: str,
        selector: ColumnsSelector,
        connection: DataConnection = None,
        sql: str = None,
        file: str = None,
        port_name: str = None,
        project_id: str = None,
        node_id: str = None,
        encoding: str = None,
        delimiter: str = None,
        row_delimiter: str = None,
        escape_char: str = None,
        first_row_as_header: bool = True,
        first_column_as_index: bool = False,
        validate_settings: bool = True,
        cached_pv_id: str = None
    ):

        super().__init__(key, file, connection)
        self.selector = selector
        self.sql = sql
        self.port_name = port_name
        self.project_id = project_id
        self.node_id = node_id
        self.encoding = encoding
        self.delimiter = delimiter
        self.row_delimiter = row_delimiter
        self.escape_char = escape_char
        self.first_row_as_header = first_row_as_header
        self.first_column_as_index = first_column_as_index
        self._validate_settings = validate_settings
        self.cached_pv_id = cached_pv_id

        if (project_id is not None and node_id is not None and port_name is not None) or (cached_pv_id is not None):
            self.link_data = True
        else:
            self.link_data = False

    def _validate_connection_host(self):
        if self.file:
            if self._validate_settings:
                if UserContext.get().last_env_is_prom():
                    self._check_connection_host(self.connection,
                                                      ModelConstants.visual_allowed_host_list)
                if UserContext.get().last_env_is_lab_ift():
                    self._check_connection_host(self.connection, [
                        'SDP-19115654-ipa-sds-ift-sdp-hadoop-1-0cd162'])

    def _check_connection_host(self, connection: DataConnection, hosts_list: list):
        if connection is None:
            return
        if isinstance(connection, LocalDataConnection):
            return
        if connection.host not in hosts_list:
            host_list_str = ",".join(str(host_list_item) for host_list_item in
                                     hosts_list)
            advise = "Если в качестве источника данных указываете file, то в параметрах DataConnection:\n" + \
                     "  * schema - заполнять не нужно,\n" + \
                     "  * для host допустимые значения: " + host_list_str + ".\n" + \
                     "ВАЖНО: если указать полный url вида hdfs://arnsdpldbr2/data/source.csv в таком случае для функции DataSample заполнять connection не нужно"
            self.raise_and_store(SdsParamValidationError('connection.host', advise))

    def get_type(self) -> str:
        return 'sample'

    def validate(self):
        super().validate()
        if isinstance(self.connection, LocalDataConnection):
            if not self.file:
                self.file = self.connection.file
        if not self.key:
            self.raise_and_store(SdsParamValidationError('DataSample.key',
                                                         f"DataSample.key должен быть заполнен"))

        if (self.sql is None and self.file is None and not self.link_data
            and not isinstance(self.connection, LocalDataConnection)
                and not isinstance(self.connection, OuterDataConnection)
                and not isinstance(self.connection, FilledOuterDataConnection)):
            self.raise_and_store(SdsParamValidationError('DataSample.sql',
                                                         f"DataSample.sql или DataSample.file или DataSample.port_name должен быть заполнен"))
        if not self.selector:
            self.raise_and_store(SdsParamValidationError('DataSample.selector',
                                                         f"DataSample.selector должен быть заполнен"))

        if self.file:
            self.validate_file_and_connection()

        if not self.link_data and self.connection:
            self.connection.validate()
        self.selector.validate()
        self._validate_connection_host()


class DataArtifact(AbstractData):
    """
    Настройка одного артефакта необходимого для исполнения методики (смотри требования к методике функцией select_method).

    Указанные параметры используются при конфигурировании нод Data Source в SberDS.
    Если указать artifact='model', то в ноду Data Source с названием model, будет загружен  picke файл.

    Parameters
    ----------
    key : str
        артефакт, допустимые варианты: ['model', 'encoding'] или другое название артефакта указанное в требованиях к методике (функция select_method)

    file : str
            путь к файлу вида /data/my_sources/heart_disease.pkl. Можно
            использовать файлы типа pkl и Parquet. Указывается только для соединений типа hdfs.
            также можно указать полный url вида hdfs://arnsdpldbr2/data/source.pkl

    connection: DataConnection object
        источник данных

    Returns
    -------
    функция возвращает обьект, который необходимо передать в параметр "data" функции "run"


    Examples
    --------
    data_source=DataConnection(host='SDP-19115654-ipa-sds-dev-sdp-hadoop-452fae')

    DataArtifact(key="model", file='/data/lib/sds/risk/validationmanag/pkl_test/test_path_1.pkl', connection=data_source)

    """

    def __init__(
        self,
        key: str,
        file: str = None,
        connection: DataConnection = None,
        port_name: str = None,
        project_id: str = None,
        node_id: str = None,
        cached_pv_id: str = None,
    ):
        super().__init__(key, file, connection)
        self.port_name = port_name
        self.project_id = project_id
        self.node_id = node_id
        self.cached_pv_id = cached_pv_id

        if project_id is not None and node_id is not None and port_name is not None:
            self.link_data = True
        else:
            self.link_data = False

    def get_type(self) -> str:
        return 'artifact'

    def validate(self):
        super().validate()
        if isinstance(self.connection, LocalDataConnection):
            if not self.file:
                self.file = self.connection.file
        self.validate_file_and_connection()


markup_role_corrector = Corrector(original_dict=ModelConstants.markuproles_dict,
                                  inverted_dict=ModelConstants.markuproles_dict_inverted,
                                  on_correction=lambda original, corrected: print(
                                      f'Внимание! Неверная роль {original} заменена на {corrected}'))
markup_type_corrector = Corrector(original_dict=ModelConstants.markuptypes_dict,
                                  inverted_dict=ModelConstants.markuptypes_dict_inverted,
                                  on_correction=lambda original, corrected: print(
                                      f'Внимание! Неверный тип {original} заменен на {corrected}'))


def correct_role(role):
    return markup_role_corrector.correct(role)


def correct_type(markup_type):
    return markup_type_corrector.correct(markup_type)
