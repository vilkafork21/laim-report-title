from .mms_web_client import MmsWebClient
from ..dto.model_version_info import ModelVersionInfo
from ..utils.poll import status_not_in_progress, get_status_from_response_in_progress, Poller, poll

DEFAULT_POLL_INTERVAL = 5  # seconds
DEFAULT_TIMEOUT = 60  # seconds


class MmsService:

    def __init__(self, host, session, token, is_internal=False):
        self._host = host
        self._session = session
        self._token = token
        self._client = MmsWebClient(host, session, token, is_internal)

    def get_model_version_info(self, model_version_id: int) -> ModelVersionInfo:
        raw_data = self._client.get_model_version_info(model_version_id)
        model_version_info = ModelVersionInfo.from_dict(raw_data)
        print("Информация о версии модели\n")
        return model_version_info

    def get_mms_schema(self):
        """ Получить схему данных из библиотеки моделей.

        Returns:
            dict: Схема данных
        """
        return self._client.get_mms_schema()

    def edit_model_version(self, prevalidation_id=None, snapshot_id=None, model_version=None, data=None, timeout=DEFAULT_TIMEOUT, poll_interval=DEFAULT_POLL_INTERVAL):

        final_status=None
        if prevalidation_id is not None and snapshot_id is not None:
            print(f"Send edit model request: prevalidation_id={prevalidation_id}, snapshot_id={snapshot_id}")
            final_status = self._client.edit_model_version(prevalidation_id, snapshot_id)
        elif model_version is not None and data is not None:
            print(f"Send flex edit model request: model_version={model_version}, data={data}")
            final_status = self._client.edit_model_version_flex(model_version, data)

        if final_status is None:
            print("Edit opreation not started. Please provide prevalidation_id and snapshot_id or model_version and data parameters")
            return None
        request_id = final_status.get('requestId')
        if not request_id:
            print("Failed to start edit operation: no requestId returned")
            return None
        print(f"Got requestId={request_id}, waiting {timeout} seconds for answer from MMS ", end='')

        return self._poll_edit_model_completion(request_id, timeout=timeout, poll_interval=poll_interval)

    def edit_model_version_status(self, request_id, timeout=DEFAULT_TIMEOUT, poll_interval=DEFAULT_POLL_INTERVAL):
        print(f"Checking edit model request status: request_id={request_id}\n")
        return self._poll_edit_model_completion(request_id, timeout=timeout, poll_interval=poll_interval)

    # noinspection PyUnusedLocal
    @poll(logger=Poller.Logger(
        result_extractor=lambda response: get_status_from_response_in_progress(response),
        operation_name='Edit model version',
        additional_timeout_info=lambda
                args,
                kwargs,
                result: f"but you can check status later manually by execution of auto_validator.edit_model_version_status('{args[1]}')"),
        exit_condition=lambda response: status_not_in_progress(response),
        timeout_param='timeout',
        poll_interval_param='poll_interval')
    def _poll_edit_model_completion(self, request_id, timeout=DEFAULT_TIMEOUT, poll_interval=DEFAULT_POLL_INTERVAL):
        return self._client.edit_model_version_status(request_id)

    def clone_model_version(self, model_version_id, timeout=DEFAULT_TIMEOUT, poll_interval=DEFAULT_POLL_INTERVAL):
        print(f"Send clone model request: model_version_id={model_version_id}")

        final_status = self._client.clone_model_version(model_version_id)
        request_id = final_status.get('requestId')
        if not request_id:
            print("Failed to start clone operation: no requestId returned")
            return None
        print(f"Got requestId={request_id}, waiting {timeout} seconds for answer from MMS ", end='')

        return self._poll_clone_model_completion(request_id, timeout=timeout, poll_interval=poll_interval)

    def clone_model_version_status(self, request_id, timeout=DEFAULT_TIMEOUT, poll_interval=DEFAULT_POLL_INTERVAL):
        print(f"Checking clone model request status: request_id={request_id}\n")
        return self._poll_clone_model_completion(request_id, timeout=timeout, poll_interval=poll_interval)

    # noinspection PyUnusedLocal
    @poll(logger=Poller.Logger(
        result_extractor=lambda response: get_status_from_response_in_progress(response),
        operation_name='Clone model version',
        additional_timeout_info=lambda
                args,
                kwargs,
                result: f"but you can check status later manually by execution of auto_validator.clone_model_version_status('{args[1]}')"),
        exit_condition=lambda response: status_not_in_progress(response),
        timeout_param='timeout',
        poll_interval_param='poll_interval')
    def _poll_clone_model_completion(self, request_id, timeout=DEFAULT_TIMEOUT, poll_interval=DEFAULT_POLL_INTERVAL):
        return self._client.clone_model_version_status(request_id)

    def get_model_version(self, project_id):
        return self._client.get_model_version(project_id)
