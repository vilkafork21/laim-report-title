import json

from ..base_requester import BaseRequester
from ..utils.retry import withretry


class MmsWebClient:
    _SERVICE_PATH = 'template-selector'
    _END_POINT = '/api/mms'

    def __init__(self, host, session, token, is_internal=False):
        self._requester = BaseRequester(host, session, service_name=self.__class__._SERVICE_PATH)
        self._is_internal = is_internal
        self._token = token

    @withretry()
    def get_mms_schema(self):
        """
        Get graphql schema representation

        :return: JSON response with graphql schema representation
        """

        response = self._requester.request(
            method='get',
            endpoint=f"{self._base_path()}/schema",
            headers=self._headers(self._token),
            timeout_seconds=60
        )
        return response.json()

    @withretry()
    def get_model_version_info(self, model_version_id: int):
        """
        Get model version info by modelVersionId

        :param model_version_id: Model version ID
        :return: JSON response with model version data
        """

        response = self._requester.request(
            method='get',
            endpoint=f"{self._base_path()}/model-version-info/{model_version_id}",
            headers=self._headers(self._token),
            timeout_seconds=60
        )
        return response.json()

    def _base_path(self):
        return self._SERVICE_PATH + self._END_POINT if not self._is_internal else self._END_POINT

    def edit_model_version(self, prevalidation_id, snapshot_id):
        """
        Edit model version information by prevalidation_id and snapshot_id

        :param prevalidation_id: Id of prevalidation where model field values are taken from
        :param snapshot_id: Id of snapshot project
        :return: JSON response with model request_id and status
        """
        response = self._requester.request(
            method='post',
            endpoint=f"{self._base_path()}/edit-model-version?prevalidationId={prevalidation_id}&snapshotId={snapshot_id}",
            headers=self._headers(self._token),
            timeout_seconds=60
        )
        return response.json()

    def edit_model_version_flex(self, model_version, data):
        """
        Flex edit model version information by model_version and data

        :param model_version: model_version
        :param data: parameters data with model field names and values
        :return: JSON response with model request_id and status
        """
        response = self._requester.request(
            method='post',
            endpoint=f"{self._base_path()}/edit-model-version-flex?modelVersionId={model_version}",
            data=json.dumps(data),
            headers=self._headers(self._token),
            timeout_seconds=60
        )
        return response.json()

    @withretry()
    def edit_model_version_status(self, request_id):
        """
        Get status of model edit request by request_id

        :param request_id: Id of request
        :return: JSON response with model request_id and current status
        """
        response = self._requester.request(
            method='get',
            endpoint=f"{self._base_path()}/edit-model-version?requestId={request_id}",
            headers=self._headers(self._token),
            timeout_seconds=60
        )
        return response.json()

    def clone_model_version(self, model_version_id):
        """
        Clone model version

        :param model_version_id: Id of model version in MLR
        :return: JSON response with request_id and status
        """
        response = self._requester.request(
            method='post',
            endpoint=f"{self._base_path()}/clone-model-version",
            headers=self._headers(self._token),
            data=json.dumps({'modelVersionId': model_version_id}),
            timeout_seconds=60
        )
        return response.json()

    @withretry()
    def clone_model_version_status(self, request_id):
        """
        Get status of model clone request by request_id

        :param request_id: Id of request
        :return: JSON response with model request_id and current status
        """
        response = self._requester.request(
            method='get',
            endpoint=f"{self._base_path()}/clone-model-version/{request_id}",
            headers=self._headers(self._token),
            timeout_seconds=60
        )
        return response.json()

    def get_model_version(self, project_id):
        response = self._requester.request(
            method='get',
            endpoint=f"{self._base_path()}/get-model-version?projectId={project_id}",
            headers=self._headers(self._token),
            timeout_seconds=60
        )
        return response.json()

    @staticmethod
    def _headers(token):
        return {
            'Authorization': f'Bearer {token}',
            'Content-Type': 'application/json',
            'Accept': 'application/json',
        }
