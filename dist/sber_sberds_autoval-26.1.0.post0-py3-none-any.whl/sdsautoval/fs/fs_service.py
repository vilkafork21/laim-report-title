from .fs_web_client import FsWebClient
from ..utils.poll import poll, Poller, get_status_from_response_in_progress, get_from_dict, status_not_in_progress

DEFAULT_POLL_INTERVAL = 5  # seconds
DEFAULT_TIMEOUT = 60  # seconds


def get_request_id_shortlist(result):
    return get_from_dict(result, 'requestId', default='requestId из ответа вызова submit_shortlist')


class FsService:

    def __init__(self, host, session, token, is_internal=False):
        self._host = host
        self._session = session
        self._token = token
        self._client = FsWebClient(host, session, token, is_internal)

    def get_long_list(self, feature_store_project_id, timeout=DEFAULT_TIMEOUT, poll_interval=DEFAULT_POLL_INTERVAL):
        print(f"Send get-long-list request: feature_store_project_id={feature_store_project_id}")

        final_status = self._client.get_long_list(feature_store_project_id)
        request_id = final_status.get('requestId')
        if not request_id:
            print("Failed to start get-long-list operation: no requestId returned")
            return None
        print(f"Got requestId={request_id}, waiting {timeout} seconds for answer from FS ", end='')
        return self._poll_get_long_list_completion(request_id, timeout=timeout, poll_interval=poll_interval)

    def get_long_list_status(self, request_id, timeout=DEFAULT_TIMEOUT, poll_interval=DEFAULT_POLL_INTERVAL):
        print(f"Checking get-long-list request status: request_id={request_id}\n")
        return self._poll_get_long_list_completion(request_id, timeout=timeout, poll_interval=poll_interval)

    def get_short_list(self, feature_store_project_id, timeout=DEFAULT_TIMEOUT, poll_interval=DEFAULT_POLL_INTERVAL):
        print(f"Send get-short-list request: feature_store_project_id={feature_store_project_id}")

        final_status = self._client.get_short_list(feature_store_project_id)
        request_id = final_status.get('requestId')
        if not request_id:
            print("Failed to start get-short-list operation: no requestId returned")
            return None
        print(f"Got requestId={request_id}, waiting {timeout} seconds for answer from FS ", end='')
        return self._poll_get_short_list_completion(request_id, timeout=timeout, poll_interval=poll_interval)

    def get_short_list_status(self, request_id, timeout=DEFAULT_TIMEOUT, poll_interval=DEFAULT_POLL_INTERVAL):
        print(f"Checking get-short-list request status: request_id={request_id}\n")
        return self._poll_get_short_list_completion(request_id, timeout=timeout, poll_interval=poll_interval)

    # noinspection PyUnusedLocal
    @poll(logger=Poller.Logger(
        result_extractor=lambda response: get_status_from_response_in_progress(response),
        operation_name='get-long-list',
        additional_timeout_info=lambda
                args,
                kwargs,
                result: f"but you can check status later manually by execution of auto_validator.get_long_list_status('{args[1]}')"),
        exit_condition=lambda response: status_not_in_progress(response),
        timeout_param='timeout',
        poll_interval_param='poll_interval')
    def _poll_get_long_list_completion(self, request_id, timeout=DEFAULT_TIMEOUT, poll_interval=DEFAULT_POLL_INTERVAL):
        return self._client.get_long_list_status(request_id)

        # noinspection PyUnusedLocal
    @poll(logger=Poller.Logger(
        result_extractor=lambda response: get_status_from_response_in_progress(response),
        operation_name='get-short-list',
        additional_timeout_info=lambda
                args,
                kwargs,
                result: f"but you can check status later manually by execution of auto_validator.get_short_list_status('{args[1]}')"),
        exit_condition=lambda response: status_not_in_progress(response),
        timeout_param='timeout',
        poll_interval_param='poll_interval')
    def _poll_get_short_list_completion(self, request_id, timeout=DEFAULT_TIMEOUT, poll_interval=DEFAULT_POLL_INTERVAL):
        return self._client.get_short_list_status(request_id)

    def submit_shortlist(self, fs_project_id, aliases, scores_data=None, timeout=DEFAULT_TIMEOUT, poll_interval=DEFAULT_POLL_INTERVAL):
        if scores_data is None:
            scores_data = {}
        final_status = self._client.submit_shortlist(fs_project_id, aliases, scores_data, timeout=timeout)
        request_id = final_status.get('requestId')
        if not request_id:
            print("Failed to start submit-short-list operation: no requestId returned")
            return None
        if get_status_from_response_in_progress(final_status).lower() == 'error':
            print("Failed to start submit-short-list operation: status is ERROR")
            return final_status
        print(f"Got requestId={request_id}, waiting {timeout} seconds for answer from FS ", end='')

        return self._poll_submit_shortlist(request_id, timeout=timeout, poll_interval=poll_interval)

    def check_submit_shortlist(self, request_id, timeout_seconds=60):
        return self._poll_submit_shortlist(request_id, timeout=timeout_seconds)

    # noinspection PyUnusedLocal
    @poll(logger=Poller.Logger(
        result_extractor=lambda response: get_status_from_response_in_progress(response),
        operation_name='submit-short-list',
        additional_timeout_info=lambda
                args,
                kwargs,
                result: f"but you can check status later manually by execution of auto_validator.check_submit_shortlist('{args[1]}')"),
        exit_condition=lambda response: status_not_in_progress(response),
        timeout_param='timeout',
        poll_interval_param='poll_interval')
    def _poll_submit_shortlist(self, request_id, timeout=60, poll_interval=DEFAULT_POLL_INTERVAL):
        return self._client.check_submit_shortlist(request_id, timeout=timeout)
