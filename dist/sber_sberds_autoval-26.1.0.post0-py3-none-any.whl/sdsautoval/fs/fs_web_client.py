import json

from ..base_requester import BaseRequester
from ..utils.retry import withretry
from ..utils.text import not_empty


class FsWebClient:
    _SERVICE_PATH = 'template-selector'
    _END_POINT = '/api/feature-store'

    def __init__(self, host, session, token, is_internal=False):
        self._requester = BaseRequester(host, session, service_name=self.__class__._SERVICE_PATH)
        self._is_internal = is_internal
        self._token = token


    def _base_path(self):
        return self._SERVICE_PATH + self._END_POINT if not self._is_internal else self._END_POINT

    def get_long_list(self, feature_store_project_id):
        """
        get long list by feature_store_project_id

        :param feature_store_project_id: Id of feature store project
        :return: JSON response with model request_id and status
        """
        response = self._requester.request(
            method='get',
            endpoint=f"{self._base_path()}/features/{feature_store_project_id}?generationType=LONG_LIST",
            headers=self._headers(self._token),
            timeout_seconds=60
        )
        return response.json()

    @withretry()
    def get_long_list_status(self, request_id):
        """
        Get status of get long list request by request_id

        :param request_id: Id of request
        :return: JSON response with model request_id and current status
        """
        response = self._requester.request(
            method='get',
            endpoint=f"{self._base_path()}/features/{request_id}/response",
            headers=self._headers(self._token),
            timeout_seconds=60
        )
        return response.json()

    def get_short_list(self, feature_store_project_id):
        """
        get short list by feature_store_project_id

        :param feature_store_project_id: Id of feature store project
        :return: JSON response with model request_id and status
        """
        response = self._requester.request(
            method='get',
            endpoint=f"{self._base_path()}/features/{feature_store_project_id}?generationType=SHORT_LIST",
            headers=self._headers(self._token),
            timeout_seconds=60
        )
        return response.json()

    @withretry()
    def get_short_list_status(self, request_id):
        """
        Get status of get short list request by request_id

        :param request_id: Id of request
        :return: JSON response with model request_id and current status
        """
        response = self._requester.request(
            method='get',
            endpoint=f"{self._base_path()}/features/{request_id}/response",
            headers=self._headers(self._token),
            timeout_seconds=60
        )
        return response.json()

    def submit_shortlist(self, fs_project_id, aliases, scores_data, timeout=60):
        end_point = f'{self._base_path()}/submit-shortlist'
        params = {}
        if not_empty(fs_project_id):
            params['featureStoreProjectId'] = fs_project_id
        if not_empty(aliases):
            params['shortListAliases'] = aliases
        if scores_data.get('shortListScores'):
            params['shortListScores'] = scores_data['shortListScores']
        data = json.dumps(params)
        response = self._do_request_endpoint(end_point, method='post', data=data, timeout=timeout)
        return response.json()

    @withretry()
    def check_submit_shortlist(self, request_id, timeout):
        end_point = f'{self._base_path()}/check-submit-shortlist/{request_id}'
        response = self._do_request_endpoint(end_point, method='get', timeout=timeout)
        return response.json()

    def _do_request_endpoint(self, end_point, method='get', data=None, need_process=True, timeout=60):
        if method is None:
            real_method = 'get' if data is None else 'post'
        else:
            real_method = method
        return self._requester.request(
            method=real_method,
            endpoint=end_point,
            headers=self._headers(self._token),
            data=data,
            need_process=need_process,
            timeout_seconds=timeout
        )

    @staticmethod
    def _headers(token):
        return {
            'Authorization': f'Bearer {token}',
            'Content-Type': 'application/json',
            'Accept': 'application/json',
        }
