import html
import re
from collections import OrderedDict

class Contacts:
    # storage format3 (dups possible (list-tuple)
    # [('BlockName', [
    #     ('Иванов Иван Иванович', 'ivanov@sber.test'),
    #     ('Петров Петр Петрович', 'petrov@sber.test', 'petrov.petr@sber.test')
    #   ]),
    #   ('BlockName2', [
    #     ('Сидоров Сидор Сидорович', 'sidorov@sber.test'),
    #     ('Яковлев Яков Яковлевич', 'yakovlev@sber.test', 'yakovlev.jakov@sber.test')
    #   ]),
    # ]
    def __init__(self, contacts=None, first_block=None, last_email=None):
        if self._is_correct(contacts, first_block, last_email):
            self.contacts = contacts
        else:
            self.contacts = None
        self.first_block = first_block
        self.last_email = last_email

    def __bool__(self):
        return self.contacts is not None and len(self.contacts) > 0

    def __add__(self, other):
        if not isinstance(other, Contacts):
            raise TypeError("Can't add Contacts to non-Contacts object")
        if self and other:
            return Contacts(Contacts._merge_blocks(self.contacts + other.contacts), self.first_block, other.last_email)
        elif self:
            return self
        return other

    @staticmethod
    def _is_correct(blocks, first_block, last_email):
        if not (blocks and first_block and last_email):
            return True
        if isinstance(blocks, list):
            for block in blocks:
                if not (isinstance(block, tuple) and len(block) >1):
                    return False
                block_name, contacts = block
                if not (isinstance(block_name, str) and block_name.strip() != "" and isinstance(contacts, list) and len(contacts) > 0):
                    return False
                for contact in contacts:
                    if not (isinstance(contact, tuple) and len(contact) >0):
                        return False
                    for n in contact:
                        if not isinstance(n, str) or n.strip() == "":
                            return False
        return True

    @staticmethod
    def parse(raw_string):
        regex = r"(?P<block>.*)\n\s*(?P<number>[0-9]*)(?P<name>.*?)\s+\(mailto:\s*(?P<emails>.+)\)"
        blocks = []
        s = raw_string
        first_block = None
        last_email = None
        while True:
            match = re.search(regex, s, re.MULTILINE)
            if match:
                res = match.groupdict()
                s = s[match.end():]
                block = res["block"].strip() if "block" in res else ""
                number = res["number"].strip() if "number" in res else ""
                name = res["name"].strip() if "name" in res else ""
                emails = res["emails"].split(" ") if "emails" in res else []
                if number != "":  # numbered contacts detected, switch to simple format
                    return ContactsSimple.parse(raw_string)
                if block != "":
                    blocks.append((block, []))
                    if first_block is None:
                        first_block = block
                if name != "" and emails != []:
                    blocks[-1][1].append((name,) + tuple(emails))
            else:
                break

        if len(blocks) > 0 and len(blocks[-1][1]) > 0 and len(blocks[-1][1][-1]) > 1:
            last_email = blocks[-1][1][-1][-1]

        return Contacts(Contacts._merge_blocks(blocks), first_block, last_email)

    @staticmethod
    def _merge_blocks(blocks):
        # Use dict to merge values, and the convert back to tuple
        new_blocks = OrderedDict()
        for block_name, contacts in blocks:
            cnt = new_blocks.setdefault(block_name, OrderedDict())
            for contact in contacts:
                cnt[contact] = 1
        return [(block_name, list(contacts.keys())) for block_name, contacts in new_blocks.items()]

    def advice_before_contacts(self, advice: str):
        """
        Returns advice prefix before contacts.
        """
        if self.first_block:
            return advice.split(self.first_block)[0].strip()
        return advice
    def advice_after_contacts(self, advice: str):
        """
        Returns advice suffix after last email and bracket.
        """
        if self.last_email:
            t = advice.split(self.last_email)
            if len(t)>1:
                return t[-1].replace(")", "", 1).strip()
        return advice

    def _simple_str(self):
        if not self.contacts or len(self.contacts) == 0:
            return "is empty"
        result = []
        for block_name, contacts in self.contacts:
            result.append(block_name)
            for name, *emails in contacts:
                result.append(f"\t{name} mailto:{emails[0]}")
                for email in emails[1:]:
                    result.append(f"\t{' ' * len(name)} mailto:{email}")
        return "\n".join(result)

    def __str__(self):
        return self._simple_str()

    def ipython_display(self):
        from IPython.core.display import HTML
        from IPython.display import display
        display(HTML(self._render_html()))

    def _render_html(self):
        """
        Создаёт строку формата html из контактов со стилями.
        """
        out = '<div class="output_subarea output_html rendered_html" dir="auto">'
        out += self._styles()
        out += self._html()
        out += '</div>'
        return out

    def _html(self):
        """
        Создаёт строку формата html из контактов.
        """
        out = '<table border="1" class="contacts">'
        out += '\n<thead>'
        out += self._row_to_html(row='Подразделение Валидаторы Почта'.split(' '), tag="th")
        out += '</thead>\n'
        out += '<tbody>\n'

        for block_name, contacts in self.contacts:
            out += '<tr><td'

            b_rowspan = sum(len(contact)-1 for contact in contacts)
            if b_rowspan > 1:
                out += f' rowspan="{b_rowspan}"'

            out += f'>{block_name.replace("Подразделение:","").strip()}</td>'

            for n, (name, *emails) in enumerate(contacts):
                if n > 0:
                    out += '<tr>'
                c_rowspan = len(emails)
                out += '<td'
                if c_rowspan > 1:
                    out += f' rowspan="{c_rowspan}"'
                out += f'>{name}</td>'
                for e, email in enumerate(emails):
                    if e>0:
                        out += '<tr>'
                    out += f'<td><a href="mailto:{email}">{email}</a></td></tr>\n'
        out += '</tbody>'
        out += '</table>'
        return out

    def _styles(self):
        """
        Инициализирует стили таблицы.
        """
        return """
            <style scoped="">
                .dataframe tbody tr th:only-of-type {
                    vertical-align: middle;
                }
                .dataframe tbody tr th {
                    vertical-align: top;
                }
                .contacts {
                    text-align: left!important;
                    border: 1px solid black!important;
                }
                .contacts thead tr th {
                    text-align: left!important;
                    border: 1px solid black!important;
                }
                .contacts tbody tr td {
                    text-align: left!important;
                    border: 1px solid black!important;
                }
                </style>
        """

    def _row_to_html(self, row: [], tag: str, style=""):
        """
        Преобразует список к строке таблицы, где каждый элемент списка это запись.
        """
        out = f'<tr {style}>'

        for i, cell in enumerate(row):
            cell = str(cell)
            cell = '<br>'.join(str(cell).split('\n'))
            out += f'<{tag}>{html.escape(cell)}</{tag}>'

        out += "</tr>"
        return out

class ContactsSimple(Contacts):

    @staticmethod
    def parse(raw_string):
        regex = r"\n\s*(?P<first>(?:[0-9\W]*)(?P<name>.*?))[\s\W]+mailto:\s*(?P<emails>.+[\w\d])"
        blocks = []
        s = raw_string
        first_block = None
        last_email = None
        while True:
            match = re.search(regex, s, re.MULTILINE)
            if match:
                res = match.groupdict()
                s = s[match.end():]
                first = res["first"].strip() if "first" in res else ""
                name = res["name"].strip() if "name" in res else ""
                emails = res["emails"].split(" ") if "emails" in res else []
                if first_block is None and first != "":
                    first_block = first
                if len(blocks) == 0:
                    blocks.append(("ROOT", []))
                if name != "" and emails != []:
                    blocks[-1][1].append((name,) + tuple(emails))
            else:
                break

        if len(blocks) > 0 and len(blocks[-1][1]) > 0 and len(blocks[-1][1][-1]) > 1:
            last_email = blocks[-1][1][-1][-1]

        return ContactsSimple(blocks, first_block, last_email)

    def _simple_str(self):
        if not self.contacts or len(self.contacts) == 0:
            return "is empty"
        result = []
        for _, contacts in self.contacts:
            for name, *emails in contacts:
                result.append(f"{name} mailto:{emails[0]}")
                for email in emails[1:]:
                    result.append(f"{' ' * len(name)} mailto:{email}")
        return "\n".join(result)

    def _html(self):
        """
        Создаёт строку формата html из контактов.
        """
        out = '<table border="1" class="contacts">'
        out += '\n<thead>'
        out += self._row_to_html(row='Описание Почта'.split(' '), tag="th")
        out += '</thead>\n'
        out += '<tbody>\n'

        for _, contacts in self.contacts:
            for n, (name, *emails) in enumerate(contacts):
                out += '<tr><td'
                c_rowspan = len(emails)
                if c_rowspan > 1:
                    out += f' rowspan="{c_rowspan}"'
                out += f'>{name}</td>'
                for e, email in enumerate(emails):
                    if e>0:
                        out += '<tr>'
                    out += f'<td><a href="mailto:{email}">{email}</a></td></tr>\n'
        out += '</tbody>'
        out += '</table>'
        return out
