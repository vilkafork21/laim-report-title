import getpass
from base64 import b64encode
from html.parser import HTMLParser
from urllib.parse import urlparse

from sdsautoval.context.constants import SBERDS_MAIL
from .base_requester import BaseRequester
from .colors import FText
from .exceptions.exceptions import *
from .exceptions.sds_exceptions import *
from .utils.misc import get_default_contacts_str


class Credentials:
    login: str
    password: str

    def __init__(self, login, password):
        self.login = login
        self.password = password


class InternalAuthorizator():
    _token_path = '/cred/user_api_token'

    def __init__(self):
        self.token = None

    def authorize(self) -> str:
        self._get_internal_token()
        print(FText.okgreen(f"Успешная авторизация"))
        return self.token

    def _get_internal_token(self):
        try:
            with open(self._token_path, 'r') as file:
                self.token = file.read().rstrip()
        except Exception:
            raise SdsInternalAuthError("Не найден внутренний токен")


class Authorizator(BaseRequester):
    SERVICE_NAME = "authorization"

    def __init__(self, host, alt_hosts, session):
        super(Authorizator, self).__init__(host['url'], session, service_name=self.__class__.SERVICE_NAME)
        self.__sudir_creds = {}
        self.__sds_creds = {}
        self.token = None
        self.login = None
        self.main_host = host
        self.alt_hosts = alt_hosts

    def authorize(self, domain: str, credentials: Credentials = None, otp: str = None):
        try:
            if credentials is not None:
                self.login = credentials.login
            print("Попытка подключения к " + self.__format_host())
            self.__authorize(domain, credentials, otp)
            return self.login, self.token
        except TimeOutError:
            self.__print_timeout_error()
        except ConnResetError:
            self.__print_conn_reset_error()
        except SSLVersionError:
            self.__print_ssl_version_error()
        except SSLError:
            self.__print_ssl_error()
        except (SdsIPAAuthError, SdsSUDIRAuthError) as e:
            self.__print_creds_error(e)
        except UnknownAuthType:
            self.__print_bad_link_error()
        except ServiceUnavailableError:
            self.__print_service_unavailable_error()
        except SdsBaseError as e:
            self.__print_connection_error(e)

    def __format_host(self):
        name = self.main_host['name']
        url = self.main_host['url']
        if name != url:
            return f"{name} ({url})"
        return str(url)

    def __authorize(self, domain: str, credentials: Credentials = None, otp: str = None) -> str:
        try:
            auth_type = self.__identify_auth_type()
        except (ConnResetError, TimeOutError, SSLVersionError, SSLError, ServiceUnavailableError) as err:
            raise err
        except Exception:
            raise SdsAuthParseError("невозможно определить способ аутентификации")

        if auth_type == 'SberDS':
            try:
                self.ipa_auth(credentials)
            except BadGatewayError:
                raise SdsIPAAuthError('Сервис недоступен, возможно идут технические работы. ' +
                                      'Пожалуйста, попробуйте позже, если проблема останется - обратитесь в поддержку' +
                                      f' {SBERDS_MAIL}. С особенностями составления обращения можно ознакомиться по данной ссылке: https://confluence.sberbank.ru/pages/viewpage.action?pageId=4238116349')
            except (ServerError, UnauthorizedError):
                raise SdsIPAAuthError("Возможно у вас нет доступа к SberDS, проверьте инструкцию тут: "
                                      "https://confluence.sberbank.ru/pages/viewpage.action?pageId=4387472848")
            except BadRequestError:
                raise SdsIPAAuthError("Проверьте правильность заполнения логина/пароля входа в SberDS")
        else:
            # 2 types of SUDIR
            try:
                if auth_type == 'SUDIR_WS':
                    self.sudir_auth(domain, credentials, otp)
                elif auth_type == 'SUDIR_NGAM':
                    self.sudir_auth_ngam(domain, credentials, otp)
                else:
                    raise UnknownAuthType('Не удалось определить способ входа на стенд')
            except (ServerError, BadGatewayError):
                raise SdsSUDIRAuthError('Сервис недоступен, возможно идут технические работы. ' +
                                        'Пожалуйста, попробуйте позже, если проблема останется - обратитесь в поддержку' +
                                        f' {SBERDS_MAIL} ИЛИ https://confluence.sberbank.ru/pages/viewpage.action?pageId=4238116349')
            except UnauthorizedError:
                raise SdsSUDIRAuthError("Возможно у вас нет доступа к SberDS, проверьте инструкцию тут: https://confluence.sberbank.ru/pages/viewpage.action?pageId=4387472848")
            except SudirAuthorizationError as e:
                raise SdsSUDIRAuthError(e.args[0])
            except BadRequestError:
                raise SdsSUDIRAuthError("Проверьте правильность заполнения логина/пароля входа в СУДИР")

        return self.token

    def __identify_auth_type(self):
        r = self.request_no_wrapper(method='get', endpoint='/')
        title_element = _find_by_name_and_id(r.text, 'title')
        page_title = title_element.content
        if page_title == 'Developer helper':
            return 'SberDS'
        else:
            # Определить это webSeal или NGAM.
            web_seal_tag = _find_by_name_and_id(r.text, 'form', 'name', 'goWebSeal')
            if web_seal_tag is not None:
                return "SUDIR_WS"
            else:
                return "SUDIR_NGAM"

    def ipa_auth(self, credentials: Credentials = None):
        if credentials is None:
            credentials = self._input_creds()
            self.login = credentials.login

        self.__sds_creds = {
            'grant_type': 'password',
            'username': credentials.login,
            'password': credentials.password,
            'client_id': 'frontend',
        }
        self._update_sds_token()
        print(f"{credentials.login} {FText.okgreen('успешно авторизован')}")

    def sudir_auth(self, domain: str, credentials: Credentials, otp: str):
        r = self.request_no_wrapper(method='get', endpoint='/')
        # Сделать авторизацию через WebSeal.
        parsed_uri = urlparse(r.url)
        title_element = _find_by_name_and_id(r.text, 'form', 'name', 'goWebSeal')
        if title_element is None:
            raise UnknownAuthType('Не удалось определить способ входа на стенд')
        
        login_action_postfix = title_element.attrs.get('action')
        login_url = '{scheme}://{netloc}{login_action_postfix}'.format(scheme=parsed_uri.scheme,
                                                                       netloc=parsed_uri.netloc,
                                                                       login_action_postfix=login_action_postfix)
        self._sudir_auth_common(domain, login_url, credentials, otp)

    def sudir_auth_ngam(self, domain: str, credentials: Credentials, otp: str):
        r = self.request_no_wrapper(method='get', endpoint='/')
        # Сделать авторизацию через NGAM.
        title_element = _find_by_name_and_id(r.text, 'form', 'id', 'loginForm')
        no_password = False
        if title_element is None:
            title_element = _find_by_name_and_id(r.text, 'form', 'id', 'sberotpForm') # new form
            no_password = True
            if title_element is None:
                if 'Учетная запись заблокирована' in r.text:
                    raise SudirAuthorizationError('Ваша учетная запись заблокирована. Обратитесь в техподдержку для разблокировки')
                raise UnknownAuthType('Не удалось определить способ входа на стенд')

        login_url = title_element.attrs.get('action')
        if no_password:
            self._sudir_auth_common_new_otp(login_url, credentials, otp)
        else:
            self._sudir_auth_common(domain, login_url, credentials, otp)

    def _sudir_auth_common_new_otp(self, login_url: str, credentials: Credentials, otp):
        if credentials is None:
            credentials = self._input_sudir_creds_no_pwd()
            self.login = credentials.login
        _otp = otp if otp is not None else getpass.getpass('Введите пароль из приложения OTP (6 цифр): ')  # ift 994306
        _data = {
            'enteredOTPCode': _otp,
            'formattedUsername': credentials.login
        }
        otp_response = self.external_request('post', login_url, data=_data, service_name=self.__class__.SERVICE_NAME)
        if otp_response is not None and otp_response.status_code == 200:
            error_element = _find_by_name_and_id(otp_response.text, 'div', 'class', 'message error')
            if error_element is not None:
                raise SudirAuthorizationError('Вы неверно ввели код OTP, попробуйте еще раз')
            else:
                self._after_sudir_login(otp_response.text, credentials.login)

    def _sudir_auth_common(self, domain: str, login_url: str, credentials: Credentials, otp):
        if credentials is None:
            credentials = self._input_sudir_creds()
            self.login = credentials.login

        self.__sudir_creds = {
            'isamoper': 'LOGIN',
            'domain': domain,
            'username': credentials.login,
            'password': credentials.password,
            'login-form-type': 'pwd',
            'operation': 'verify'
        }
        login_response = self.external_request('post', login_url, data=self.__sudir_creds,
                                               service_name=self.__class__.SERVICE_NAME)
        content = login_response.text
        otp_element = _find_by_name_and_id(content, 'form', 'id', 'sberotpForm')

        if otp_element is not None:
            _otp = otp if otp is not None else getpass.getpass('Введите пароль из приложения OTP (6 цифр): ')  # ift 994306
            otp_url = otp_element.attrs.get('action')
            otp_response = self.external_request('post', otp_url, data={'enteredOTPCode': _otp},
                                                 service_name=self.__class__.SERVICE_NAME)
            if otp_response is not None and otp_response.status_code == 200:
                error_element = _find_by_name_and_id(otp_response.text, 'div', 'class', 'message error')
                if error_element is not None:
                    raise SudirAuthorizationError('Вы неверно ввели код OTP, попробуйте еще раз')
                else:
                    self._after_sudir_login(otp_response.text, credentials.login)
        elif 'Учетная запись заблокирована' in content:
            raise SudirAuthorizationError('Ваша учетная запись заблокирована. Обратитесь в техподдержку для разблокировки')
        else:
            self._after_sudir_login(content, credentials.login)

    def _after_sudir_login(self, response, login):
        title_element = _find_by_name_and_id(response, 'title')
        if title_element is None:
            raise ServerError('Невозможно авторизоваться, вероятно не работает SberDS', '', '')
        if title_element.content == 'Developer helper':
            pass
        elif 'Your session in SUDIR by user' in response:
            pass
        elif _find_by_name_and_id(response, 'span', 'id', 'text_error') is not None:
            raise SudirAuthorizationError('Ошибка аутентификации в СУДИР')
        else:
            error_element = _find_by_name_and_id(response, 'div', 'class', 'message error')
            if error_element is not None:
                raise SudirAuthorizationError(error_element.content.strip())
            else:
                raise SudirAuthorizationError('Неизвестная ошибка авторизации в СУДИР')

        self.__sds_creds = {
            'grant_type': 'sudir',
            'username': '',
            'password': '',
            'client_id': 'frontend',
        }
        self._update_sds_token()
        print(f"{login} {FText.okgreen('успешно авторизован')}")

    def _update_sds_token(self):
        headers = {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Authorization': f"Basic {b64encode('frontend:secret'.encode()).decode()}"
        }
        try:
            response = self.request_no_wrapper(
                method='post',
                endpoint='/auth-server/oauth/token',
                headers=headers,
                data=self.__sds_creds
            )
        except BadRequestError as e:
            raise BadRequestError("Ошибка при авторизации, проверьте введенный логин и пароль",
                                  e.method, e.url)

        parsed_response = response.json()
        self.token = parsed_response['access_token']

    def __print_creds_error(self, e: SdsBaseError):
        print(f"Ошибка: {e.advice}\n")

    def __print_timeout_error(self):
        print(f"Ошибка: сервис не ответил на запрос вовремя\n")
        self.__print_advice()

    def __print_conn_reset_error(self):
        print(f"Ошибка: сервис сбросил соединение\n")
        self.__print_advice()

    def __print_ssl_version_error(self):
        print(f"При подключении к SberDS мы получили ошибку 'ssl.SSLError: [SSL: KRB5_S_TKT_NYV] unexpected eof while reading', "
              f"скорее всего это вызвано несоответствием версии питона и библиотеки SSL. Такие проблемы были замечены с python 3.7")
        print(f"Решение: Обновить питон до следующей версии (например python 3.8)")

    def __print_ssl_error(self):
        print(f"При подключении к SberDS мы получили ошибку вида 'ssl.SSLError'")
        print(
            f"Решение: Попробуйте подключиться еще раз, если проблема останется - обратитесь в поддержку:\n" + \
            f"{get_default_contacts_str()}"
        )

    def __print_bad_link_error(self):
        print(f"Ошибка: не удалось определить метод входа, возможно задана неверная ссылка\n")
        self.__print_advice()

    def __print_service_unavailable_error(self):
        print(f"Ошибка: сервис временно недоступен, возможно идут работы")
        print(f"Решение: Попробовать авторизоваться позже")

    def __print_connection_error(self, e: SdsBaseError):
        print(f"Ошибка: {e.message}\n")
        self.__print_advice()

    def __print_advice(self):
        print(f"Возможные причины:")
        print(f"1. Вы пытаетесь подключиться из другой сетевой зоны")
        print(f"2. Нет доступа к SberDS (нужно создать заявку)\n")
        print(f"Возможные решения:")
        alts = 0
        if self.alt_hosts and len(self.alt_hosts) > 0:
            alts = 1
            print(f"1. Можно попробовать подключиться к другим зонам используя команды")
            for alt_host in self.alt_hosts:
                print(f"auto_validator.authorize('{alt_host['key']}') # {alt_host['name']}")
        print(f"{1+alts}. Завести заявку на доступ. СберДруг->Универсальная заявка на доступ к АС. "
              f"В качестве АС указать 'ФП Помощник разработчика Sberbank Data Science (SberDS) ПРОМ'")
        print(f"{2 + alts}. Обратиться в поддержку (cсылка для сигма) "
              f"https://jira.sberbank.ru/secure/CreateIssueDetails!init.jspa?pid=175500&issuetype=3&%3A&priority=4&reporter=currentuser()&customfield_12111=275800&labels=2023Q4")
        contacts = f'\n     * '.join(get_default_contacts_str().split('\n'))
        print(
            f"{3 + alts}. Написать в поддержку:\n" +
            f"     * {contacts}")

    @property
    def session(self):
        return self._session


    @staticmethod
    def _input_creds() -> Credentials:
        login = input('Введите IPA логин: ')
        password = getpass.getpass('Введите пароль: ')
        return Credentials(login, password)

    @staticmethod
    def _input_sudir_creds() -> Credentials:
        login = input('Введите логин СУДИР: ')
        password = getpass.getpass('Введите пароль СУДИР: ')
        return Credentials(login, password)

    @staticmethod
    def _input_sudir_creds_no_pwd() -> Credentials:
        login = input('Введите логин СУДИР: ')
        return Credentials(login, None)
    
    @staticmethod
    def input_creds() -> Credentials:
        login = input(f'Введите логин: ')
        password = getpass.getpass(f'Введите пароль: ')
        return Credentials(login, password)


class _Element:
    def __init__(self, name: str, attrs: dict):
        self.name = name
        self.attrs = attrs
        self.content = ''


def _find_by_name_and_id(content, tag_name, attr_name=None,
                         attr_value=None) -> _Element:
    parser = _InternalParser(tag_name, attr_name, attr_value)
    parser.feed(content)
    if len(parser.found) > 0:
        return parser.found[0]
    else:
        return None


class _InternalParser(HTMLParser):
    def __init__(self, tag_name, attr_name, attr_value):
        super().__init__()
        self.tag_name = tag_name
        self.attr_name = attr_name
        self.attr_value = attr_value
        self.found = []
        self.save_immediate_data = False

    def handle_starttag(self, tag, attrs):
        self.save_immediate_data = False
        if tag != self.tag_name:
            return
        if self.attr_name is None:
            self.save_immediate_data = True
            self.found.append(_Element(tag, dict(attrs)))

        id_attr = next((x for x in attrs if x[0] == self.attr_name), None)
        if id_attr is not None and id_attr[1] == self.attr_value:
            self.save_immediate_data = True
            self.found.append(_Element(tag, dict(attrs)))

    def handle_endtag(self, tag: str) -> None:
        self.save_immediate_data = False

    def handle_data(self, data):
        if self.save_immediate_data:
            last_element = self.found[-1]
            last_element.content = data
            self.save_immediate_data = False