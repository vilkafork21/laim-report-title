from .kss_web_client import KssWebClient
from ..clui.utils import is_in_jupyter
from ..method.method_web_client import MethodWebClient
from ..util import print_table, SimpleTable, TableDisplayStyle, CellDisplayStyle
from ..utils.text import not_empty


class KssService:

    def __init__(self, host, session, token, is_internal=False):
        self._host = host
        self._session = session
        self._token = token
        self._client = KssWebClient(host, session, token, is_internal)
        self._method_client = MethodWebClient(host, session, token, is_internal)

    @property
    def valid_methods(self):
        return [
            item["methodName"] for item in self._method_client.get_methods(project_area_type="automodeling")
            if item.get("status") == "ACTIVE" and not item.get("isHidden", False)
        ]

    def get_kss_info(self, has_methods=True):
        # for ml tasks just plain table
        ml_tasks = self._client.get_ml_tasks(has_methods)
        ml_table = []
        for task in ml_tasks:
            ml_table.append([task.get('name', ''), task.get('id', '')])

        field_names = ['ML задача', 'ml_task']
        print("Список ML задач\n")
        if is_in_jupyter():
            self._to_html_table(ml_table, field_names)._ipython_display_()
        else:
            print_table(ml_table, field_names)

        # for subclasses we print one row per ml task for each subclass
        subclasses = self._client.get_business_task_subclasses(has_methods)
        business_table = []
        for subclass in subclasses:
            tasks = subclass.get('mlTasks', [])
            if len(tasks) == 0:
                business_table.append([subclass.get('name', ''), subclass.get('id', ''), ''])
            else:
                for task in tasks:
                    business_table.append([subclass.get('name', ''), subclass.get('id', ''), task.get('id', '')])

        field_names = ['Подкласс бизнес задач', 'business_task_subclass', 'ml_task']
        print("Список подклассов бизнес задач\n")
        if is_in_jupyter():
            self._to_html_table(business_table, field_names)._ipython_display_()
        else:
            print_table(business_table, field_names)

    def get_kss_pipelines(self, ml_task=None, business_task_subclass=None, device=None, has_methods=True, tags=None):
        hardware_solution = device
        if not_empty(hardware_solution) and hardware_solution.upper() not in ['CPU', 'GPU']:
            print(f"'device' должен быть пуст либо одно из ['CPU', 'GPU']")
            return
        if not_empty(business_task_subclass):
            use_subclasses = True
            pipelines = self._client.get_business_task_subclasses_pipelines(business_task_subclass, ml_task)
        elif not_empty(ml_task):
            use_subclasses = False
            pipelines = self._client.get_ml_task_pipelines(ml_task, hardware_solution=hardware_solution, tags=tags)
        else:
            print(f"Укажите хотя бы один из параметров 'ml_task' или 'business_task_subclass'")
            return

        if tags is not None and len(tags) > 20:
            print(f"Вы ввели слишком много тегов ({len(tags)}). Максимальное количество тегов: 20. " +
                  f"Уменьшите количество тегов. и повторите запрос")
            return

        table = []
        for pipeline in pipelines:
            if not use_subclasses:
                method_key = pipeline.get('methodKey', '')
                if method_key not in self.valid_methods:
                    continue
                if has_methods and (method_key is None or len(method_key) == 0):
                    continue
                table.append([pipeline.get('name', ''),
                              pipeline.get('globalRankPlace', ''), pipeline.get('globalRankValue', ''),
                              ml_task,
                              pipeline.get('methodKey', ''), pipeline.get('hardwareSolution', ''),
                              pipeline.get('kssCardUrl', ''), pipeline.get('shortDescription', ''),
                              pipeline.get('tags', '')])
            else:
                cur_task_name = pipeline.get('mlTask', '{}').get('name', '')
                cur_task_id = pipeline.get('mlTask', '{}').get('id', '')
                pips = pipeline.get('pipelines', '[]')
                for pip in pips:
                    method_key = pip.get('methodKey', '')
                    if has_methods and (method_key is None or len(method_key) == 0):
                        continue
                    table.append([cur_task_name,
                                  pip.get('globalRankPlace', ''), pip.get('globalRankValue', ''),
                                  cur_task_id,
                                  pip.get('methodKey', ''), pip.get('kssCardUrl', ''), pip.get('shortDescription', ''),
                                  pip.get('tags', '')])

        field_names = ['ML задача', 'Рейтинг (место)', 'Рейтинг (значение)', 'Название', 'method_key', 'Ссылка на KSS',
                       'Описание', 'Теги'] if use_subclasses \
            else ['ML задача', 'Рейтинг (место)', 'Рейтинг (значение)', 'Название', 'method_key', 'Аппаратное решение',
                  'Ссылка на KSS', 'Описание', 'Теги']

        print("Список доступных пайплайнов\n")
        if is_in_jupyter():
            self._to_html_table(table, field_names)._ipython_display_()
        else:
            print_table(table, field_names)

    def get_top_pipelines(self, ml_task, hardware_solution, tags):
        pipes = self._client.get_ml_task_pipelines(ml_task=ml_task, hardware_solution=hardware_solution, tags=tags)
        pipelines = {}
        for pipe in pipes:
            if pipe["methodKey"] is not None and pipe["methodKey"] in self.valid_methods:
                pipelines[pipe["methodKey"]] = pipe["globalRankPlace"]
        return list({k: v for k, v in sorted(pipelines.items(), key=lambda item: item[1])}.keys())

    def _to_html_table(self, table, fields) -> SimpleTable:
        return SimpleTable(table, fields, display_style=TableDisplayStyle(cell_style=CellDisplayStyle())) \
            .filter_empty() \
            .filter(keep_columns=[]) \
            .replace_empty(replacement='-')
