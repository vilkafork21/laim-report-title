import urllib.parse

from ..base_requester import BaseRequester
from ..util import convert_bool
from ..utils.retry import withretry
from ..utils.text import not_empty


class KssWebClient:
    _SERVICE_PATH = 'template-selector'
    _END_POINT = '/api/kss'

    def __init__(self, host, session, token, is_internal=False):
        self._requester = BaseRequester(host, session, service_name=self.__class__._SERVICE_PATH)
        self._is_internal = is_internal
        self._token = token

    @withretry()
    def get_ml_tasks(self, has_methods: bool):
        """
        Get ML tasks

        :return: ML tasks list
        """

        response = self._requester.request(
            method='get',
            endpoint=f"{self._base_path()}/ml-tasks?onlyWithLinkToPipelinesThatHasMethod={convert_bool(has_methods)}",
            headers=self._headers(self._token),
            timeout_seconds=60
        )
        return response.json()

    @withretry()
    def get_ml_task_pipelines(self, ml_task: str, hardware_solution: str = None, tags: list = None):
        """
        Get ML task pipelines

        :return: ML task pipelines
        """

        path = f"{self._base_path()}/ml-tasks/{ml_task}"

        params = {}
        if not_empty(hardware_solution):
            params['hardwareSolutionFilter'] = str(hardware_solution).upper()
        if tags is not None and len(tags) > 0:
            params['tagsFilter'] = ','.join(tags)
        if len(params) > 0:
            path += f'?{urllib.parse.urlencode(params)}'

        response = self._requester.request(
            method='get',
            endpoint=path,
            headers=self._headers(self._token),
            timeout_seconds=60
        )
        return response.json()

    @withretry()
    def get_business_task_subclasses(self, has_methods: bool):
        """
        Get business task subclasses

        :return: business task subclasses
        """

        response = self._requester.request(
            method='get',
            endpoint=f"{self._base_path()}/business-task-subclasses?onlyWithLinkToPipelinesThatHasMethod={convert_bool(has_methods)}",
            headers=self._headers(self._token),
            timeout_seconds=60
        )
        return response.json()

    @withretry()
    def get_business_task_subclasses_pipelines(self, business_task_subclass: str, ml_task=None):
        """
        Get business task subclasses pipelines

        :return: business task subclasses pipelines
        """

        url = f"{self._base_path()}/business-task-subclasses/{business_task_subclass}" if ml_task is None \
            else f"{self._base_path()}/business-task-subclasses/{business_task_subclass}?mlTask={ml_task}"

        response = self._requester.request(
            method='get',
            endpoint=url,
            headers=self._headers(self._token),
            timeout_seconds=60
        )
        return response.json()

    def _base_path(self):
        return self._SERVICE_PATH + self._END_POINT if not self._is_internal else self._END_POINT

    @staticmethod
    def _headers(token):
        return {
            'Authorization': f'Bearer {token}',
        }
