from urllib.parse import urljoin

from .exceptions.base import SberDSError
from .exceptions.exception_decorator import ExceptionLoggerConfig
from .exceptions.exceptions import *
from .exceptions.exceptions import ForbiddenError
from .rest_utils import DEFAULT_TIMEOUT_SECONDS, process_error_response


def common_http_retry_condition(e):
    return __exclude_exceptions_retry(e, [BadRequestError, ForbiddenError, UnauthorizedError, NotFoundError])


def custom_retry_condition(abort_on_exceptions=None):
    return lambda e: __exclude_exceptions_retry(e, abort_on_exceptions)


def __exclude_exceptions_retry(e, no_retry_exceptions):
    if no_retry_exceptions is None:
        no_retry_exceptions = []
    if not isinstance(no_retry_exceptions, list):
        no_retry_exceptions = [no_retry_exceptions]
    for exception_class in no_retry_exceptions:
        if isinstance(e, exception_class):
            return False
    return True


class BaseRequester:
    def __init__(self, host, session, service_name=None):
        self.host = BaseRequester.__improve_host(host)
        self._session = session
        self._service_name = service_name

    def request(self, method: str, endpoint: str = '', headers: dict = None,
                data=None, files=None, timeout_seconds=DEFAULT_TIMEOUT_SECONDS, need_process=True):

        try:
            return self.__request(method=method, endpoint=endpoint, headers=headers,
                                  data=data, files=files,
                                  timeout_seconds=timeout_seconds)
        except SberDSError as ex:
            if need_process:
                process_error_response(ex)
                if ExceptionLoggerConfig.RETHROW:
                    raise ex

    def request_no_wrapper(self, method: str, endpoint: str = '', headers: dict = None, data=None, files=None,
                           timeout_seconds=DEFAULT_TIMEOUT_SECONDS):
        return self.__request(method=method, endpoint=endpoint, headers=headers,
                              data=data, files=files,
                              timeout_seconds=timeout_seconds, )

    def __request(self, method: str, endpoint: str = '', headers: dict = None,
                  data=None, files=None, timeout_seconds=DEFAULT_TIMEOUT_SECONDS):

        url = urljoin(self.host, endpoint.lstrip('/'))
        resp = self._session.request(method, url, headers=headers, data=data,
                                     files=files,
                                     timeout_seconds=timeout_seconds,
                                     service_name=self._service_name)

        if 200 <= resp.status_code < 300:
            return resp
        elif resp.status_code == 401:
            raise UnauthorizedError(resp, method, url)
        elif resp.status_code == 403:
            raise ForbiddenError(resp, method, url)
        elif resp.status_code == 404:
            raise NotFoundError(resp, method, url)
        elif resp.status_code == 502:
            raise BadGatewayError(resp, method, url, service_name=self._service_name)
        elif resp.status_code == 503:
            raise ServiceUnavailableError(resp, method, url, service_name=self._service_name)
        elif 400 <= resp.status_code < 500:
            raise BadRequestError(resp, method, url)
        elif resp.status_code >= 500:
            raise ServerError(resp, method, url)
        else:
            raise UnknownError(resp, method, url)

    def external_request(self, method: str, url: str,
                         headers: dict = None,
                         data=None,
                         timeout_seconds=DEFAULT_TIMEOUT_SECONDS,
                         service_name=None):
        return self._session.request(method, url,
                                     headers=headers,
                                     data=data,
                                     timeout_seconds=timeout_seconds,
                                     service_name=service_name)

    @staticmethod
    def __improve_host(host: str):
        if host.endswith('/'):
            return host
        else:
            return host + '/'
