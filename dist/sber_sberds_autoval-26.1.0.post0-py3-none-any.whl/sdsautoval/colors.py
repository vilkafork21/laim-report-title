class Colors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    YELLOW = '\033[93m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'
    IS_ENABLED = True

    @classmethod
    def disable(cls):
        cls.HEADER = ''
        cls.OKBLUE = ''
        cls.OKCYAN = ''
        cls.OKGREEN = ''
        cls.YELLOW = ''
        cls.WARNING = ''
        cls.FAIL = ''
        cls.ENDC = ''
        cls.BOLD = ''
        cls.UNDERLINE = ''
        cls.IS_ENABLED = False

    @classmethod
    def enable(cls):
        cls.HEADER = '\033[95m'
        cls.OKBLUE = '\033[94m'
        cls.OKCYAN = '\033[96m'
        cls.OKGREEN = '\033[92m'
        cls.YELLOW = '\033[93m'
        cls.WARNING = '\033[93m'
        cls.FAIL = '\033[91m'
        cls.ENDC = '\033[0m'
        cls.BOLD = '\033[1m'
        cls.UNDERLINE = '\033[4m'
        cls.IS_ENABLED = True

    @classmethod
    def remove(cls, string):
        if cls.IS_ENABLED:
            string = string.replace(f'{cls.HEADER}', '')
            string = string.replace(f'{cls.OKBLUE}', '')
            string = string.replace(f'{cls.OKCYAN}', '')
            string = string.replace(f'{cls.OKGREEN}', '')
            string = string.replace(f'{cls.WARNING}', '')
            string = string.replace(f'{cls.FAIL}', '')
            string = string.replace(f'{cls.ENDC}', '')
            string = string.replace(f'{cls.BOLD}', '')
            string = string.replace(f'{cls.UNDERLINE}', '')
        return string


class FText:
    @classmethod
    def colored(cls, color, txt):
        return f'{color}{txt}{Colors.ENDC}'

    @classmethod
    def yellow(cls, txt):
        return cls.colored(Colors.YELLOW, txt)

    @classmethod
    def okgreen(cls, txt):
        return cls.colored(Colors.OKGREEN, txt)

    @classmethod
    def bold(cls, txt):
        return cls.colored(Colors.BOLD, txt)
