import sys


def is_in_unit_test():
    return 'unittest' in sys.modules.keys() or 'pytest' in sys.modules.keys()
