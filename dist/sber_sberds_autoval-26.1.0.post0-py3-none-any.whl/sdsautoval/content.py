def tuple_list_to_dict(lst):
    dct = dict()
    for key, value in lst:
        if value:
            dct[key] = value
    return dct


class Content:
    def __init__(self,
                 job_id=None,
                 run_id=None,
                 model_version_id=None,
                 project_url=None,
                 report_url=None,
                 main_traffic_light=None,
                 results=None,
                 status=None,
                 method_key=None):
        self.model_version_id = model_version_id
        self.project_url = project_url
        self.report_url = report_url
        self.main_traffic_light = main_traffic_light
        self.results = results
        self.status = status
        self.method_key = method_key
        self.job_id = job_id
        self.run_id = run_id

    def to_dict(self):
        return tuple_list_to_dict(self.tuple_list())

    def tuple_list(self):
        return [
            ('job_id', self.job_id),
            ('run_id', self.run_id),
            ('model_version_id', self.model_version_id),
            ('project_url', self.project_url),
            ('report_url', self.report_url),
            ('main_traffic_light', self.main_traffic_light),
            ('results', self.results),
            ('status', self.status),
            ('method_key', self.method_key),
        ]

    @property
    def dict(self):
        return self.to_dict()

    def __getitem__(self, key):
        return getattr(self, key)

    def __repr__(self):
        return self.dict.__str__()


class AVContent(Content):
    def __init__(self,
                 prevalidation_id=None,
                 run_id=None,
                 model_version_id=None,
                 project_url=None,
                 report_url=None,
                 main_traffic_light=None,
                 results=None,
                 status=None,
                 method_key=None):
        super().__init__(job_id=prevalidation_id,
                         run_id=run_id,
                         model_version_id=model_version_id,
                         project_url=project_url,
                         report_url=report_url,
                         main_traffic_light=main_traffic_light,
                         results=results,
                         status=status,
                         method_key=method_key)
        self.prevalidation_id = prevalidation_id

    def tuple_list(self):
        tuple_list = super().tuple_list()
        tuple_list.append(('prevalidation_id', self.prevalidation_id))
        return tuple_list


class ABContent(Content):
    def __init__(self,
                 fin_effect_id=None,
                 run_id=None,
                 model_version_id=None,
                 project_url=None,
                 report_url=None,
                 main_traffic_light=None,
                 results=None,
                 status=None,
                 method_key=None):
        super().__init__(job_id=fin_effect_id,
                         run_id=run_id,
                         model_version_id=model_version_id,
                         project_url=project_url,
                         report_url=report_url,
                         main_traffic_light=main_traffic_light,
                         results=results,
                         status=status,
                         method_key=method_key)
        self.fin_effect_id = fin_effect_id

    def tuple_list(self):
        tuple_list = super().tuple_list()
        tuple_list.append(('fin_effect_id', self.fin_effect_id))
        return tuple_list


class ContentKeeper:

    def __init__(self, session=None):
        self.method_key = None
        self.prevalidation = None
        self._prevalidation_run = None
        self.session = session

    def content(self):
        prevalidation_id = None
        run_id = None
        version_id = None
        project_link = None
        report_link = None
        main_traffic_light = None
        results = None
        status = None
        if self.prevalidation:
            prevalidation_id = self.prevalidation.prevalidation_id
            version_id = self.prevalidation.get_model_version_id()
            project_link = self.prevalidation.get_project_link()
            report_link = self.prevalidation.get_report_link()
            main_traffic_light = self.prevalidation.get_main_traffic_light()
            results = self.prevalidation.get_main_traffic_light_info()
            status = self.prevalidation.get_status()
        if self._prevalidation_run:
            run_id = self._prevalidation_run.run_id
        if self.session.prevalidation_id_name() == 'prevalidation_id':
            return AVContent(
                prevalidation_id=prevalidation_id,
                run_id=run_id,
                model_version_id=version_id,
                project_url=project_link,
                report_url=report_link,
                main_traffic_light=main_traffic_light,
                results=results,
                status=status,
                method_key=self.method_key
            )
        elif self.session.prevalidation_id_name() == 'fin_effect_id':
            return ABContent(
                fin_effect_id=prevalidation_id,
                run_id=run_id,
                model_version_id=version_id,
                project_url=project_link,
                report_url=report_link,
                main_traffic_light=main_traffic_light,
                results=results,
                status=status,
                method_key=self.method_key
            )
        else:
            return Content(
                job_id=prevalidation_id,
                run_id=run_id,
                model_version_id=version_id,
                project_url=project_link,
                report_url=report_link,
                main_traffic_light=main_traffic_light,
                results=results,
                status=status,
                method_key=self.method_key
            )

    def update(self, prevalidation=None, keep_prevalidation=False, method_key=None, keep_method_key=False, run=None, keep_run=False):
        if not keep_method_key:
            self.method_key = method_key
        if not keep_prevalidation:
            self.prevalidation = prevalidation
        if not keep_run:
            self._prevalidation_run = run
