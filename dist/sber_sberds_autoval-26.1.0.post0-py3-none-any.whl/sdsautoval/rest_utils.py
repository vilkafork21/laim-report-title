import errno
import json
import ssl
import urllib
import uuid
from http.client import HTTPResponse
from http.client import responses as responses_description
from http.cookiejar import CookieJar, Cookie
from json import JSONDecodeError
from socket import timeout
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, build_opener, HTTPCookieProcessor

from sdsautoval.context.constants import AUTOVALIDATION_MAIL
from sdsautoval.context.constants import SBERDS_MAIL
from .exceptions.base import SberDSError
from .exceptions.exceptions import *
from .exceptions.sds_exceptions import *

DEFAULT_TIMEOUT_SECONDS = 15


class UserSession:
    def __init__(self, host, session, token):
        self.host = host
        self.session = session
        self.token = token
        self.instance = ''


class SimpleResponse:
    debug = False

    def __init__(self, resp: HTTPResponse):
        try:
            self.url = resp.geturl()
            self.text = str(resp.read(), "utf-8")
            self.status_code = resp.getcode()
            self.headers = resp.getheaders()
            self.reason = resp.reason
            if SimpleResponse.debug:
                print(f'{self.status_code} {self.text}')
        finally:
            resp.close()

    def is_ok(self):
        return 200 <= self.status_code < 300

    def json(self):
        return json.loads(self.text)


class SimpleResponseError:
    debug = False

    def __init__(self, url, text, status_code):
        self.url = url
        self.text = str(text)
        self.status_code = status_code
        if SimpleResponseError.debug:
            print(f'{self.status_code} {self.text}')

    def json(self):
        return json.loads(self.text)


class SimpleSession:
    def __init__(self, verify: bool = False):
        self.headers = {
            'Accept': '*/*',
            'Connection': 'keep-alive'
        }
        self._zone = None
        # Сохранять куки.
        self.cookies = CookieJar()
        # Создать объект для запросов в рамках сессии.
        self.opener = self._make_opener(self.cookies, verify)

    def set_zone(self, zone: str):
        self._zone = zone
        c = Cookie(0, 'sberds_zone', self._zone, None, False, '',
                   False, False, '/', True,
                   False, None, False, None, None, {})
        self.cookies.set_cookie(c)

    def set_qa_mode(self):
        c = Cookie(0, 'SDS_VERSION', 'NEXT', None, False, '',
                   False, False, '/', True,
                   False, None, False, None, None, {})
        self.cookies.set_cookie(c)

    def unset_qa_mode(self):
        c = Cookie(0, 'SDS_VERSION', 'CURRENT', None, False, '',
                   False, False, '/', True,
                   False, None, False, None, None, {})
        self.cookies.set_cookie(c)

    def request(self, method, url,
                headers=None,
                data='',
                files=None,
                timeout_seconds=DEFAULT_TIMEOUT_SECONDS,
                service_name=None):
        """
        Делает запрос к серверу в рамках одной сессии с сохранением cookie

        Parameters
        ----------
        method: str
            метод запроса GET, POST, PUT
        url: str
            URL запроса
        headers: str
            Заголовки
        data
            Полезная нагрузка для форматов x-www-form-urlencoded или json.
            Для формата x-www-form-urlencoded ожидается dict
            Для формата json ожидается сериализованная строка
        files: dict|None
            Полезная нагрузка для для mulitpart-form-data. Ожидается dict вида:
            name -> (filename, strcontent, contenttype)
        timeout_seconds:
            Время ожидания ответа сервера (в секундах)
        service_name:
            Имя сервиса, к которому осуществляется запрос
        """
        real_method = method.upper()
        real_headers = self.headers.copy()
        if headers is not None:
            real_headers.update(headers)

        if SimpleResponse.debug:
            print(f'{method.upper()} {url} {data if data is not None else ""}')
            print(f'Cookie: {self.cookies}')
        if real_method == 'POST' or real_method == 'PUT':
            content_type = real_headers.get('Content-Type')
            if real_headers.get('Content-Type') is None:
                real_headers['Content-Type'] = content_type = \
                    'application/x-www-form-urlencoded'
            if files is not None:
                real_data = \
                    SimpleSession._prepare_multipart(real_headers, files)
            elif data is not None:
                if content_type.lower() == 'application/x-www-form-urlencoded':
                    real_data = urlencode(data).encode("utf-8")
                elif content_type.lower() == 'application/json':
                    real_data = data.encode("utf-8")
                elif content_type.lower() == 'application/binary':
                    real_data = data
                else:
                    raise KeyError('unknown content_type=' + content_type)
            else:
                real_data = b''
        else:
            real_data = None

        req = Request(
            url,
            headers=real_headers,
            method=real_method,
            data=real_data
        )

        try:
            response = self.opener.open(req, timeout=timeout_seconds)
            return SimpleResponse(response)
        except HTTPError as err:
            return SimpleResponse(err)
        except URLError as err:
            if err.reason and err.reason.errno:
                if isinstance(err.reason, timeout):
                    raise TimeOutError("Connection Timeout")
                if err.reason.errno == errno.ENOEXEC:  # wrong url
                    return SimpleResponseError(url, err.reason, 404)
                if err.reason.errno == errno.ECONNRESET:  # another reset by peer
                    raise ConnResetError("Connection reset by peer")
                if 'SSL: CERTIFICATE_VERIFY_FAILED' in str(err.reason):
                    raise SSLError(err.reason, service_name=service_name)
            return SimpleResponseError(url, err.__repr__(), 500)
        except ConnectionResetError:
            raise ConnResetError("Connection reset by peer", service_name=service_name)
        except timeout:
            raise TimeOutError("Connection Timeout", service_name=service_name)
        except ssl.SSLEOFError:
            raise SSLEOFError("SSL EOF read error", service_name=service_name)
        except ssl.SSLError as err:
            if 'KRB5_S_TKT_NYV' in str(err):
                print(err)
                raise SSLVersionError("SSL read error", service_name=service_name)
            else:
                print(err)
                raise SSLError("SSL read error", service_name=service_name)

    @staticmethod
    def _prepare_multipart(headers: dict, files: dict) -> bytes:
        boundary = f'BOUNDARY----{uuid.uuid4()}----'
        headers['Content-Type'] = f'multipart/form-data; boundary={boundary}'
        lines = []

        for name, rec in files.items():
            filename, content, content_type = rec
            disposition = f'Content-Disposition: form-data; name="{name}";'
            if filename is not None:
                disposition += f' filename="{filename}"'
            lines.extend((
                f'--{boundary}',
                disposition,
                f'Content-Type: {content_type}',
                '',
                content,
            ))

        lines.extend((
            f'--{boundary}--',
            '',
        ))
        body = '\r\n'.join(lines)
        return body.encode("utf-8")


    @staticmethod
    def _make_opener(cookie_jar: CookieJar, verify: bool) -> urllib.request.OpenerDirector:
        """
        Создаёт объект для запросов в рамках сессии.
        """
        ssl_context = ssl.create_default_context()
        if not verify:
            ssl_context.check_hostname = False
            ssl_context.verify_mode = ssl.CERT_NONE

        https_handler = urllib.request.HTTPSHandler(context=ssl_context)

        # Сохранять cookie.
        cookie_processor = HTTPCookieProcessor(cookie_jar)
        opener = build_opener(https_handler, cookie_processor)
        return opener


def process_error_response(ex: SberDSError):
    try:
        __process_error_response_base(ex)
        __process_error_response_with_json(ex)
        __process_error_response_without_json(ex)
    except (JSONDecodeError, TypeError) as _:
        __process_error_response_without_json(ex)


def __process_error_response_base(ex: SberDSError):
    if isinstance(ex, ServiceUnavailableError):
        raise SdsServiceUnavailableError(ex)
    if isinstance(ex, BadGatewayError):
        raise SdsBadGatewayError(ex)
    if isinstance(ex, ConnResetError):
        raise SdsConnResetError(ex)
    if isinstance(ex, TimeOutError):
        raise SdsTimeOutError(ex)
    if isinstance(ex, SSLVersionError):
        raise SdsSSLError(ex)
    if isinstance(ex, SSLError):
        raise SdsSSLError(ex)
    if isinstance(ex, SSLEOFError):
        raise SdsSSLError(ex)
    elif isinstance(ex, UnauthorizedError):
        raise SdsNotAuthorizedError()

def __process_error_response_with_json(ex: SberDSError):
    _json = ex.response.json()
    # 1. check if server returned sds error specific data in headers-body format
    if _json and isinstance(_json, dict) and 'body' in _json:
        _json = _json['body']
    # 2. check if server returned sds error specific data in sds-commons format
    if _json and isinstance(_json, dict) and 'error' in _json:
        _json = _json['error']
    # 3. check if server returned sds error specific data
    if _json and isinstance(_json, dict) and 'code' in _json:
        raise SdsBaseError(_json.get('code', 'none'),
                           _json.get('header', 'none'),
                           _json.get('message', 'none'),
                           _json.get('solutionAdvice', 'none'))


def __process_error_response_without_json(ex: SberDSError):
    method = 'неизвестного типа'
    url = 'неизвестный URL'
    text = ex.response.text
    status_code = None

    if ex.response and ex.response.status_code:
        status_code = ex.response.status_code
    if ex.method and len(ex.method) > 0:
        method = ex.method.upper()
    if ex.url:
        url = ex.url

    message = describe_http_status(status_code) + " при запросе " + method + " на " + url + "."
    if text is not None and len(text) > 0:
        message += f" Детали: {text}"
    advice = f"Попробуйте снова. Если проблема остается - свяжитесь с командой поддержки: {SBERDS_MAIL} или {AUTOVALIDATION_MAIL}"

    if 400 <= status_code < 500:
        raise SdsBaseError("SDS-004", "system_error", message,
                           f"Проверьте параметры вызова. Если проблема остается - свяжитесь с командой поддержки: {SBERDS_MAIL} или {AUTOVALIDATION_MAIL}")
    elif 500 <= status_code:
        raise SdsBaseError("SDS-004", "system_error", message, advice)
    else:
        raise SdsBaseError("SDS-004", "system_error", message, advice)


def describe_http_status(status_code):
    return "HTTP " + str(status_code) + ": " + responses_description[status_code]
