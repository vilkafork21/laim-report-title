from sdsautoval.clui.utils import is_in_jupyter
from sdsautoval.colors import FText
from sdsautoval.context.constants import SBERDS_MAIL, AUTOVALIDATION_MAIL, \
    AUTOVALIDATION_MAIL_, SBERDS_MAIL_
from sdsautoval.context.user_context import UserContext
from sdsautoval.utils.misc import get_default_contacts_str

# Ошибки БМ
USER_NOT_FOUND_IN_US = 'Вам требуется получить доступ в Библиотеку моделей с ролью «Разработчик моделей (Data Scientist)» и попросить вашего Teamlead указать вас в качестве разработчика в версии модели в БМ, в которую вы пытаетесь опубликовать результаты превалидации.'
USER_NOT_FOUND_IN_CORE = 'Вам требуется получить доступ в Библиотеку моделей с ролью «Разработчик моделей (Data Scientist)» и попросить вашего Teamlead указать вас в качестве разработчика в версии модели в БМ, в которую вы пытаетесь опубликовать результаты превалидации.'
USER_NOT_ACTIVE = 'Вам требуется получить доступ в Библиотеку моделей с ролью «Разработчик моделей (Data Scientist)» оформив заявку в Друге на доступ к "АС Sberbank Data Science (среда ЛД)".'
USER_NO_ROLE = 'Вам требуется получить доступ в Библиотеку моделей с ролью «Разработчик моделей (Data Scientist)» оформив заявку в Друге на доступ к "АС Sberbank Data Science (среда ЛД)".'
USER_NO_ACCESS = 'Попросите своего Team Lead добавить вас в команду разработки версии модели или обратитесь в службу поддержки через метод auto_validator.report_issue или на почту sberds@omega.sbrf.ru '
INVALID_STATE = 'Для публикации превалидации в Библиотеку моделей, переведите версию модели в статус "Разработка".'
INVALID_REQUEST_BAD_TASK_TYPE = 'не найден в справочнике Типов задач в Библиотеке моделей'
INVALID_REQUEST_BAD_TYPE_DATA = 'не найден в справочнике Типов данных в Библиотеке моделей'
INVALID_REQUEST = 'Некорректный формат публикуемых результатов превалидации'

BM_ERRORS = [
    USER_NOT_FOUND_IN_US,
    USER_NOT_FOUND_IN_CORE,
    USER_NOT_ACTIVE,
    USER_NO_ROLE,
    USER_NO_ACCESS,
    INVALID_STATE,
    INVALID_REQUEST_BAD_TASK_TYPE,
    INVALID_REQUEST_BAD_TYPE_DATA,
    INVALID_REQUEST,
]

def translate_category(category):
    if category == "USER":
        return 'Пользовательская ошибка'
    if category == "INFRA":
        return 'Инфраструктурная ошибка'
    if category == "PLATFORM":
        return 'Платформенная ошибка'
    return category

def format_error_for_contacts(message, advice, separator="\n"):
    return f'{FText.yellow("Message:")} {message}{separator}' + \
        f'{FText.yellow("Solution advice:")} {advice}'


def format_error_with_header(category, header, message, advice, separator="\n"):
    # return (f"{FText.bold(f'{translate_category(category)}: {header}')}{separator}{message_and_advice}")
    message_and_advice = format_error(message, advice, separator=separator)
    return message_and_advice


def format_node_details(node_name, node_id, settings):
    return f"Node Details: Name={node_name}, Id={node_id}, settings={settings}"


def format_node_error_(category, header, message, advice, node_name, node_id, settings, separator="\n"):
    return (f'{format_error_with_header(category, header, message, advice, separator=separator)}{separator}'
            f'{format_node_details(node_name, node_id, settings)}')


def should_add_av_contacts(advice):
    if isinstance(advice, str):
        for bm_error in BM_ERRORS:
            if bm_error in advice:
                return False
    return True


def fix_advice(advice):
    if advice == 'Please try again. Please contact support team if issue remains.':
        return f'Попробуйте снова. Если проблема не решится, то обратитесь в поддержку:\n{get_default_contacts_str()}'
    if isinstance(advice, str) and \
            not (SBERDS_MAIL in advice or SBERDS_MAIL_ in advice) and \
            not (AUTOVALIDATION_MAIL in advice or AUTOVALIDATION_MAIL_ in advice)\
            and should_add_av_contacts(advice):
        return f'{advice}\nКонтакты поддержки: {get_default_contacts_str()}'
    return advice


def format_error(message, advice, separator="\n"):
    advice = fix_advice(advice)
    return f'{FText.yellow("Message:")} {message}{separator}' + \
        f'{FText.yellow("Solution advice:")} {advice}'


def format_node_error(error, advice_override=None, separator='\n'):
    advice = error.get('solutionAdvice', 'None')
    if advice_override:
        advice = advice_override
    return format_node_error_(error['category'],
                              error['header'],
                              error['message'],
                              advice,
                              error['nodeName'],
                              error['nodeId'],
                              error['settings'],
                              separator=separator)
def log_error_with_contact_if_present(message: str):
    if is_in_jupyter():
        from .contact_util import ContactsSimple
        service_contact = ContactsSimple.parse(message)
        if service_contact:
            print(service_contact.advice_before_contacts(message))
            service_contact.ipython_display()
            print(service_contact.advice_after_contacts(message))
            return
    print(message)


def get_event_service():
    return UserContext.get().event_service
