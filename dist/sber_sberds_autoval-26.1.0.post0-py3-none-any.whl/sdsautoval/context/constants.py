AUTOVALIDATION_MAIL = 'mailto:AutoValidation@sberbank.ru'
AUTOVALIDATION_MAIL_ = 'mailto: AutoValidation@sberbank.ru'
SBERDS_MAIL = 'mailto:sberds@omega.sbrf.ru'
SBERDS_MAIL_ = 'mailto: sberds@omega.sbrf.ru'
_HOST_MAPPING: dict = {
    'lab': {'url': 'https://df-office.sberds.omega.sbrf.ru/de',
            'name': 'SberDS Лабораторная зона (ВАРМ ЛД, офис)'},
    'alpha': {'url': 'https://office.sberds.omega.sbrf.ru/de',
              'name': 'SberDS Домен Alpha/Omega (офис)'},

    'lab_ift': {
        'url': 'https://iamproxy-dfcrit.apps.ift-terra000023-eds.ocp.delta.sbrf.ru/ift2/',
        'name': 'SberDS Лабораторная зона IFT (офис)'},
    'alpha_ift': {
        'url': 'https://iamproxy-ift.apps.ift-gen1-dm.delta.sbrf.ru/ift2',
        'name': 'Домен Alpha/Omega IFT (офис)'},

    'st1': {
        'url': 'https://sds-front-ci02132621-delta-dh-st-1.apps.dev-terra000005-ids.ocp.delta.sbrf.ru/',
        'name': 'ST1'},
    'dev12': {
        'url': 'https://sds-front-ci02132621-sds-dev12.apps.dev-terra000005-ids.ocp.delta.sbrf.ru',
        'name': 'Dev12'},
    'dev13': {
        'url': 'https://sds-front-ci02132621-delta-sds-dev13.apps.dev-terra000005-ids.ocp.delta.sbrf.ru',
        'name': 'Dev13'}
}

_HOSTS: dict = {
    'prom': {'main': 'lab', 'additional': ['alpha']},
    'ift': {'main': 'lab_ift', 'additional': ['alpha_ift']},
    'dev': {'main': 'dev10', 'additional': ['dev12', 'dev13']}
}

_PROM_HOSTS: list = ['prom', 'lab', 'alpha']

STATUS_SUBMITTED = 'SUBMITTED'
STATUS_WORK_STARTED = 'WORK_STARTED'
STATUS_REQUEST_VERIFIED = 'REQUEST_VERIFIED'
STATUS_DATA_VERIFIED = 'DATA_VERIFIED'
STATUS_PROJECT_CREATED = 'PROJECT_CREATED'
STATUS_SETTINGS_APPLIED = 'SETTINGS_APPLIED'
STATUS_PROJECT_STARTED = 'PROJECT_STARTED'

REQUEST_STATUS_LIST = [
    STATUS_SUBMITTED,
    STATUS_WORK_STARTED,
    STATUS_REQUEST_VERIFIED,
    STATUS_DATA_VERIFIED,
    STATUS_PROJECT_CREATED,
    STATUS_SETTINGS_APPLIED,
    STATUS_PROJECT_STARTED
]

DEFAULT_SERVICE_CONTACTS = \
    {
        'responsibleUsers': [],
        'service':
            [
                {
                    "name": "service-contact",
                    "email": f"{'sberds@omega.sbrf.ru'}",
                    "description": "Поддержка SberDS"
                },
                {
                    "name": "autoval-contact",
                    "email": f"{'AutoValidation@sberbank.ru'}",
                    "description": "Поддержка сервиса Автовалидации"
                }
            ]
    }
