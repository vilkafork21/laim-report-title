from sdsautoval.context.constants import _PROM_HOSTS
from sdsautoval.utils.conjugating_word import DummyConjugatingWord


class UserContext:
    """ User context.

    Attributes:
       version        sdk version
       current_method current_method
       last_run       user last prevalidation run details
       last_error     last error details
       last_env       last environment the user logged in to
    """
    INSTANCE = None

    def __init__(self):
        self.version = None
        self.current_method = None
        self.last_run = None
        self.last_error = None
        self.last_env = None
        self.internal_auth = False
        self.short_host = False
        self.job_name = DummyConjugatingWord('None')

    @staticmethod
    def get():
        return UserContext.INSTANCE

    def should_substitute_host(self):
        return self.internal_auth or self.short_host

    def last_env_is_prom(self):
        return self.last_env in _PROM_HOSTS

    def last_env_is_lab_ift(self):
        return self.last_env in ['SDP-19115654-ipa-sds-ift-sdp-hadoop-1-0cd162', 'lab_ift']

    def auth_method(self):
        if self.internal_auth:
            return 'internal'
        else:
            return 'regular'

    @staticmethod
    def static_init():
        if UserContext.get() is None:
            UserContext.create()

    @staticmethod
    def create():
        UserContext.INSTANCE = UserContext()

    @staticmethod
    def backup():
        instance = UserContext.INSTANCE
        UserContext.get().create()
        return instance

    @staticmethod
    def restore(user_context):
        UserContext.INSTANCE = user_context


UserContext.static_init()


class LastRun:
    """ Last prevalidation run details.

    Attributes:
       timestamp         run time
       prevalidation_id  prevalidation ID of run
       model_version_id  model version ID used for run
       samples           samples json
       settings          settings json
       resources         docker custom resources if any
    """

    def __init__(self, timestamp, prevalidation_id, model_version_id, samples,
                 settings, resources):
        self.timestamp = timestamp
        self.prevalidation_id = prevalidation_id
        self.model_version_id = model_version_id
        self.samples = samples
        self.settings = settings
        self.resources = resources


class LastError:
    """ Last error details.

    Attributes:
       timestamp         error time
       code              error SDS code
       header            error header
       message           error message
       advice            error solution advice
    """

    def __init__(self, timestamp, code, header, message, advice):
        self.timestamp = timestamp
        self.code = code
        self.header = header
        self.message = message
        self.advice = advice
