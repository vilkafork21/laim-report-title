from sdsautoval.context.constants import REQUEST_STATUS_LIST, SBERDS_MAIL, AUTOVALIDATION_MAIL, DEFAULT_SERVICE_CONTACTS
from sdsautoval.utils.stream import stream


def pre_validation_status_order(status):
    if status is None:
        return -2
    if len(status) == 0:
        return -1
    for i in range(0, len(REQUEST_STATUS_LIST)):
        if status == REQUEST_STATUS_LIST[i]:
            return i
    return len(REQUEST_STATUS_LIST) + 100


def get_service_contacts(method):
    return get_service_contacts_key('service', 'service', method)


def get_service_contacts_publish(method):
    return get_service_contacts_key('service', 'serviceContacts', method)


def get_responsible_users(method):
    return get_service_contacts_key('responsibleUsers', 'service', method)


def get_responsible_users_publish(method):
    return get_service_contacts_key('responsibleUsers', 'serviceContacts', method)


def get_service_contacts_key(key, key2, method):
    service_contacts_array = method.get(key2, [])
    if len(service_contacts_array) > 0:
        res = []
        for service_contacts_array_item in service_contacts_array:
            subarray = service_contacts_array_item.get(key, [])
            for item in subarray:
                if item not in res:
                    res.append(item)
        return res
    return []


def format_service_contacts(service_contacts):
    return stream(service_contacts).map(
        lambda x: str(str(x.get('description', x.get('serviceName', '???'))) + ': mailto:' + str(x.get('email', '???')))
    ).collect(list)


def format_responsible_users(service_contacts):
    return stream(service_contacts).map(
        lambda x: str(str(x.get('fullName', '???')) + ': mailto:' + str(x.get('email', '???')))
    ).collect(list)


def get_service_contacts_all_formatted(contacts):
    service_contacts = format_service_contacts(contacts.get('service', []))
    responsible_users = format_responsible_users(contacts.get('responsibleUsers', []))
    return '\n'.join(service_contacts + responsible_users)


def get_default_contacts_str():
    return get_contacts_str(DEFAULT_SERVICE_CONTACTS)


def get_contacts_str(contacts):
    if contacts:
        contacts_key = get_service_contacts_all_formatted(contacts)
        if contacts_key:
            return contacts_key
    return f'{SBERDS_MAIL} или {AUTOVALIDATION_MAIL}'
