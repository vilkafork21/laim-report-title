def is_dict_with_elements(some_dict):
    return some_dict and isinstance(some_dict, dict) and len(some_dict) > 0


def kwargs_get(kwargs, key, default):
    value = default
    if is_dict_with_elements(kwargs):
        value = kwargs.get(key, value)
    return value
