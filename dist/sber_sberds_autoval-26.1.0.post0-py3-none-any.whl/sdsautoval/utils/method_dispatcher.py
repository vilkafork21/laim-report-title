import functools
import inspect


# noinspection PyPep8Naming
class any_type:
    # Технический класс для обозначения любого типа
    pass


# noinspection PyPep8Naming
class etc:
    # Технический класс для обозначения любого типа всех последующих аргументов
    pass


def args_matches(args_types, *args):
    if args_types is None:
        return True
    for i in range(len(args_types)):
        if i >= len(args):
            return False
        expected_type = args_types[i]
        if expected_type == etc:
            return True
        if expected_type == any_type:
            continue
        real_type = type(args[i])
        if real_type != expected_type:
            return False
    return True


def kwargs_matches(kwargs_types, **kwargs):
    if kwargs_types is None:
        return True
    for key in kwargs_types.keys():
        if key not in kwargs.keys():
            return False
        expected_type = kwargs_types[key]
        if expected_type == etc:
            return True
        if expected_type == any_type:
            continue
        real_type = type(kwargs[key])
        if real_type != expected_type:
            return False
    return True


def args_and_kwargs_matches(args_types, kwargs_types, *args, **kwargs):
    return args_matches(args_types, *args) and kwargs_matches(kwargs_types, **kwargs)


def get_replacement_func(self, replacement_func_ref):
    if callable(replacement_func_ref):
        return replacement_func_ref
    if isinstance(replacement_func_ref, str):
        replacement_func_candidate = getattr(self, replacement_func_ref)
        return get_replacement_func(self, replacement_func_candidate)
    raise ValueError("No such method/function: " + str(replacement_func_ref))


def method_dispatch(replacement_func_ref, args_types: list = None, kwargs_types: dict = None):
    def dispatcher(func):
        """
        Decorator that handles SdsBaseError in func, prints it as well and rethrow it.
        Used in case whole function could be wrapped. Should be on top of decorator list.

        :param func: function
        :return: result
        """

        @functools.wraps(func)
        def wrapper_decorator(_self, *args, **kwargs):
            replacement_func = get_replacement_func(_self, replacement_func_ref)
            if args_and_kwargs_matches(args_types, kwargs_types, *args, **kwargs):
                if inspect.ismethod(replacement_func):
                    replacement_func(*args, **kwargs)
                else:
                    replacement_func(_self, *args, **kwargs)
            else:
                return func(_self, *args, **kwargs)

        return wrapper_decorator

    return dispatcher
