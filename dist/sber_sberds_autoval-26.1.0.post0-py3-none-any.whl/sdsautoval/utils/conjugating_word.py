def capitalize_first(word):
    return word[0].upper() + word[1:]


class ConjugatingWord:

    def get(self, version=0, capital=False, plural=False, synonym_index: int = 0) -> str:
        # this is just an interface
        pass

    def __str__(self):
        return self.get(0, False)


class SimpleConjugatingWord(ConjugatingWord):
    def __init__(self, versions: dict):
        self.versions = versions

    def get(self, version=0, capital=False, plural=False, synonym_index: int = 0) -> str:
        index = 0
        if plural:
            index = 1
        word = self.versions[version][index]
        if capital:
            word = capitalize_first(word)
        return word

    def __str__(self):
        return self.get(0, False)


class DummyConjugatingWord(ConjugatingWord):
    def __init__(self, word: str):
        self.word = word

    def get(self, version=0, capital=False, plural=False, synonym_index: int = 0) -> str:
        return self.word


class SynonymConjugatingWord(ConjugatingWord):
    # noinspection PyMissingConstructor
    def __init__(self, conjugating_words: list):
        self.conjugating_words = conjugating_words

    def get(self, version=0, capital=False, plural=False, synonym_index: int = 0) -> str:
        return self.conjugating_words[synonym_index].get(version, capital, plural)
