import traceback
from datetime import datetime
from time import sleep


class DelayManager:

    def __init__(self, delay=None):
        if delay is None:
            delay = 3
        if isinstance(delay, list):
            self.delay = delay
        else:
            self.delay = [delay]

    def get_delay(self, i):
        return self.delay[min(i, len(self.delay) - 1)]

    def get_delays_count(self):
        return len(self.delay)


def now_time_str():
    return datetime.now().strftime('%Y-%m-%d %H:%M:%S')


def exception_short_info(e):
    if hasattr(e, 'message'):
        ex_info = e.message
        if ex_info.endswith('.'):
            ex_info = ex_info[:-1]
        return ex_info
    return type(e).__name__


class Retryer(DelayManager):
    FULL_STACK_TRACE = False

    def __init__(self, retries=5, retry_delay=None, retry_condition=None, retry_logger=None, print_errors=False):
        super().__init__(delay=retry_delay)
        self.retries = retries
        self.retry_condition = retry_condition
        self.retry_logger = retry_logger
        self.print_errors = print_errors

    def run(self, function):
        exception = None
        value = None
        for i in range(0, self.retries):
            try:
                if (self.print_errors or self.FULL_STACK_TRACE) and i > 0:
                    print(f'{now_time_str()} Попытка №{i + 1} из {self.retries}')
                value = function()
                return value
            except Exception as e:
                if self.print_errors:
                    another_try_str = ''
                    if i < self.retries - 1:
                        another_try_str = ' Будет совершена повторная попытка.'
                    print(f'{now_time_str()} Произошла ошибка: {exception_short_info(e)}.{another_try_str}')
                    print(e)
                    if self.FULL_STACK_TRACE:
                        traceback.print_exc()
                exception = e
                if self.should_retry(e):
                    if self.retry_logger:
                        self.retry_logger(i + 1, self.retries)
                    sleep(self.get_delay(i))
                else:
                    break
        if exception is not None and isinstance(exception, Exception):
            raise exception
        return value

    def should_retry(self, e):
        if self.retry_condition:
            return self.retry_condition(e)
        return True


class Waiter(DelayManager):
    def __init__(self, wait_delay=None):
        super().__init__(delay=wait_delay)

    def run(self, function):
        i = 0
        while True:
            try:
                value = function()
                if value is not None:
                    return value
                else:
                    sleep(self.get_delay(i))
            except Exception as e:
                raise e
            finally:
                if i <= self.get_delays_count():
                    i = i + 1
