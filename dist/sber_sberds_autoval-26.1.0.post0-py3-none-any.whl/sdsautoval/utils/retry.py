import math
from functools import wraps

from sdsautoval.utils.private.retry import Retryer, Waiter


def withretry(retries=5,
              retry_delay=None,  # [0, 3, 5, 10] by default
              retry_condition=None,
              retry_logger=None,
              internal_retry_delay=20,
              internal_retry_total_time=7200,  # 2 hours
              print_errors=True
              ):
    if retry_delay is None:
        retry_delay = [0, 3, 5, 10]

    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            _retries, _retry_delay, _print_errors = extend_retry_time_for_internal_auth()
            retryer = Retryer(retries=_retries,
                              retry_delay=_retry_delay,
                              retry_condition=retry_condition,
                              retry_logger=retry_logger,
                              print_errors=_print_errors)
            return retryer.run(lambda: func(*args, **kwargs))

        def extend_retry_time_for_internal_auth():
            _retries = retries
            _retry_delay = retry_delay.copy()
            _print_errors = print_errors
            from sdsautoval import UserContext
            if UserContext.get().internal_auth:  # Увеличиваем таймаут для ноды-запускатора
                _retries += math.ceil(internal_retry_total_time / internal_retry_delay)
                _retry_delay.append(internal_retry_delay)
                _print_errors = True
                Retryer.FULL_STACK_TRACE = True
            return _retries, _retry_delay, _print_errors

        return wrapper
    return decorator


def withwait(
        wait_delay=None  # [1, 2, 5, 10, 15] by default
):
    if wait_delay is None:
        wait_delay = [1, 2, 5, 10, 15]

    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            waiter = Waiter(wait_delay=wait_delay)
            return waiter.run(lambda: func(*args, **kwargs))

        return wrapper

    return decorator
