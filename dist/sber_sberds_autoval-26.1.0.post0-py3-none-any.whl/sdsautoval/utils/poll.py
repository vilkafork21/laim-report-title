import time
from functools import wraps

from sdsautoval.utils.private.retry import DelayManager

DEFAULT_POLL_INTERVAL = 5  # seconds
DEFAULT_TIMEOUT = 60  # seconds


def get_from_dict(dictionary, key, default=None):
    if dictionary is not None:
        if key in dictionary.keys():
            return dictionary.get(key)
    return default


def get_status_from_response(response, default=None):
    return get_from_dict(response, 'status', default=default)


def get_status_from_response_in_progress(response):
    return get_from_dict(response, 'status', default='in_progress')


def status_not_in_progress(response):
    return get_status_from_response_in_progress(response).lower() != 'in_progress'


class Poller(DelayManager):
    def __init__(self,
                 exit_condition=None,
                 success_condition=None,
                 logger=None,
                 timeout=DEFAULT_TIMEOUT,
                 poll_interval=DEFAULT_POLL_INTERVAL):
        super().__init__(delay=poll_interval)
        self.exit_condition = exit_condition
        self.success_condition = success_condition
        self.logger = logger
        self.timeout = timeout

    def run(self, func, args, kwargs):
        final_value = None
        start_time = time.time()
        i = 0
        while True:
            value = func()
            if self.exit_condition:
                if self.exit_condition(value):
                    final_value = value
                    break

            if time.time() - start_time > self.timeout:
                if self.logger:
                    self.logger.print_timeout(args, kwargs, value)
                return value
            if self.logger:
                self.logger.print_progress()
            delay = self.get_delay(i)
            if i <= self.get_delays_count():
                i = i + 1
            time.sleep(delay)
        if self.success_condition:
            if self.success_condition(final_value):
                if self.logger:
                    self.logger.print_success()
            else:
                if self.logger:
                    self.logger.print_failure()
        else:
            if self.logger:
                self.logger.print_success()

        return final_value

    # noinspection PyMethodMayBeStatic
    class Logger:

        def __init__(self,
                     result_extractor=lambda x: x,
                     operation_name='some action',
                     additional_timeout_info=lambda args, kwargs, result: ''):
            self.operation_name = operation_name
            self.result_extractor = result_extractor
            self.additional_timeout_info = additional_timeout_info

        def print_start(self):
            print(f"Running {self.operation_name}...", end='')

        def print_progress(self):
            print(".", end='')

        def print_success(self):
            print(f"\n{self.operation_name} operation completed successfully")

        def print_failure(self, value):
            print(f"\n{self.operation_name} operation failed with result {self.result_extractor(value)}")

        def print_timeout(self, args, kwargs, result):
            msg = f"\n{self.operation_name} operation timed out"
            additional_info = self.additional_timeout_info(args, kwargs, result)
            if len(str(additional_info)) > 0:
                msg = msg + f" {additional_info}"
            else:
                msg = msg + '.'
            print(msg)


def poll(exit_condition=None,
         timeout=DEFAULT_TIMEOUT,
         timeout_param=None,
         poll_interval=DEFAULT_POLL_INTERVAL,
         poll_interval_param=None,
         logger=None):
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            real_timeout = timeout
            if timeout_param:
                if timeout_param in kwargs.keys():
                    real_timeout = kwargs[timeout_param]
            real_poll_interval = poll_interval
            if poll_interval_param:
                if poll_interval_param in kwargs.keys():
                    real_poll_interval = kwargs[poll_interval_param]
            poller = Poller(exit_condition=exit_condition,
                            logger=logger,
                            timeout=real_timeout,
                            poll_interval=real_poll_interval)
            return poller.run(lambda: func(*args, **kwargs), args, kwargs)

        return wrapper

    return decorator
