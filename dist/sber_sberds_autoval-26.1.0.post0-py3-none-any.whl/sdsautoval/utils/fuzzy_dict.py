import abc
import inspect

from sdsautoval.utils.text import levenstein


def fuzzy_dict(value):
    if isinstance(value, dict):
        if isinstance(value, FuzzyDict):
            return value
        wrapper = FuzzyDict()
        for key, val in value.items():
            wrapper[key] = fuzzy_dict(val)
        return wrapper
    if isinstance(value, list):
        wrapper = []
        for item in value:
            wrapper.append(fuzzy_dict(item))
        return wrapper
    return value


class _DictGetter:

    def prepare_key(self, key):
        return key

    def get(self, key, dictionary):
        if key in dictionary:
            return True, dictionary[key]
        return False, None


class _RegularGetter(_DictGetter):
    pass


class _RegularCaseInsensitiveGetter(_RegularGetter):
    def prepare_key(self, key):
        if isinstance(key, str):
            return key.lower()
        return key


class _UnderscoreAsWhitespaceGetter(_DictGetter):
    def prepare_key(self, key):
        if isinstance(key, str):
            return key.replace('_', ' ')
        return key


class _UnderscoreAsWhitespaceCaseInsensitiveGetter(_RegularCaseInsensitiveGetter):
    def prepare_key(self, key):
        if isinstance(key, str):
            return super().prepare_key(key).replace('_', ' ')
        return key


class _DistanceGetter(_DictGetter):

    @abc.abstractmethod
    def distance(self, key1, key2):
        pass

    def get(self, key, dictionary):
        min_key = self.find_min_distance_key(dictionary, key)
        if min_key:
            return True, dictionary[min_key]
        else:
            return False, None

    def find_min_distance_key(self, dictionary, key):
        min_distance = float('inf')
        min_key = None
        key = self.prepare_key(key)
        for k in dictionary:
            if isinstance(k, str):
                k = self.prepare_key(k)
                distance = self.distance(key, k)
                if min_key:
                    if distance < min_distance:
                        min_distance = distance
                        min_key = k
                else:
                    min_distance = distance
                    min_key = k
        if min_key:
            if min_distance > self.max_distance(key):
                min_key = None
        return min_key

    def max_distance(self, key):
        return 1 + (len(key) / 2)


class _LevenshteinGetter(_DistanceGetter):

    def distance(self, key1, key2):
        return levenstein(key1, key2)


class _CaseInsensitiveLevenshteinGetter(_LevenshteinGetter):
    def prepare_key(self, key):
        if isinstance(key, str):
            return key.lower()
        return key


class _CaseInsensitiveUnderscoreAsWhitespaceLevenshteinGetter(_CaseInsensitiveLevenshteinGetter):
    def prepare_key(self, key):
        if isinstance(key, str):
            return super().prepare_key(key).replace('_', ' ')
        return key


def _is_recursive(function_name):
    stack = inspect.stack()
    if len(stack) < 3:
        return False
    truncated_stack = stack[2:]
    for frame in truncated_stack:
        if frame.function == function_name:
            return True
    return False


class _WrappedDictGetter(_DictGetter):
    def __init__(self, getter):
        self.getter = getter

    def prepare_key(self, key):
        prepared_key = self.pre_prepare_key(key)
        return self.post_prepare_key(self.getter.prepare_key(prepared_key))

    def get(self, key, dictionary):
        key = self.prepare_key(key)
        return self.getter.get(key, dictionary)

    def pre_prepare_key(self, key):
        return key

    def post_prepare_key(self, key):
        return key


_GETTERS = [
    _RegularGetter(),
    _RegularCaseInsensitiveGetter(),
    _UnderscoreAsWhitespaceGetter(),
    _UnderscoreAsWhitespaceCaseInsensitiveGetter(),
    _LevenshteinGetter(),
    _CaseInsensitiveLevenshteinGetter()
]


class _ReplacedCyrillicGetterWrappedDictGetter(_WrappedDictGetter):
    def pre_prepare_key(self, key):
        from ..utils.text import replace_cyrillic_homoglyphs
        return replace_cyrillic_homoglyphs(key)


def replaced_cyrillic_getter(getter):
    return _ReplacedCyrillicGetterWrappedDictGetter(getter)


def replaced_cyrillic_getters(getters):
    res = []
    for getter in getters:
        res.append(replaced_cyrillic_getter(getter))
    return res


_GETTERS = _GETTERS + replaced_cyrillic_getters(_GETTERS)


class RecursionAwareDict(dict):

    def __non_recursive_getitem__(self, key):
        return super().__getitem__(key)

    def __possibly_recursive_getitem__(self, key):
        return super().__getitem__(key)

    def __getitem__(self, key):
        if _is_recursive('__getitem__'):
            return self.__non_recursive_getitem__(key)
        else:
            return self.__possibly_recursive_getitem__(key)

    def get(self, key, default=None):
        try:
            return self.__getitem__(key)
        except KeyError:
            return default


class FuzzyDict(RecursionAwareDict):
    def __init__(self, ):
        super().__init__()
        self.__getters = _GETTERS

    def __possibly_recursive_getitem__(self, key):
        for getter in self.__getters:
            get_result = getter.get(key, self)
            if get_result is not None:
                found, value = get_result
                if found:
                    return value
            else:
                raise ValueError('getter.get returned None')
        return self.__non_recursive_getitem__(key)
