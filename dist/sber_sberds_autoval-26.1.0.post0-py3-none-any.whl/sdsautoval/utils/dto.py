import json

from sdsautoval.clui.interfaces import TableView
from sdsautoval.util import safe_int_conversion
from sdsautoval.utils.addict import SuperAdDict, SuperAdDictSnake

NONE_SIGN = '-'


class DtoDisplay(TableView):

    # noinspection PyMethodMayBeStatic
    # should return list of tuples (key, value)
    # same as dict.items()
    def items(self):
        return []

    # noinspection PyMethodMayBeStatic
    # called before to_table exits, for table customization
    # like replacing None with '-' or removing empty rows
    def post_process_table(self, table):
        return table.replace_empty(replacement=NONE_SIGN)

    def header(self):
        return ['Поле', 'Значение']

    def field_descriptions(self):
        return {}

    def field_display(self, key, value):
        if value is None:
            return None
        if isinstance(value, str):
            return value
        if isinstance(value, list) or isinstance(value, tuple):
            if len(value) > 0:
                return ', '.join(value)
            else:
                return None
        if isinstance(value, dict):
            return json.dumps(value)
        return safe_int_conversion(value)

    def to_table(self):
        field_names = self.header()

        field_descriptions = self.field_descriptions()
        columns = [
        ]
        for key, value in self.items():
            columns.append([
                field_descriptions.get(key, key), self.field_display(key, value)
            ])

        from sdsautoval.util import SimpleTable, TableDisplayStyle, CellDisplayStyle
        table = SimpleTable(columns, field_names, display_style=TableDisplayStyle(cell_style=CellDisplayStyle()))
        return self.post_process_table(table)


class EazyDtoCamel(SuperAdDict, DtoDisplay):

    def __init__(self, data):
        super(EazyDtoCamel, self).__init__(data)

    def _repr_pretty_(self, p, cycle):
        super(DtoDisplay, self)._repr_pretty_(p, cycle)


class EazyDtoSnake(SuperAdDictSnake, DtoDisplay):
    def __init__(self, data):
        super(EazyDtoSnake, self).__init__(data)

    def _repr_pretty_(self, p, cycle):
        super(DtoDisplay, self)._repr_pretty_(p, cycle)

class EazyDto(EazyDtoSnake):
    pass
