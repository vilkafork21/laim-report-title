class Average:
    def __init__(self, initial_value=None):
        self.value = initial_value
        if self.value:
            self.counts = 1
        else:
            self.counts = 0

    def add(self, value):
        if self.value:
            self.value = (self.value * self.counts + value) / (self.counts + 1)
        else:
            self.value = value
        self.counts += 1

    def get(self):
        return self.value