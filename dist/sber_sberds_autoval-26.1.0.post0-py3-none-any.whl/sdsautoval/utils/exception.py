class Validatable(object):
    def __init__(self):
        self.__exception = None

    def raise_and_store(self, ex):
        self.store(ex)
        raise ex

    def store(self, ex):
        self.__exception = ex

    def validate(self):
        if self.__exception and isinstance(self.__exception, Exception):
            raise self.__exception
