import re


def camel_to_snake(name):
    name = re.sub('(.)([A-Z][a-z]+)', r'\1_\2', name)
    return re.sub('([a-z0-9])([A-Z])', r'\1_\2', name).lower()


def not_empty(some_str):
    if isinstance(some_str, str):
        return some_str is not None and len(some_str) > 0
    else:
        return some_str is not None


def is_empty(some_str):
    return not not_empty(some_str)


def substitute_block_names(key, value):
    if key == 'developer_block' or key == 'cds_block':
        from ..data.block_names import block_names
        from sdsautoval.util import safe_int_conversion
        return block_names.get(safe_int_conversion(value), value)
    return value


def levenstein(str_1, str_2):
    n, m = len(str_1), len(str_2)
    if n > m:
        str_1, str_2 = str_2, str_1
        n, m = m, n

    current_row = range(n + 1)
    for i in range(1, m + 1):
        previous_row, current_row = current_row, [i] + [0] * n
        for j in range(1, n + 1):
            add, delete, change = previous_row[j] + 1, current_row[j - 1] + 1, previous_row[j - 1]
            if str_1[j - 1] != str_2[i - 1]:
                change += 1
            current_row[j] = min(add, delete, change)

    return current_row[n]


CYRILLIC_HOMOGLYPHS = {
    'а': 'a', 'е': 'e', 'о': 'o', 'р': 'p', 'с': 'c', 'у': 'y', 'х': 'x',
    'А': 'A', 'Е': 'E', 'О': 'O', 'Р': 'P', 'С': 'C', 'У': 'Y', 'Х': 'X', 'В': 'B', 'К': 'K', 'М': 'M', 'Н': 'H',
}


def replace_cyrillic_homoglyphs(s):
    if not s:
        return s
    res = s
    for cyrillic, latin in CYRILLIC_HOMOGLYPHS.items():
        res = res.replace(cyrillic, latin)
    return res
