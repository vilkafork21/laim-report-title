import copy

from sdsautoval.utils.text import camel_to_snake


def addict_snake(value):
    return addict(value, constructor=SuperAdDictSnake.constructor)

def addict(value, constructor=None):
    if constructor is None:
        constructor = __addict_constructor
    if isinstance(value, dict):
        return __addict_dict(value, constructor=constructor)
    if isinstance(value, list):
        return __addict_list(value, constructor=constructor)
    if isinstance(value, tuple):
        return __addict_tuple(value, constructor=constructor)
    return value


def __addict_constructor():
    return AdDict.constructor


def __addict_dict(value, constructor=__addict_constructor):
    _addict = constructor().__call__()
    for key, val in value.items():
        new_val = addict(val, constructor=constructor)
        _addict[key] = new_val
    return _addict


def __addict_tuple(value, constructor=__addict_constructor):
    _list = __addict_list(value, constructor=constructor)
    return tuple(_list)


def __addict_list(value, constructor=__addict_constructor):
    _list = []
    for item in value:
        _list.append(addict(item, constructor=constructor))
    return _list

class AdDict(dict):

    @staticmethod
    def constructor():
        return AdDict()

    def __init__(self, *args, **kwargs):
        super().__init__()
        self._construct(*args, **kwargs)

    def _construct(self, *args, **kwargs):
        object.__setattr__(self, '__parent', kwargs.pop('__parent', None))
        object.__setattr__(self, '__key', kwargs.pop('__key', None))
        object.__setattr__(self, '__frozen', False)
        for arg in args:
            if not arg:
                continue
            elif isinstance(arg, dict):
                for key, val in arg.items():
                    self[self.key_preprocessor(key)] = self.value_preprocessor(self._hook(val))
            elif isinstance(arg, tuple) and (not isinstance(arg[0], tuple)):
                self[self.key_preprocessor(arg[0])] = self.value_preprocessor(self._hook(arg[1]))
            else:
                for key, val in iter(arg):
                    self[self.key_preprocessor(key)] = self.value_preprocessor(self._hook(val))
        for key, val in kwargs.items():
            self[self.key_preprocessor(key)] = self.value_preprocessor(self._hook(val))
        return self

    def key_preprocessor(self, key):
        return key

    def value_preprocessor(self, value):
        return value

    def __setattr__(self, name, value):
        if hasattr(self.__class__, name):
            raise AttributeError("'Dict' object attribute "
                                 "'{0}' is read-only".format(name))
        else:
            self[name] = value

    def __setitem__(self, name, value):
        name = self.key_preprocessor(name)
        if self.is_frozen() and name not in super(AdDict, self).keys():
            raise KeyError(name)
        super(AdDict, self).__setitem__(name, value)
        try:
            p = object.__getattribute__(self, '__parent')
            key = object.__getattribute__(self, '__key')
        except AttributeError:
            p = None
            key = None
        if p is not None:
            p[key] = self
            object.__delattr__(self, '__parent')
            object.__delattr__(self, '__key')

    def is_frozen(self):
        try:
            return object.__getattribute__(self, '__frozen')
        except AttributeError:
            return False

    def __add__(self, other):
        if not self.keys():
            return other
        else:
            self_type = type(self).__name__
            other_type = type(other).__name__
            msg = "unsupported operand type(s) for +: '{}' and '{}'"
            raise TypeError(msg.format(self_type, other_type))

    @classmethod
    def _hook(cls, item):
        if isinstance(item, dict):
            return cls(item)
        elif isinstance(item, (list, tuple)):
            return type(item)(cls._hook(elem) for elem in item)
        return item

    def __getattr__(self, item):
        return self.__getitem__(item)

    def __missing__(self, name):
        if self.is_frozen():
            raise KeyError(name)
        return self.__class__()._construct(__parent=self, __key=name)
        # return self.__class__(__parent=self, __key=name)

    def __delattr__(self, name):
        del self[name]

    def to_dict(self):
        base = {}
        for key, value in self.items():
            if isinstance(value, type(self)):
                base[key] = value.to_dict()
            elif isinstance(value, (list, tuple)):
                base[key] = type(value)(
                    item.to_dict() if isinstance(item, type(self)) else
                    item for item in value)
            else:
                base[key] = value
        return base

    def copy(self):
        return copy.copy(self)

    def deepcopy(self):
        return copy.deepcopy(self)

    def __deepcopy__(self, memo):
        other = self.__class__()
        memo[id(self)] = other
        for key, value in self.items():
            other[copy.deepcopy(key, memo)] = copy.deepcopy(value, memo)
        return other

    def update(self, *args, **kwargs):
        other = {}
        if args:
            if len(args) > 1:
                raise TypeError()
            other.update(args[0])
        other.update(kwargs)
        for k, v in other.items():
            if ((k not in self) or
                    (not isinstance(self[k], dict)) or
                    (not isinstance(v, dict))):
                self[k] = addict(v)
            else:
                self[k].update(addict(v))

    def __getnewargs__(self):
        return tuple(self.items())

    def __getstate__(self):
        return self

    def __setstate__(self, state):
        self.update(state)

    def __or__(self, other):
        if not isinstance(other, (AdDict, dict)):
            return NotImplemented
        new = AdDict(self)
        new.update(other)
        return new

    def __ror__(self, other):
        if not isinstance(other, (AdDict, dict)):
            return NotImplemented
        new = AdDict(other)
        new.update(self)
        return new

    def __ior__(self, other):
        self.update(other)
        return self

    def setdefault(self, key, default=None):
        if key in self:
            return self[key]
        else:
            self[key] = default
            return default

    def freeze(self, should_freeze=True):
        object.__setattr__(self, '__frozen', should_freeze)
        for key, val in self.items():
            if isinstance(val, AdDict):
                val.freeze(should_freeze)

    def unfreeze(self):
        self.freeze(False)


class SuperAdDict(AdDict):

    @staticmethod
    def constructor():
        return SuperAdDict

    def value_preprocessor(self, value):
        return addict(value, constructor=SuperAdDict.constructor)


class SuperAdDictSnake(SuperAdDict):

    @staticmethod
    def constructor():
        return SuperAdDictSnake

    def key_preprocessor(self, key):
        return camel_to_snake(key)

    def value_preprocessor(self, value):
        return addict(value, constructor=SuperAdDictSnake.constructor)
