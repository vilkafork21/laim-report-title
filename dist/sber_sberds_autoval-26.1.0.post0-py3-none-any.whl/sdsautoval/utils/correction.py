from sdsautoval.utils.collections import invert_dict
from sdsautoval.utils.fuzzy_dict import fuzzy_dict


def correct(value, original_dict=None, inverted_dict=None):
    if value is None:
        return None
    original_dict, inverted_dict = _prepare_dicts(original_dict=original_dict, inverted_dict=inverted_dict)
    value_corrected_val = original_dict.get(value.lower(), value)
    value_corrected = inverted_dict.get(value_corrected_val, value)
    return value_corrected


def _prepare_dicts(original_dict=None, inverted_dict=None):
    if original_dict is None and inverted_dict is None:
        raise ValueError('Не задан словарь для корректировки')
    if original_dict is None and inverted_dict is not None:
        original_dict = invert_dict(inverted_dict)
    if inverted_dict is None and original_dict is not None:
        inverted_dict = invert_dict(original_dict)
    return fuzzy_dict(original_dict), fuzzy_dict(inverted_dict)


class Corrector:
    def __init__(self, original_dict=None, inverted_dict=None, on_correction=None):
        original_dict, inverted_dict = _prepare_dicts(original_dict=original_dict, inverted_dict=inverted_dict)
        self.original_dict = original_dict
        self.inverted_dict = inverted_dict
        self.on_correction = on_correction
        self.has_on_correction = self.on_correction is not None and callable(self.on_correction)

    def correct(self, value):
        corrected_value = correct(value, original_dict=self.original_dict, inverted_dict=self.inverted_dict)
        if self.has_on_correction and corrected_value != value:
            self.on_correction(value, corrected_value)
        return corrected_value
