def get_arg(args, i):
    if i < len(args):
        return args[i]
    else:
        return None


# noinspection PyUnusedLocal
def default_keyboard_interrupt_handler(keyboard_interrupt: KeyboardInterrupt,
                                       operation_id,
                                       instance,
                                       *args, **kwargs):
    print("\n\n"
          f"Выполнение ячейки остановлено пользователем:\n"
          f"Сработало прерывание KeyboardInterrupt, вызванное нажатием клавиш \"Ctrl + C\" или кнопкой \"стоп\"\n")


# noinspection PyProtectedMember,PyUnusedLocal
def session_interface_run_job(keyboard_interrupt: KeyboardInterrupt,
                              operation_id,
                              instance,
                              *args, **kwargs):
    if not instance._prevalidation:
        raise keyboard_interrupt
    prevalidation_id = instance._prevalidation.prevalidation_id
    if not prevalidation_id:
        raise keyboard_interrupt
    message = "\n\n" \
              f"Ячейка прервана, но выполнение {instance.get_job_name().get(1)} продолжается.\n" \
              f"Для получения статуса вызовите метод " \
              f"{instance.default_object_name()}.get_status('{prevalidation_id}')"
    print(message)


# noinspection PyProtectedMember,PyUnusedLocal
def session_interface_authorize(keyboard_interrupt: KeyboardInterrupt,
                                operation_id,
                                instance,
                                *args, **kwargs):
    message = "\n\n"
    login = instance._login
    if not login:
        message += "Процесс авторизации прерван пользователем\n"
    else:
        if instance._token:
            instance._token = None
        message += f"Процесс авторизации пользователя {login} прерван самим пользователем\n"
    print(message)


# noinspection PyProtectedMember,PyUnusedLocal
def session_interface_get_methods(keyboard_interrupt: KeyboardInterrupt,
                                  operation_id,
                                  instance,
                                  *args, **kwargs):
    job_name = instance.get_job_name().get(1)
    print("\n\n"
          f"Выполнение ячейки прервано пользователем.\n"
          f"Процесс получения методик {job_name} остановлен\n")


# noinspection PyProtectedMember,PyUnusedLocal
def session_interface_select_methods(keyboard_interrupt: KeyboardInterrupt,
                                     operation_id,
                                     instance,
                                     *args, **kwargs):
    method_id = get_arg(args, 0)
    job_name = instance.get_job_name().get(1)
    print("\n\n"
          f"Выполнение ячейки прервано пользователем.\n"
          f"Процесс выбора методики {job_name} {method_id} остановлен\n")


# noinspection PyProtectedMember,PyUnusedLocal
def session_interface_get_jobs(keyboard_interrupt: KeyboardInterrupt,
                               operation_id,
                               instance,
                               *args, **kwargs):
    model_version_filter = ""  # Описание для названия модели превалидации/финоценки
    status_filter = ""  # Описание для фильтра по статусу превалидации/финоценки (RUNNING, DONE, ERROR, PAUSED, TECHNICAL_PAUSED)
    date_from_filter = ""  # Описание для нижней границы фильтра по дате
    date_to_filter = ""  # Описание для верхней границы фильтра по дате

    job_name = instance.get_job_name()

    model_version_id = kwargs.get('model_version_id', get_arg(args, 0))
    status = kwargs.get('status', get_arg(args, 1))
    date_to = kwargs.get('date_to', get_arg(args, 2))
    date_from = kwargs.get('date_from', get_arg(args, 3))

    filters_count = 0

    if model_version_id:
        model_version_filter = f"- Id модели: {model_version_id}\n"
    filters_count += 1

    if status:
        status_filter = f"- статус {job_name.get(1)}: {status}\n"
    filters_count += 1

    if date_from:
        date_from_filter = f"- нижняя граница даты запуска {job_name.get(1)} {date_from}\n"
    filters_count += 1

    if date_to:
        date_to_filter = f"- верхняя граница даты запуска {job_name.get(1)} {date_to}\n"
    filters_count += 1

    message = ''
    if filters_count > 1:
        message = "\n\n" \
                  f"Выполнение ячейки прервано пользователем.\n" \
                  f"Приостановлен процесс загрузки информации по {job_name.get(4, plural=True)}, запущенным пользователем, " \
                  f"со следующим списком параметров:\n "
    elif filters_count == 1:
        message = "\n\n" \
                  f"Выполнение ячейки прервано пользователем.\n" \
                  f"Приостановлен процесс загрузки информации по {job_name.get(4, plural=True)}, запущенным пользователем, " \
                  f"с параметром:\n "
    if len(model_version_filter) > 0:
        model_version_filter = model_version_filter[2:]
    if len(status_filter) > 0:
        status_filter = status_filter[2:]
    if len(date_from_filter) > 0:
        date_from_filter = date_from_filter[2:]
    if len(date_to_filter) > 0:
        date_to_filter = date_to_filter[2:]
    else:
        message = "\n\n" \
                  f"Выполнение ячейки прервано пользователем.\n" \
                  f"Приостановлен процесс загрузки информации по {job_name.get(4, plural=True)}, запущенным " \
                  f"пользователем\n "
    message = message + model_version_filter + status_filter + date_from_filter + date_to_filter
    print(message)

    # noinspection PyUnusedLocal


def session_interface_get_status(keyboard_interrupt: KeyboardInterrupt,
                                 operation_id,
                                 instance,
                                 *args, **kwargs):
    job_name = instance.get_job_name()
    prevalidation_id = kwargs.get('prevalidation_id', get_arg(args, 0))
    message = "\n\n" \
              f"Выполнение ячейки прервано пользователем.\n" \
              f"Приостановлен запущенный пользователем процесс отслеживания статуса {job_name.get(1)} " \
              f"с Id: {prevalidation_id}\n "
    print(message)


# noinspection PyUnusedLocal
def session_interface_stop(keyboard_interrupt: KeyboardInterrupt,
                           operation_id,
                           instance,
                           *args, **kwargs):
    job_name = instance.get_job_name()
    prevalidation_id = kwargs.get('prevalidation_id', get_arg(args, 0))
    message = "\n\n" \
              f"Выполнение ячейки прервано пользователем, но выполнение {instance.get_job_name().get(1)} продолжается.\n" \
              f"Для получения статуса вызовите метод " \
              f"{instance.default_object_name()}.get_status('{prevalidation_id}')"
    print(message)


# noinspection PyUnusedLocal
def session_interface_resume_job(keyboard_interrupt: KeyboardInterrupt,
                                 operation_id,
                                 instance,
                                 *args, **kwargs):
    prevalidation_id = kwargs.get('prevalidation_id', get_arg(args, 0))
    message = "\n\n" \
              f"Выполнение ячейки прервано пользователем.\n" \
              f"Процесс дозапуска {instance.get_job_name().get(1)} продолжается.\n" \
              f"Для получения статуса вызовите метод " \
              f"{instance.default_object_name()}.get_status('{prevalidation_id}')"
    print(message)


# noinspection PyUnusedLocal
def auto_validator_publish_to_mms(keyboard_interrupt: KeyboardInterrupt,
                                  operation_id,
                                  instance,
                                  *args, **kwargs):
    prevalidation_id = kwargs.get('prevalidation_id', get_arg(args, 0))
    message = ""
    if not instance.publish_to_mms_response:
        message = "\n\n" \
                  f"Выполнение ячейки прервано пользователем.\n" \
                  f"Публикация модели превалидации была остановлена\n"
    elif instance.publish_to_mms_response_error:
        message = "\n\n" \
                  f"Выполнение ячейки прервано пользователем.\n" \
                  f"Публикация модели превалидации была остановлена, тем не менее модель была опубликована.\n"
    else:
        message = "\n\n" \
                  f"Выполнение ячейки прервано пользователем.\n" \
                  f"Публикация модели превалидации была остановлена, она была завершена с ошибками.\n"
    print(message)


# noinspection PyUnusedLocal
def session_interface_kss(keyboard_interrupt: KeyboardInterrupt,
                          operation_id,
                          instance,
                          *args, **kwargs):
    print(f"\nВыполнение ячейки прервано пользователем.\n")
