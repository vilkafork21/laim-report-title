import time
from datetime import datetime


def utc_to_local(utc):
    epoch = time.mktime(utc.timetuple())
    offset = datetime.fromtimestamp(epoch) - datetime.utcfromtimestamp(epoch)
    return utc + offset

def pretty_date(d):
    return d.strftime("%Y.%m.%d %H:%M:%S")

