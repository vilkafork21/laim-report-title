from collections import UserList


def stream(iterable):
    return Streamable(iterable).stream()


class Optional:
    def __init__(self, value):
        self.value = value

    def get(self):
        return self.value

    def is_present(self):
        return self.value is not None

    def is_absent(self):
        return not self.is_present()

    def or_else(self, default):
        return self.or_else_get(lambda: default)

    def or_else_raise(self, exception=None, message=None):
        return self.or_else_get(lambda: __raise_exception(exception, message))

    def or_else_get(self, default_supplier):
        if self.is_present():
            return self.get()
        else:
            return default_supplier()


def __raise_exception(exception, message):
    if exception is None:
        exception = Exception
    raise exception(message)


class Streamable(UserList):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.iter = None

    def stream(self):
        self.iter = None
        return self

    def filter(self, function):
        self.iter = filter(function, self.__get_iter())
        return self

    def map(self, function):
        self.iter = map(function, self.__get_iter())
        return self

    def collect(self, collection_class=None):
        if collection_class is None:
            if self.iter is not None:
                ret = Streamable(self.iter)
                self.iter = None

                return ret

            return Streamable(self)

        return collection_class(self.__get_iter())

    def find_first(self):
        collect = self.collect()
        if len(collect) > 0:
            return Optional(collect[0])
        return Optional(None)

    def peek(self, function):
        return self.map(lambda x: self.__peek(function, x))

    def any_match(self, predicate):
        return len(self.filter(predicate).collect()) > 0

    def none_match(self, predicate):
        return not self.any_match(predicate)

    def all_match(self, predicate):
        return not self.any_match(lambda x: not predicate(x))

    def __get_iter(self):
        return self if self.iter is None else self.iter

    # noinspection PyMethodMayBeStatic
    def __peek(self, function, x):
        function(x)
        return x
