from sdsautoval.context.constants import SBERDS_MAIL
from .base import SberDSError
from ..clui.utils import is_in_jupyter
from ..contact_util import ContactsSimple
from ..error_util import format_error, get_event_service, \
    format_error_for_contacts, fix_advice, log_error_with_contact_if_present
from ..version import __version__

__all__ = (
    'SdsBaseError',
    'SdsUrlParseError',
    'SdsSUDIRAuthError',
    'SdsIPAAuthError',
    'SdsParamValidationError',
    'SdsSettingsValidationError',
    'SdsFeedbackError',
    'SdsNonCompatibleVersionError',
    'SdsResourceError',
    'SdsNotAuthorizedError',
    'SdsExceptionPrinterInterface',
    'SdsExceptionLogPrinter',
    'SdsColumnRolesValidationError',
    'SdsInternalAuthError',
    'SdsAuthParseError',
    'SdsServiceUnavailableError',
    'SdsConnResetError',
    'SdsTimeOutError',
    'SdsSSLError',
    'SdsBadGatewayError',
    'SdsFileUploadError',
    'SdsFileUploadEventsError'
)


class SdsBaseError(Exception):
    """
       Базовая ошибка SDK, которая выдается пользователю.
    """

    def __init__(self, code: str, header: str, message: str, advice: str):
        super().__init__()
        self.code = code
        self.header = header
        self.message = message
        self.advice = advice
        self.custom_print = None
        self._service_str = None
        from ..contact_util import Contacts
        self.contacts = Contacts.parse(advice)
        if self.contacts:
            self.custom_print = self.print_with_contacts
            if isinstance(self.contacts, ContactsSimple):
                self.advice = fix_advice(self.advice)
                self.contacts = ContactsSimple.parse(self.advice)

    def print_with_contacts(self):
        advice_prefix = self.contacts.advice_before_contacts(self.advice)
        advice_suffix = self.contacts.advice_after_contacts(self.advice)
        print(format_error_for_contacts(self.message, advice_prefix))
        if is_in_jupyter():
            self.contacts.ipython_display()
        else:
            print(self.contacts)
        print(advice_suffix)
        # self._print_suffix(advice_suffix)


    def _print_suffix(self, advice_suffix: str):
        if advice_suffix.strip() != "":
            fixed_suffix = fix_advice(advice_suffix)
            from ..contact_util import ContactsSimple
            service_contact = ContactsSimple.parse(fixed_suffix)
            if service_contact:
                fixed_prefix = service_contact.advice_before_contacts(fixed_suffix)
                final_suffix = service_contact.advice_after_contacts(fixed_suffix)
                print(fixed_prefix)
                if is_in_jupyter():
                    service_contact.ipython_display()
                else:
                    print(service_contact)
                print(final_suffix)
            else:
                print(advice_suffix)

    def service_str(self, ex):
        service_str = ''
        if isinstance(ex, SberDSError):
            service_str = ex.get_service_str() + ' '
        if len(service_str.strip()) == 0:
            return ''
        return service_str

    def print_with_events(self, file=None):
        print(format_error(self.message, self.advice), file=file)
        event_service = get_event_service()
        if isinstance(self._service_str, str) and \
                'template-selector' not in self._service_str and \
                'incident-service' not in self._service_str and \
                event_service is not None:
            try:
                events = event_service.get_all_sorted_events(force=True)
                if events is not None and len(events) > 0:
                    print("\nВ данный момент заведены инциденты:", file=file)
                    event_service.print_events_list(events, file=file)
            except Exception:
                pass


class SdsAuthParseError(SdsBaseError):
    """
    SDS-094 Ошибка при парсинге страницы
    """

    def __init__(self, advice: str):
        super().__init__('SDS-094', 'authorization',
                         'невозможно определить способ аутентификации', advice)


class SdsUrlParseError(SdsBaseError):
    """
    SDS-094 Ошибка при локальной проверке стенда-константы или формата url.
    """

    def __init__(self, advice: str):
        super().__init__('SDS-094', 'authorization', 'не валидный URL', advice)


class SdsSUDIRAuthError(SdsBaseError):
    """
    SDS-095 Ошибка аутентификации в СУДИР.
    """

    def __init__(self, advice: str):
        super().__init__('SDS-095', 'authorization', 'Ошибка аутентификации в СУДИР', advice)


class SdsIPAAuthError(SdsBaseError):
    """
    SDS-096 Ошибка аутентификации в SberDS.
    """

    def __init__(self, advice: str):
        super().__init__('SDS-096', 'authorization', 'Ошибка аутентификации в SberDS', advice)


class SdsInternalAuthError(SdsBaseError):
    """
    SDS-095 Ошибка внутренней аутентификации.
    """

    def __init__(self, advice: str):
        super().__init__('SDS-095', 'authorization', 'Ошибка внутренней аутентификации', advice)


class SdsParamValidationError(SdsBaseError):
    """
    SDS-097 Пользователь SDK неверно указал значения параметров и вызвал функцию validate.
    """

    def __init__(self, param: str, advice: str):
        super().__init__('SDS-097', 'parameters_validation', 'Неверно указаны параметры функции SDK, ' + param, advice)


class SdsSettingsValidationError(SdsBaseError):
    """
    SDS-097 Пользователь SDK неверно указал значения settings и вызвал функцию validate.
    """

    def __init__(self, message: str, advice: str):
        super().__init__('SDS-097', 'settings_validation', message, advice)


class SdsFeedbackError(SdsBaseError):
    """
    SDS-107 Ошибка при валидации или вызове user-feedback-service.
    """

    def __init__(self, message: str, advice: str):
        super().__init__('SDS-107', 'feedback',
                         'Не удается отправить обращение. ' + message,
                         advice)


class SdsNonCompatibleVersionError(SdsBaseError):
    """
    SDS-109 Ошибка при проверке версии SDK.
    """

    def __init__(self, version, advise):
        super().__init__('SDS-109', 'SDK error',
                         f"Версия SDK {__version__} устарела. Пожалуйста, обновите SDK до версии {version.current_version}",
                         advise)


class SdsResourceError(SdsBaseError):
    """
    SDS-097 Пользователь SDK неверно указал значения настроек запуска превалидации и запустил её.
    """

    def __init__(self, message: str, advice: str):
        super().__init__('SDS-097', 'parameters_validation', message, advice)


class SdsNotAuthorizedError(SdsBaseError):
    """
    SDS-112 Ошибка при отсутствии авторизации.
    """

    def __init__(self):
        super().__init__('SDS-094', 'authorization',
                         'Пользователь не авторизован или токен авторизации уже не валиден.',
                         f"Пожалуйста, авторизуйтесь через метод auto_validator.authorize")


class SdsServiceUnavailableError(SdsBaseError):
    """
    SDS-004 Ошибка при недоступности сервиса.
    """

    def __init__(self, ex):
        super().__init__('SDS-004', 'system_error',
                         f'Сервис {self.service_str(ex)}недоступен, возможно идут технические работы. ',
                         f"Пожалуйста, попробуйте позже, если проблема останется - обратитесь в поддержку" +
                         f" {SBERDS_MAIL} ИЛИ https://confluence.sberbank.ru/pages/viewpage.action?pageId=4238116349")
        self._service_str = self.service_str(ex).strip()
        self.custom_print = self.print_with_events


class SdsBadGatewayError(SdsBaseError):
    """
    SDS-004 Ошибка при недоступности сервиса.
    """

    def __init__(self, ex):
        super().__init__('SDS-004', 'system_error',
                         f'Сервис {self.service_str(ex)}недоступен, возможно идут технические работы. ',
                         'Пожалуйста, попробуйте позже, если проблема останется - обратитесь в поддержку' +
                         f' {SBERDS_MAIL} ИЛИ https://confluence.sberbank.ru/pages/viewpage.action?pageId=4238116349')
        self._service_str = self.service_str(ex).strip()
        self.custom_print = self.print_with_events


class SdsTimeOutError(SdsBaseError):
    """
    SDS-004 Ошибка при превышении таймаута.
    """

    def __init__(self, ex):
        super().__init__('SDS-004', 'system_error', f'Сервис {self.service_str(ex)}не ответил на запрос вовремя.',
                         f"Пожалуйста, попробуйте позже, если проблема останется - обратитесь в поддержку" +
                         f" {SBERDS_MAIL} ИЛИ https://confluence.sberbank.ru/pages/viewpage.action?pageId=4238116349")
        self._service_str = self.service_str(ex).strip()
        self.custom_print = self.print_with_events


class SdsConnResetError(SdsBaseError):
    """
    SDS-004 Ошибка при сбросе соединения.
    """

    def __init__(self, ex):
        super().__init__('SDS-004', 'system_error', f'Сервис {self.service_str(ex)}сбросил соединение.',
                         f"Пожалуйста, попробуйте позже, если проблема останется - обратитесь в поддержку" +
                         f" {SBERDS_MAIL} ИЛИ https://confluence.sberbank.ru/pages/viewpage.action?pageId=4238116349")
        self._service_str = self.service_str(ex).strip()
        self.custom_print = self.print_with_events


class SdsFileUploadError(SdsBaseError):
    """
    SDS-004/SDS-097 Ошибка при загрузке файла.
    """

    def __init__(self, message=None, advise=None, header=None):
        if not message:
            message = "Ошибка при загрузке файла."
        if not advise:
            advise = f"Пожалуйста, попробуйте позже, если проблема останется - обратитесь в поддержку" + \
                     f" {SBERDS_MAIL} ИЛИ https://confluence.sberbank.ru/pages/viewpage.action?pageId=4238116349"
        code = 'SDS-004'
        if not header:
            header = 'system_error'
        if header == 'parameters_validation':
            code = 'SDS-097'
        super().__init__(code, header, message, advise)


class SdsFileUploadEventsError(SdsFileUploadError):
    """
    SDS-004/SDS-097 Ошибка при загрузке файла.
    """

    def __init__(self, message=None, advise=None, header=None, cause_events_str=None):
        super().__init__(message=message, advise=advise, header=header)
        self.cause_events_str = cause_events_str
        self.custom_print = self.custom_print_func

    def custom_print_func(self):
        print(format_error(self.message, self.advice))
        if self.cause_events_str:
            print("Информация о технических работах:")
            print(self.cause_events_str, end='\n\n')


class SdsSSLError(SdsBaseError):
    """
    SDS-004 Ошибка SSLError.
    """

    def __init__(self, ex):
        message = "Получена ошибка вида 'ssl.SSLError'."
        service_str = self.service_str(ex)
        if len(service_str > 0):
            message = f"Получена ошибка вида 'ssl.SSLError' от сервиса {service_str.strip()}."

        super().__init__('SDS-004', 'system_error', message,
                         f"Пожалуйста, попробуйте позже, если проблема останется - обратитесь в поддержку" +
                         f" {SBERDS_MAIL} ИЛИ https://confluence.sberbank.ru/pages/viewpage.action?pageId=4238116349")


class SdsDatasourceDescriptionError(SdsBaseError):
    """
    SDS-097 Ошибка в описании источника данных
    """

    def __init__(self, description, advice):
        super().__init__('SDS-097', 'parameters_validation',
                         message='Ошибка в описании источника данных: ' + str(description),
                         advice=advice)


class SdsColumnRolesValidationError(SdsBaseError):
    """
    SDS-097 Пользователь SDK неверно указал значения ролей/типов колонок.
    """

    def __init__(self, errors: list):
        super().__init__('SDS-097', 'parameters_validation', '', '')
        self.errors = errors
        self.custom_print = self.log_errors_dict

    def log_errors_dict(self):
        print('Ошибки валидации запроса:')
        _unique_errors = [i for n, i in enumerate(self.errors) if i not in self.errors[n + 1:]]
        for n, error in enumerate(_unique_errors):
            print(f'''{n + 1}.
            {format_error(error['message'], error['solutionAdvice'])}    
                    ''')


class SdsExceptionPrinterInterface:
    """
        Интерфейс показа ошибок SDK пользователю.
    """

    def print(self, error: SdsBaseError, call_str: str = None):
        pass


class SdsExceptionLogPrinter(SdsExceptionPrinterInterface):
    """
       Реализация - показ ошибок SDK пользователю в логе.
    """

    def print(self, error: SdsBaseError, call_str: str = None):
        print(f'\nОшибка:')
        update_error(error)

        if error.custom_print is not None:
            error.custom_print()
        else:
            log_error_with_contact_if_present(format_error(error.message, error.advice))
            # print(format_error(error.message, error.advice))


def update_error(error: SdsBaseError):
    if error.header == 'kss_request':
        if error.message == 'KSS did not answered in timeout':
            error.advice = 'Сервис KSS недоступен?! Оставь нам заявку в https://confluence.sberbank.ru/pages/viewpage.action?pageId=4238116349 (sigma)'
        elif error.message == 'Глобальный рейтинг не готов':
            error.advice = 'Попробуйте запросить данные через минуту. Если ошибка повторится - напишите в поддержку ' \
                           'https://confluence.sberbank.ru/pages/viewpage.action?pageId=4238116349 (sigma)'
        else:
            error.advice = 'Есть идеи по улучшению?! Напиши нам на helloKSS@sberbank.ru'
