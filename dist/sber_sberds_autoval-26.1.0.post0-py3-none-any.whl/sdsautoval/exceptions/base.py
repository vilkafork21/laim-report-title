__all__ = 'SberDSError'


class SberDSError(Exception):
    def __init__(self, response, method=None, url=None, service_name=None):
        super().__init__(response, method, url)
        self.response = response
        self.method = method
        self.url = url
        self.service_name = service_name

    pass

    def __str__(self):
        service_str = self.get_service_str()
        if len(service_str) > 0:
            service_str = f'service={service_str} '
        return f'{self.__class__.__name__}({service_str}code={self.response.status_code} ' \
               f'{self.response.reason} {self.method} {self.url}))'

    def get_service_str(self):
        service_str = ''
        if isinstance(self.service_name, str) and len(self.service_name) > 0:
            service_str = f'{self.service_name}'
        return service_str
