import datetime
import functools
import inspect
import sys
import traceback

from sdsautoval.context.user_context import UserContext, LastError
from .exceptions import StopExecution
from .sds_exceptions import SdsBaseError, SdsExceptionPrinterInterface, SdsAuthParseError
from .. import testutil
from ..utils.keyboard_interrupt_handlers import default_keyboard_interrupt_handler
from ..utils.stream import stream


class ExceptionLoggerConfig:
    RETHROW = testutil.is_in_unit_test()


def handle_exception(func, logger, args, ex, kwargs, supress_rethrow=False):
    if isinstance(ex, SdsAuthParseError):
        print("-auth- error", file=sys.stderr)
        traceback.print_exc()
    UserContext.get().last_error = LastError(datetime.datetime.now(),
                                             ex.code, ex.header,
                                             ex.message, ex.advice)
    func_call_str = None
    if func:
        try:
            func_args = inspect.signature(func).bind(*args,
                                                     **kwargs).arguments
            func_args_str = ", ".join(map("{0[0]} = {0[1]!r}".format, process_func_args(func_args)))
            func_call_str = str(func.__module__) + "." + str(
                func.__qualname__) + "(" + func_args_str + ")"
        except Exception:
            pass
    logger.print(ex, call_str=func_call_str)
    if supress_rethrow:
        return
    if ExceptionLoggerConfig.RETHROW:
        raise ex


def arg_value_to_str(arg):
    key = arg[0]
    value = arg[1]
    if type(value).__repr__ is not object.__repr__:
        return (key, value)
    if type(value).__str__ is not object.__str__:
        return key, Str2Repr(value)
    return key, Str2Repr(Type2Str(value))


def process_func_args(func_args):
    args = []
    if func_args:
        args = func_args.items()
    return (stream(args)
            .map(arg_value_to_str)
            .collect(collection_class=list))


def exception_logger(logger: SdsExceptionPrinterInterface, supress_rethrow=False):
    def exception_handler(func):
        """
        Decorator that handles SdsBaseError in func and prints it as well.
        Used in case whole function could be wrapped.

        :param func: function
        :return: result
        """

        @functools.wraps(func)
        def wrapper_decorator(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except SdsBaseError as ex:
                handle_exception(func, logger, args, ex, kwargs, supress_rethrow)

        return wrapper_decorator

    return exception_handler


def return_self():
    def exception_handler(func):
        """
        Decorator that returns `self` instance,
        no matter what happens inside method

        :param func: function
        :return: result
        """

        @functools.wraps(func)
        def wrapper_decorator(_instance, *args, **kwargs):
            func(_instance, *args, **kwargs)
            return _instance

        return wrapper_decorator

    return exception_handler


def throwable_exception_logger(logger: SdsExceptionPrinterInterface):
    def exception_handler(func):
        """
        Decorator that handles SdsBaseError in func, prints it as well and rethrow it.
        Used in case whole function could be wrapped. Should be on top of decorator list.

        :param func: function
        :return: result
        """

        @functools.wraps(func)
        def wrapper_decorator(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except SdsBaseError as ex:
                UserContext.get().last_error = LastError(datetime.datetime.now(), ex.code, ex.header, ex.message,
                                                         ex.advice)
                logger.print(ex)
                raise StopExecution

        return wrapper_decorator

    return exception_handler


def keyboard_interrupt_handler(ki_handler=default_keyboard_interrupt_handler,
                               operation_id=None):
    def exception_handler(func):
        """
        Decorator that handles KeyboardInterrupt in func and calls the ki_handler.
        Used in case whole function could be wrapped.

        :param func: function
        :return: result
        """

        @functools.wraps(func)
        def wrapper_decorator(_instance, *args, **kwargs):
            try:
                return func(_instance, *args, **kwargs)
            except KeyboardInterrupt as ki:
                ki_handler(ki, operation_id, _instance, *args, **kwargs)

        return wrapper_decorator

    return exception_handler


class Str2Repr:

    def __init__(self, value):
        self.value = value

    def __repr__(self):
        if self.value:
            return self.value.__str__()
        return str(None)


class Type2Str:

    def __init__(self, value):
        self.value = value

    def __str__(self):
        if self.value:
            return f'<{self.value.__class__.__name__}>'
        return str(None)