__all__ = (
    'BadRequestError',
    'NotFoundError',
    'ForbiddenError',
    'UnauthorizedError',
    'UnknownError',
    'ValidationError',
    'ServerError',
    'TimeOutError',
    'ConnResetError',
    'SSLVersionError',
    'SSLError',
    'SSLEOFError',
    'SudirAuthorizationError',
    'UnknownAuthType',
    'ServiceUnavailableError',
    'BadGatewayError'
)

from sdsautoval.exceptions.base import SberDSError


class BadRequestError(SberDSError):
    def __init__(self, response, method, url):
        super().__init__(response, method, url)


class NotFoundError(SberDSError):
    def __init__(self, response, method, url):
        super().__init__(response, method, url)


class UnauthorizedError(SberDSError):
    def __init__(self, response, method, url):
        super().__init__(response, method, url)


class ForbiddenError(SberDSError):
    def __init__(self, response, method, url):
        super().__init__(response, method, url)


class UnknownError(SberDSError):
    def __init__(self, response, method, url):
        super().__init__(response, method, url)


class ServerError(SberDSError):
    def __init__(self, response, method, url):
        super().__init__(response, method, url)


class ServiceUnavailableError(SberDSError):
    def __init__(self, response, method, url, service_name=None):
        super().__init__(response, method, url, service_name=service_name)


class BadGatewayError(SberDSError):
    def __init__(self, response, method, url, service_name=None):
        super().__init__(response, method, url, service_name=service_name)


class UnknownAuthType(SberDSError):
    def __init__(self, s):
        super().__init__(s)
        self.response = s


class SudirAuthorizationError(SberDSError):
    def __init__(self, s):
        super().__init__(s)
        self.response = s


class ValidationError(SberDSError):
    pass


class TimeOutError(SberDSError):
    def __init__(self, s, service_name=None):
        super().__init__(s, service_name=service_name)
        self.response = s


class ConnResetError(SberDSError):
    def __init__(self, s, service_name=None):
        super().__init__(s, service_name=service_name)
        self.response = s


class SSLVersionError(SberDSError):
    def __init__(self, s, service_name=None):
        super().__init__(s, service_name=service_name)
        self.response = s


class SSLError(SberDSError):
    def __init__(self, s, service_name=None):
        super().__init__(s, service_name=service_name)
        self.response = s


class SSLEOFError(SberDSError):
    def __init__(self, s, service_name=None):
        super().__init__(s, service_name=service_name)
        self.response = s


class IllegalStateException(Exception):
    pass


class StopExecution(Exception):
    def _render_traceback_(self):
        return []
