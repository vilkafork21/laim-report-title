import base64
import json

from .feedback.parsed_jwt import ParsedJwt


def parse_jwt(token: str):
    """
    Принимает jwt-token, который состоит из 3 закодированных частей.
    Декодирует payload (2 часть) и считывает нужные данные: "user_name", "email", "fullName", а так же "sberds-zone".
    """
    decoded = decode_jwt(token)
    sds_zone = decoded.get('sberds-zone', None)
    if sds_zone is None and 'user_context' in decoded.keys():
        user_context = decoded['user_context']
        if user_context is not None:
            sds_zone = user_context.get('sdsZone', None)

    return ParsedJwt(decoded.get('user_name', None), decoded.get('email', None),
                     decoded.get('fullName', None),
                     sds_zone)


def decode_jwt(token):
    if token is None:
        return None
    token = token.strip()
    token_split = token.split(".")
    if len(token_split) < 2:
        return None
    payload_encoded = token_split[1]
    decoded_bytes = base64.urlsafe_b64decode(
        payload_encoded + '=' * (-len(payload_encoded) % 4))
    token_payload_decoded = str(decoded_bytes, "utf-8")
    return json.loads(token_payload_decoded)
