import json

from sdsautoval.context.user_context import UserContext
from ..exceptions.sds_exceptions import SdsSettingsValidationError
from ..modprop import AbstractData, ColumnsSelector, DataSample, RoleAndType
from ..version import __version__ as sdk_version


class PreValidationConverter:

    @staticmethod
    def convert_to_transport(
        model_version_id: int,
        method_id: str,
        samples: [DataSample],
        settings: dict,
        validate_settings: bool,
        resources=None,
        permission_data=False,
        trigger_node_id=None,
        project_id=None,
        cpu_only=False,
        disable_pv=False,
        request_type=None
    ) -> dict:
        """convert to server API format"""
        data_source_json = list(map(PreValidationConverter.convert_data_sample, samples))

        return {
            "modelVersionId": model_version_id,
            "methodId": method_id,
            "dataSource": data_source_json,
            "settings": PreValidationConverter.prepare_settings(settings),
            "validateSettings": validate_settings,
            "dockerResource": resources,
            "version": sdk_version,
            "authMethod": UserContext.get().auth_method(),
            "disable_pv": disable_pv,
            "cpu_only": cpu_only,
            "triggerNodeId": trigger_node_id,
            "projectId": project_id,
            "privateData": permission_data,
            "requestType": request_type
        }

    @staticmethod
    def convert_data_sample(sample: AbstractData) -> dict:
        csv = {}
        sql = None
        columns = None
        default_role = None
        default_type = None
        csv_file_data = None
        if isinstance(sample, DataSample):
            sql = sample.sql
            selector: ColumnsSelector = sample.selector

            json_columns = {}
            if selector is not None:
                default_role = selector.get_default_role()
                default_type = selector.get_default_type()
                helper = _JsonHelper(selector.defaultRole, selector.defaultType)
                for col in selector.rolesAndTypes:
                    json_columns[col] = helper.role_and_type_to_json(col, selector.rolesAndTypes[col])

            columns = list(json_columns.values())

            csv = {
                'columnDelimiter': sample.delimiter,
                'rowDelimiter': sample.row_delimiter,
                'escapeChar': sample.escape_char,
                'encoding': sample.encoding,
                'firstRowAsHeader': sample.first_row_as_header,
                'firstColumnAsIndex': sample.first_column_as_index
            }
        if not sample.link_data and sample.connection:
            csv_file_data = sample.connection.get_csv_file_data()
        return {
            'key': sample.get_key().upper(),
            'type': sample.get_type(),
            'connection': sample.connection.to_dict() if (not sample.link_data) and sample.connection else None,
            'sql': sql,
            'file': sample.file,
            'csvProps': csv,
            'csvFileData': csv_file_data,
            'columns': columns,
            'defaultRole': default_role,
            'defaultType': default_type,
            'projectId': sample.project_id,
            'nodeId': sample.node_id,
            'portName': sample.port_name,
            'cachedPvId': sample.cached_pv_id
        }

    @staticmethod
    def prepare_settings(settings: dict):
        if not settings:
            return {}
        if not isinstance(settings, dict):
            raise SdsSettingsValidationError("Настройки должны быть dict",
                                             "Проверьте настройки")
        result = {}
        legal_types = (int, float, bool, str, list, dict, set, tuple)
        for key, value in settings.items():
            if not isinstance(value, legal_types):
                raise SdsSettingsValidationError(
                    f"Недопустимый тип значения для ключа {key}",
                    f"Используйте только типы "
                    f"{list(map(lambda x:x.__name__, legal_types))}"
                )
            result_value = value
            if isinstance(value, dict) or isinstance(value, list) or isinstance(value, tuple):
                result_value = json.dumps(value)
            if isinstance(value, set):
                # json cannot dump set, wrap to the list
                result_value = json.dumps(list(value))
            result[key] = result_value

        return result

    @staticmethod
    def prepare_resume_body(resource, trigger_node_id=None, cpu_only=False) -> dict:
        result = {}
        if resource is not None:
            result['resource'] = resource
        if trigger_node_id is not None:
            result['triggerNodeId'] = trigger_node_id
        result['cpu_only'] = cpu_only
        return result


class _JsonHelper:
    role: str
    type: str

    def __init__(self, role, type):
        self.type = type
        self.role = role

    def role_and_type_to_json(self, col, roleAndType: RoleAndType):
        role = roleAndType.get_role() if roleAndType.get_role() is not None else self.role
        type = roleAndType.get_type() if roleAndType.get_type() is not None else self.type
        return self.json(col, role, type)

    def json_column(self, col, role: str, type: str):
        role = role if role is not None else self.role
        type = type if type is not None else self.type
        return self.json(col, role, type)

    @staticmethod
    def json(col, role: str, type: str):
        return {'name': col, 'role': role, 'type': type.upper()}
