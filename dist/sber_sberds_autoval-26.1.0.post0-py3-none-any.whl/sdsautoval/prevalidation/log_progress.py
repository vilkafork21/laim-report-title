from datetime import datetime

from sdsautoval.colors import Colors
from sdsautoval.context.user_context import UserContext
from sdsautoval.warnings import SdsWarning
from .error_helper import ADVICE_MAP
from ..context.constants import REQUEST_STATUS_LIST
from ..error_util import format_error, format_error_with_header, \
    format_node_error, log_error_with_contact_if_present
from ..utils.args import is_dict_with_elements
from ..utils.conjugating_word import ConjugatingWord
from ..utils.misc import pre_validation_status_order, get_contacts_str
from ..utils.text import is_empty

BG_COLOR_CODES_ENABLED = {
    'black': '\033[40m',
    'red': '\033[41m',
    'green': '\033[42m',
    'yellow': '\033[43m',
    'blue': '\033[44m',
    'purple': '\033[45m',
    'cyan': '\033[46m',
    'white': '\033[47m'
}

COLOR_CODES_ENABLED = {
    'black': '\033[30m',
    'red': '\033[31m',
    'green': '\033[32m',
    'yellow': '\033[33m',
    'blue': '\033[34m',
    'purple': '\033[35m',
    'cyan': '\033[36m',
    'white': '\033[37m'
}


def get_color_codes():
    if Colors.IS_ENABLED:
        return COLOR_CODES_ENABLED
    else:
        return {}


def get_bg_color_codes():
    if Colors.IS_ENABLED:
        return BG_COLOR_CODES_ENABLED
    else:
        return {}

def get_bold_code():
    if Colors.IS_ENABLED:
        return "\033[1m"
    else:
        return ""

def get_reset_code():
    if Colors.IS_ENABLED:
        return "\033[0m"
    else:
        return ""


class LogProgressInterfaceSimple:
    """ Базовый интерфейс для показа прогресса """

    def __init__(self, job_name: ConjugatingWord):
        if not job_name:
            job_name = UserContext.get().job_name
        self._job_name = job_name
        self.printed_warnings = set()
        self.last_printed_status = None

    @staticmethod
    def get_time() -> str:
        return datetime.now().strftime("[%d.%m.%Y - %H:%M:%S]")

    def on_status_change(self, new_status=None):
        self.last_printed_status = new_status

    def get_job_name(self):
        return self._job_name

    def get_widget(self):
        """ returns widget """
        return ""

    def log_current_time(self, new_line=False):
        """ log current time
        :param new_line: check if need new line before
        """

    def log_submit_step(self, prevalidation_id: str, persistent_volume=None):
        """ log on submit step
        :param prevalidation_id: prevalidation ID
        """
        if is_dict_with_elements(persistent_volume):
            if persistent_volume.get('usePV', False):
                print(
                    f'{self.get_job_name().get(0, capital=True)} будет запущена c PersistentVolume размером {persistent_volume.get("pvSize", 0)} GiB')

    def log_project_started_step(self, prevalidation_id: str):
        """ log on project created step
        """

    def log_waiting_step(self) -> None:
        """ log on waiting step
        """

    def log_queue_step(self):
        """ log on too long wait in queue step
        """
        print(
            f'Запрос на {self.get_job_name().get(3)} {Colors.BOLD + Colors.WARNING + "поставлен в очередь" + Colors.ENDC} Ожидание может занять некоторое время в зависимости '
            f'от нагрузки на сервис и инфраструктурных работ')

    def log_work_started_step(self):
        """ log on work started step
        """

    def log_request_verified_step(self):
        """ log on request verified step
        """

    def log_data_verified_step(self):
        """ log on data verified step
        """

    def log_project_created_step(self, link_to_workflow_ui: str, prevalidation_id: str) -> None:
        """ log on project created step
        """
        print(f'Проект {self.get_job_name().get(1)} создан')
        print(f'ID проекта: {prevalidation_id}')
        print(f'Ссылка на проект: {link_to_workflow_ui}')

    def log_progress_update(self, status: dict):
        """ log on update progress

        :param status: dict
            example:
            {
                "nodes": {"all":1, "launched": 2, "error": 3, "done": 4},
                "status": "<String>",
                "message": "<String>",
                "project_url": <String>
            }
        """

    def log_project_executed_step(self) -> None:
        """ log on PROJECT_EXECUTED step """
        print(f'\n{self.get_time()}')
        print(
            f'Проект {self.get_job_name().get(1)} {Colors.BOLD + Colors.OKGREEN + "полностью исполнен" + Colors.ENDC}')

    def log_project_paused_step(self) -> None:
        """ log on PAUSED step """
        print(f'\n{self.get_time()}')
        print(f'Проект {self.get_job_name().get(1)} {Colors.BOLD + Colors.WARNING + "был остановлен" + Colors.ENDC}\n')

    def log_project_technical_paused_step(self) -> None:
        """ log on TECHNICAL_PAUSED step """
        print(f'\n{self.get_time()}')
        print(f'Проект {self.get_job_name().get(1)} был приостановлен на время инцидента\n')

    def log_project_published_step(self) -> None:
        """ log on PUBLISHED step """
        print(f'\n{self.get_time()}')
        print(
            f'Проект {self.get_job_name().get(1)} {Colors.BOLD + Colors.OKGREEN + "был опубликован в БМ" + Colors.ENDC}')

    def log_report_step(self, main_traffic_light: str, main_traffic_light_info: dict,
                        report_url: str, link_to_workflow_ui: str) -> None:
        """ log report and MTL info

        :param main_traffic_light: main traffic light (example GREEN)
        :param main_traffic_light_info: raw value of main traffic light
        :param report_url: url to report
        :param link_to_workflow_ui: link to project UI
        """

    def log_errors_step(self, prevalidation, error: dict, method_id: str, validation_errors: list, node_errors: list) -> None:
        print(f'\n{self.get_time()}')
        err_len = 0

        if validation_errors is not None and len(validation_errors) > 0:
            err_len = len(validation_errors)
        # error contains one from validation_errors
        if error is not None and err_len == 0:
            err_len += 1
        if node_errors is not None and len(node_errors) > 0:
            err_len += len(node_errors)

        if err_len > 0:
            if err_len == 1:
                print(
                    f'Проект {self.get_job_name().get(1)} {Colors.BOLD + Colors.FAIL + "завершился с ошибкой:" + Colors.ENDC}')
            else:
                print(
                    f'Проект {self.get_job_name().get(1)} {Colors.BOLD + Colors.FAIL + "завершился с ошибками:" + Colors.ENDC}')

            if validation_errors is not None and len(validation_errors) > 0:
                print(Colors.FAIL + '\u2022 Ошибки валидации запроса:' + Colors.ENDC)
                LogProgressInterface.log_validation_errors(validation_errors)
            elif error is not None:
                self.log_prevalidation_error(error, method_id)

            if node_errors is not None and len(node_errors) > 0:
                print(Colors.FAIL + '\u2022 Ошибки исполнения нод:' + Colors.ENDC)
                LogProgressInterface.log_node_errors(node_errors)
        else:
            print(
                f'Проект {self.get_job_name().get(1)} {Colors.BOLD + Colors.FAIL + "завершился с ошибкой." + Colors.ENDC}')
            print('Детали по описанию ошибки отсутствуют.')
            print(f'Обратитесь к валидатору или в поддержку.')
            self.print_contacts(prevalidation)

    # noinspection PyMethodMayBeStatic
    def print_contacts(self, prevalidation):
        contacts = prevalidation.get_service_contacts()
        print(get_contacts_str(contacts))

    def log_warnings_step(self, warnings: list, prevalidation_status, file=None) -> None:
        if prevalidation_status in REQUEST_STATUS_LIST:
            prevalidation_status = self.last_printed_status
        warnings = SdsWarning.convert_list(warnings)
        status_order = pre_validation_status_order(prevalidation_status)
        if warnings is not None and len(warnings) > 0:
            warnings = sorted(warnings, key=lambda w: w.order)
            for warning in warnings:
                # noinspection PyTestUnpassedFixture
                if status_order >= warning.order.pre_validation_status_order and \
                        warning not in self.printed_warnings:
                    print('\n' + str(warning), file=file)
                    self.printed_warnings.add(warning)

    @staticmethod
    def log_prevalidation_error(error: dict, method_id: str = "") -> None:
        """ log error on prevalidation configuring or running

        :param error: error
        """
        print(format_error_with_header(error['category'], error['header'], error['message'], error['solutionAdvice']))

    @staticmethod
    def log_validation_errors(validation_errors: list, method_id: str = "") -> None:
        """ log node errors on prevalidation running

        :param validation_errors: list of validatiom errors
        """
        if validation_errors is not None and len(validation_errors) > 0:
            for n, error in enumerate(validation_errors):
                log_error_with_contact_if_present(f'''{n + 1}.
    {format_error(error['message'], error['solutionAdvice'])}
                    ''')

    @staticmethod
    def log_node_errors(node_errors: list, method_id: str = "", from_error=0) -> None:
        """ log node errors on prevalidation running

        :param node_errors: list of node errors
        :param from_error: from which error need print, default=0 (all)
        """
        if node_errors is not None and len(node_errors) > 0:
            for n, error in enumerate(node_errors):
                if n >= from_error:
                    node_error_str = format_node_error(error, advice_override=(
                        ADVICE_MAP.get(error['code'], error['solutionAdvice'])), separator='    \n')
                    log_error_with_contact_if_present(f'''{n - from_error + 1}.    
    {node_error_str}     
                    ''')

    def log_no_validate_settings(self):
        print(
            f'{Colors.WARNING + "Обратите внимание!" + Colors.ENDC} {self.get_job_name().get(0, capital=True)} будет запущена без проверок параметра settings.')
        print(f'Если вы указали неверное значение одной из настроек, то проект исполнится с ошибкой.')

    @staticmethod
    def pretty_print(text, color=None, bg_color=None):
        reset_code = get_reset_code()
        bold_code = get_bold_code()
        color_codes = get_color_codes()
        bg_color_codes = get_bg_color_codes()
        output_text = ""
        if color is not None:
            output_text += color_codes.get(color.lower(), "")
        if bg_color is not None:
            output_text += bg_color_codes.get(bg_color.lower(), "")
        output_text += f"{bold_code}{text}{reset_code}"
        return output_text

    def print_feedback_promo(self):
        print()
        print(self.pretty_print(f'Оцените, пожалуйста, {self.get_job_name().get(3)}!', bg_color="yellow"))
        print()
        print("Сделайте сервис лучше, выполнив метод:")
        print(
            f'{self.pretty_print("auto_validator.send_feedback", color="purple")}(usability=None, valuability=None), где:')
        print(
            f'  - {self.pretty_print("usability", color="purple")} - насколько удобно было проводить {self.get_job_name().get(3)} (1 - совсем не удобно, 5 - очень удобно)')
        print(
            f'  - {self.pretty_print("valuability", color="purple")} - насколько полезна проведенная {self.get_job_name().get(0)} (1 - бесполезна, 5 - очень полезна)')

    def log_settings_applied_step(self):
        """ log on project settings applied step
        """

    def log_project_started_step(self, prevalidation_id: str):
        """ log on project created step
        """

    def log_questions(self, questions):
        """ log on questions
        """
    pass

    def wait_input(self) -> str:
        return ''

class LogProgressInterface(LogProgressInterfaceSimple):
    """ Интерфейс для показа прогресса превалидации """

    # log step methods

    def log_current_time(self, new_line=False):
        """ log current time
        :param new_line: check if need new line before
        """
        if new_line:
           print(f'\n{self.get_time()}')
        else:
           print(self.get_time())

    def log_submit_step(self, prevalidation_id: str, persistent_volume=None) -> None:
        """ log on submit step
        :param prevalidation_id: prevalidation ID
        """
        self.log_current_time()
        print(f'Запрос на {self.get_job_name().get(3)} принят. ID {self.get_job_name().get(1)}={prevalidation_id}')
        if is_dict_with_elements(persistent_volume):
            if persistent_volume.get('usePV', False):
                print(f'{self.get_job_name().get(0, capital=True)} будет запущена c PersistentVolume размером {persistent_volume.get("pvSize", 0)} GiB')

    def log_waiting_step(self) -> None:
        """ log on waiting step
        """
        print('.', end='')

    def log_queue_step(self) -> None:
        """ log on too long wait in queue step
        """
        print(f'Запрос на {self.get_job_name().get(3)} поставлен в очередь. Ожидание может занять некоторое время в зависимости '
             f'от нагрузки на сервис и инфраструктурных работ')

    def log_work_started_step(self) -> None:
        """ log on work started step
        """
        print(f'{self.get_job_name().get(0, capital=True)} взята в работу')

    def log_request_verified_step(self) -> None:
        """ log on request verified step
        """
        print(f'Настройки {self.get_job_name().get(1)} проверены')

    def log_data_verified_step(self) -> None:
        """ log on data verified step
        """
        print(f'Доступ к источнику данных проверен')

    def log_settings_applied_step(self) -> None:
        """ log on project settings applied step
        """
        print(f'Настройки {self.get_job_name().get(1)} применены')

    def log_project_started_step(self, prevalidation_id: str) -> None:
        """ log on project created step
        """
        print(f'{self.get_job_name().get(0, capital=True)} c ID={prevalidation_id} запущена')

    def log_questions(self, questions):
        """ log on questions
        """
        if questions is None or len(questions) == 0:
            return None, ''

        question = questions[0]
        request_id = question.get("questionRequestId", None)
        q_type = question.get("questionType", "INPUT")
        q_selection = question.get("questionSelection", [])
        q_text = question.get("questionText", "???")
        text = q_text if (q_type == "INPUT" or q_type == "NOTIFICATION") else f"{q_text}: {q_selection}?"

        if q_type == "NOTIFICATION":
            print(f"\n{Colors.WARNING + 'Получено уведомление от валидатора!' + Colors.ENDC}\n{text}")
            return request_id, 'default'

        print(f"\n{Colors.WARNING + 'Получен вопрос от валидатора!' + Colors.ENDC}\n{text}")
        if q_type == "INPUT":
            user_answer = self.wait_input()
            if is_empty(user_answer):
                user_answer = 'default'
            return request_id, user_answer
        else:
            selection = [sel.lower() for sel in q_selection]
            while True:
                answer = self.wait_input()
                if answer.lower() in selection:
                    return request_id, answer
                else:
                    print(f"Выберите, пожалуйста, один из вариантов ответа: {q_selection}")

    def wait_input(self) -> str:
        return input('')