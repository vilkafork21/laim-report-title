import time

from .tqdm.auto import trange

from .log_progress import LogProgressInterfaceSimple, LogProgressInterface
from ..context.constants import REQUEST_STATUS_LIST
from ..utils.conjugating_word import ConjugatingWord
from ..utils.text import not_empty

SUBMIT_WAIT_COUNT = 3
REQUEST_SLEEP_SEC = 5

REQUEST_SLEEP_SEC_BIG = 30
REQUEST_SLEEP_SEC_MED = 15


class PrevalidationRunner:

    def __init__(self, prevalidation, method_id, job_name: ConjugatingWord=None, auto_model=False, content_keeper = None,
                 timeout=None, internal=False,
                 question_service=None):
        self._prevalidation = prevalidation
        self._progress = LogProgressInterface(job_name=job_name)
        self._printed_errors = 0
        self._method_id = method_id
        self._auto_model = auto_model
        self._content_keeper = content_keeper
        self._internal = internal
        self._question_service = question_service

        if timeout is None:
            self.timeout_pipe = 10000000000
        else:
            self.timeout_pipe = time.time() + timeout

    def run_prevalidation(self, widget: LogProgressInterfaceSimple = None):
        if widget is not None:
            self._progress = widget

        self._estimate()

    def _estimate(self):
        self._progress._min_warn_order = None
        self._progress.log_warnings_step(self._prevalidation.get_warnings(), self._prevalidation.get_status())
        self._wait_prevalidation_configuring()
        if self._auto_model:
            self._wait_automodel_running()
        else:
            self._wait_prevalidation_running()

        if self._is_status_error(self._prevalidation.get_status()):
            self._progress.log_errors_step(self._prevalidation,
                                           self._prevalidation.get_error(),
                                           self._method_id,
                                           self._prevalidation.get_validation_errors(),
                                           self._prevalidation.get_nodes_errors())
        else:
            if self._prevalidation.get_status() in ['PAUSED'] or self.is_timeout:
                self._progress.log_project_paused_step()
            elif self._prevalidation.get_status() in ['TECHNICAL_PAUSED']:
                self._progress.log_project_technical_paused_step()
            elif self._prevalidation.get_status() in ['PUBLISHED']:
                self._progress.log_project_executed_step()
                self._progress.log_report_step(self._prevalidation.get_main_traffic_light(),
                                               self._prevalidation.get_main_traffic_light_info(),
                                               self._prevalidation.get_report_link(),
                                               self._prevalidation.get_project_link())
                self._progress.log_project_published_step()
            else:
                self._progress.log_project_executed_step()
                self._progress.log_report_step(self._prevalidation.get_main_traffic_light(),
                                               self._prevalidation.get_main_traffic_light_info(),
                                               self._prevalidation.get_report_link(),
                                               self._prevalidation.get_project_link())
                self._progress.print_feedback_promo()

    def _wait_prevalidation_configuring(self):
        _count = 0
        _dot_count = 0
        _last_status = 'SUBMITTED'
        self._progress.log_submit_step(self._prevalidation.prevalidation_id, persistent_volume=self._prevalidation.get_persistent_volume())

        self._prevalidation.update_current_status()
        while self._is_status_configuring(self._prevalidation.get_status()):
            _count += 1
            _status = self._prevalidation.get_request_status()
            if _status != _last_status:
                self._print_incoming_statuses(_status, _last_status, _dot_count > 0)
                _last_status = _status
                _dot_count = 0
            else:
                self._progress.log_waiting_step()
                _dot_count += 1

            if _last_status == 'SUBMITTED' and _count == SUBMIT_WAIT_COUNT:
                self._progress.log_current_time(_dot_count > 0)
                self._progress.log_queue_step()
                _dot_count = 0

            self._progress.log_warnings_step(self._prevalidation.get_warnings(), _status)

            time.sleep(REQUEST_SLEEP_SEC)
            self._prevalidation.update_current_status()

        # print all not printed conf statuses before exit
        _status = self._prevalidation.get_request_status()
        if _status != _last_status:
            self._print_incoming_statuses(_status, _last_status)

    def _print_incoming_statuses(self, _status, _last_status, new_line=False):
        _need_print = False
        for status in REQUEST_STATUS_LIST:
            if _need_print:
                self._progress.log_current_time(new_line)
                self._print_incoming_status(status)
            if status == _last_status:
                _need_print = True
            if status == _status:
                return

    def _wait_prevalidation_running(self):
        self._prevalidation.update_current_status()
        while not self.is_status_finished(self._prevalidation.get_status()):
            self._progress.log_warnings_step(self._prevalidation.get_warnings(), self._prevalidation.get_status())
            self._progress.log_progress_update(self._prevalidation.get_current_status())
            if self._content_keeper:
                self._content_keeper.update(prevalidation=self._prevalidation,
                                            keep_method_key=True)

            # check if we need answer to some question
            question_request_id, answer = self._progress.log_questions(self._prevalidation.get_questions())
            if not_empty(answer):
                self._question_service.send_answer(self._prevalidation.prevalidation_id, question_request_id, answer)

            time.sleep(REQUEST_SLEEP_SEC_BIG if self._internal else REQUEST_SLEEP_SEC_MED)
            self._prevalidation.update_current_status()
        self._progress.log_warnings_step(self._prevalidation.get_warnings(), self._prevalidation.get_status())

    def _wait_automodel_running(self):
        self._prevalidation.update_current_status()
        status = self._prevalidation.get_current_status()
        current_nodes_previous = 0
        for i in trange(int(status["nodes"]["all"]), desc=self._method_id):
            
            if i == int(status["nodes"]["all"]):
                return

            status = self._prevalidation.get_current_status()

            if self._is_status_error(self._prevalidation.get_status()):
                print('Ошибки выполнения нод')
                LogProgressInterfaceSimple.log_node_errors(status['projectNodeErrors'], self._method_id, self._printed_errors)
                return

            while self._prevalidation.get_current_status()["nodes"]["done"] == current_nodes_previous:
                time.sleep(REQUEST_SLEEP_SEC_BIG if self._internal else REQUEST_SLEEP_SEC_MED)
                self._prevalidation.update_current_status()

                if self.is_timeout:
                    print("Остановка проекта по тайм-ауту")
                    return

                if self.is_status_finished(self._prevalidation.get_status()):
                    break

            current_nodes_previous += 1

    @property
    def is_timeout(self):
        if time.time() > self.timeout_pipe:
            return True
        else:
            return False

    @staticmethod
    def is_status_finished(status) -> bool:
        return status in ['ERROR', 'DONE', 'PAUSED', 'TECHNICAL_PAUSED', 'PUBLISHED']

    @staticmethod
    def _is_status_error(status) -> bool:
        return status in ['ERROR']

    @staticmethod
    def _is_status_configuring(status) -> bool:
        return status in ['CONFIGURING']

    def _print_incoming_status(self, status):
        if status == 'WORK_STARTED':
            self._progress.log_work_started_step()
        elif status == 'REQUEST_VERIFIED':
            self._progress.log_request_verified_step()
        elif status == 'DATA_VERIFIED':
            self._progress.log_data_verified_step()
        elif status == 'PROJECT_CREATED':
            self._progress.log_project_created_step(self._prevalidation.get_project_link(), self._prevalidation.prevalidation_id)
        elif status == 'SETTINGS_APPLIED':
            self._progress.log_settings_applied_step()
        elif status == 'PROJECT_STARTED':
            self._progress.log_project_started_step(self._prevalidation.prevalidation_id)
        self._progress.on_status_change(new_status=status)
        self._progress.log_warnings_step(self._prevalidation.get_warnings(), status)
