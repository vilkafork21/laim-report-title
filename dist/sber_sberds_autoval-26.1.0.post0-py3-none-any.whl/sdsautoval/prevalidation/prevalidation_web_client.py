import abc
import json
import urllib.parse

from ..base_requester import BaseRequester
from ..utils.retry import withretry
from ..utils.text import not_empty


def progress_print_retry_message(count, total):
    print(f"Не удалось получить статус проекта, попытка {count} из {total}...")

def progress_retry_condition(e):
    from .. import SdsNotAuthorizedError, BadRequestError, ForbiddenError, UnauthorizedError, NotFoundError, \
        SdsBaseError
    no_retry_exceptions = [
        SdsNotAuthorizedError,
        BadRequestError,
        ForbiddenError,
        UnauthorizedError,
        NotFoundError
    ]
    for exception_class in no_retry_exceptions:
        if isinstance(e, exception_class):
            return False
    if isinstance(e, SdsBaseError):
        if "HTTP 400" in e.message or "HTTP 401" in e.message or "HTTP 403" in e.message or "HTTP 404" in e.message:
            return False
        if 'Проверьте параметры вызова' in e.advice:
            return False
    return True

class IPrevalidationWebClient:
    @abc.abstractmethod
    def create(self, parameters: dict) -> dict:
        """
        Create prevalidation on server (POST /validate)

        :param parameters: see convert_to_transport()
        :return:
         {
            "prevalidation_id": <String>,
            "projectId": <String>,
            "project_url": <String>,
            "status": "RUNNING"
         }
        """
        pass

    @abc.abstractmethod
    def create_all(self, parameters: dict) -> dict:
        """
        Create a bunch of autovalidations on server (POST /validate_all)

        :param parameters: see convert_to_transport_all()
        :return:
         {
            "runId": <String>
         }
        """
        pass

    @abc.abstractmethod
    def create_refits(self, parameters: dict) -> dict:
        """
        Create a bunch of refits on server (POST /api/refit/run_all)

        :param parameters: see convert_to_transport_all()
        :return:
         {
            "runId": <String>
         }
        """
        pass


    @abc.abstractmethod
    def get_current_status(self, prevalidation_id, need_process) -> dict:
        pass

    @abc.abstractmethod
    def get_current_status_all(self, run_id, trigger_node_id=None) -> dict:
        pass

    @abc.abstractmethod
    def stop(self, prevalidation_id, only_current=False):
        pass

    @abc.abstractmethod
    def stop_all(self, run_id):
        pass

    @abc.abstractmethod
    def resume(self, prevalidation_id, parameters: dict, only_current=False):
        pass

    @abc.abstractmethod
    def resume_all(self, run_id, parameters: dict):
        pass

    @abc.abstractmethod
    def get_status(self, prevalidation_id):
        pass

    @abc.abstractmethod
    def get_status_all(self, run_id):
        pass

    @abc.abstractmethod
    def get_prevalidations(self, params):
        pass

    @abc.abstractmethod
    def publish(self, prevalidation_id):
        pass

    @abc.abstractmethod
    def get_service_contacts(self, prevalidation_id):
        pass

    @abc.abstractmethod
    def get_settings(self, run_id=None, prevalidation_id=None, project_id=None, parent_project_id=None, trigger_node_id=None):
        pass

    @abc.abstractmethod
    def get_capabilities(self, method_id=None, project_area_id=None):
        pass

    @abc.abstractmethod
    def get_project_details(self, project_id=None):
        pass

class PrevalidationWebClient(IPrevalidationWebClient):
    _SERVICE_PATH = 'template-selector'
    _END_POINT = '/api/prevalidation'
    _REFIT_END_POINT = '/api/refit'
    _PROJECT_END_POINT = '/api/project'

    def __init__(self, host, session, token, is_internal=False):
        self._requester = BaseRequester(host, session, service_name=self.__class__._SERVICE_PATH)
        self._is_internal = is_internal
        self._token = token

    def create(self, parameters) -> str:
        end_point = f"{self._base_path()}/validate"
        data = json.dumps(parameters)

        response = self._requester.request(
            method='post',
            endpoint=end_point,
            headers=self._headers(self._token),
            data=data
        )

        return response.json()

    def create_all(self, parameters) -> str:
        end_point = f"{self._base_path()}/validate_all"
        data = json.dumps(parameters)

        response = self._requester.request(
            method='post',
            endpoint=end_point,
            headers=self._headers(self._token),
            data=data
        )

        return response.json()

    def create_refits(self, parameters) -> str:
        end_point = f"{self._base_refit_path()}/run_all"
        data = json.dumps(parameters)

        response = self._requester.request(
            method='post',
            endpoint=end_point,
            headers=self._headers(self._token),
            data=data
        )

        return response.json()

    @withretry(retries=15,
               retry_delay=[0, 3, 5, 10, 15],
               retry_condition=progress_retry_condition,
               retry_logger=progress_print_retry_message)
    def get_current_status(self, prevalidation_id, need_process):
        response = self._do_request(prevalidation_id, path='/progress', method='post', need_process=need_process)
        return response.json()

    def get_current_status_all(self, run_id, trigger_node_id=None):
        path = '/run_progress' if trigger_node_id is None else f'/run_progress?triggerNodeId={trigger_node_id}'
        response = self._do_request(run_id, path, method='post')
        return response.json()

    def get_prevalidations(self, params):
        end_point = f'{self._base_path()}/main_info'
        response = self._requester.request(
            method='post',
            endpoint=end_point,
            headers=self._headers(self._token),
            data=json.dumps(params)
        )
        return response.json()

    @withretry()
    def get_status(self, prevalidation_id):
        response = self._do_request(prevalidation_id, '/all_info')
        return response.json()

    def get_status_all(self, run_id, trigger_node_id=None):
        path = '/run_all_info' if trigger_node_id is None else f'/run_all_info?triggerNodeId={trigger_node_id}'
        response = self._do_request(run_id, path)
        return response.json()

    @withretry()
    def get_status_impl(self, prevalidation_id):
        return self._do_request_no_wrapper(prevalidation_id, '/all_info')

    def stop(self, prevalidation_id, only_current=False):
        link_part = '/stop?onlyCurrent=true' if only_current else '/stop'
        self._do_request(prevalidation_id, link_part, method='post')

    def stop_all(self, run_id, trigger_node_id=None):
        path = '/run_stop' if trigger_node_id is None else f'/run_stop?triggerNodeId={trigger_node_id}'
        self._do_request(run_id, path, method='post')

    def resume(self, prevalidation_id, parameters: dict, only_current=False):
        data = json.dumps(parameters)
        link_part = '/continue?onlyCurrent=true' if only_current else '/continue'
        self._do_request(prevalidation_id, link_part, data=data, method='post')

    def resume_all(self, run_id, parameters: dict):
        data = json.dumps(parameters)
        self._do_request(run_id, '/run_continue', data=data, method='post')

    def publish(self, prevalidation_id):
        response = self._do_request(prevalidation_id, '/publish', method='post')
        return response.json()

    @withretry()
    def get_service_contacts(self, prevalidation_id):
        # /api/prevalidation/get-service-contacts/{preValidationId}:
        end_point = f'{self._base_path()}/get-service-contacts/{prevalidation_id}'
        response = self._do_request_endpoint(end_point)
        return response.json()

    @withretry()
    def get_settings(self, run_id=None, prevalidation_id=None, project_id=None, parent_project_id=None, trigger_node_id=None):
        end_point = f'{self._base_path()}/parameters'
        params = {}
        if not_empty(run_id):
            params['runId'] = run_id
        if not_empty(prevalidation_id):
            params['preValidationId'] = prevalidation_id
        if not_empty(project_id):
            params['projectId'] = project_id
        if not_empty(parent_project_id):
            params['parentProjectId'] = parent_project_id
        if not_empty(trigger_node_id):
            params['triggerNodeId'] = trigger_node_id
        if len(params) > 0:
            end_point += '?' + urllib.parse.urlencode(params)
        return self._do_request_endpoint(end_point).json()

    @withretry()
    def get_capabilities(self, method_id=None, project_area_id=None):
        end_point = f'{self._base_path()}/capabilities'
        params = {}
        if not_empty(method_id):
            params['method_id'] = method_id
        if not_empty(project_area_id):
            params['project_area_id'] = project_area_id
        if len(params) > 0:
            end_point += '?' + urllib.parse.urlencode(params)
        return self._do_request_endpoint(end_point).json()

    @withretry()
    def get_project_details(self, project_id=None) -> str:
        end_point = f"{self._base_project_path()}/{project_id}/details"
        return self._do_request_endpoint(end_point).json()

    def _do_request(self, prevalidation_id, path='', data=None, method=None, need_process=True):
        end_point = f'{self._base_path()}/{prevalidation_id}{path}'
        return self._do_request_endpoint(end_point, method=method, data=data, need_process=need_process)

    def _do_request_endpoint(self, end_point, method='get', data=None, need_process=True):
        if method is None:
            real_method = 'get' if data is None else 'post'
        else:
            real_method = method
        return self._requester.request(
            method=real_method,
            endpoint=end_point,
            headers=self._headers(self._token),
            data=data,
            need_process=need_process
        )

    def _do_request_no_wrapper(self, prevalidation_id, path='', data=None, method=None):
        end_point = f'{self._base_path()}/{prevalidation_id}{path}'
        if method is None:
            real_method = 'get' if data is None else 'post'
        else:
            real_method = method

        return self._requester.request_no_wrapper(
            method=real_method,
            endpoint=end_point,
            headers=self._headers(self._token),
            data=data
        )

    def _base_path(self):
        return self._SERVICE_PATH + self._END_POINT if not self._is_internal else self._END_POINT

    def _base_refit_path(self):
        return self._SERVICE_PATH + self._REFIT_END_POINT if not self._is_internal else self._REFIT_END_POINT

    def _base_project_path(self):
        return self._SERVICE_PATH + self._PROJECT_END_POINT if not self._is_internal else self._PROJECT_END_POINT

    @staticmethod
    def _headers(token):
        return {
            'Accept': 'application/json',
            'Authorization': f'Bearer {token}',
            'Content-Type': 'application/json'
        }
