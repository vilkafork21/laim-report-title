from ..exceptions.sds_exceptions import SdsParamValidationError, SdsSettingsValidationError, \
    SdsColumnRolesValidationError
from ..method.method_models import MethodExtendedModel
from ..modprop import DataSample


class PreValidationSettings:
    """
    PreValidation run settings
    """

    @staticmethod
    def validate_params(model_version_id: int, method: MethodExtendedModel, samples: [DataSample], settings: dict,
                        finance=False, validate_settings=True):
        if model_version_id is None:
            raise SdsParamValidationError("model_version_id", "'model_version_id' должен быть заполнен")
        if method is None:
            raise SdsParamValidationError("model_version_id", "выберите методику при помощи метода auto_validator.select_method")

        # check samples exists
        if samples is None:
            raise SdsParamValidationError("Data[DataSample, DataArtifact]", "Data[DataSample, DataArtifact] должны быть заполнены")

        # check basic sample requirements
        data_sources = method.info.data_sources_sample + method.info.data_sources_artifact
        required_sample_types = [sample_type.key.upper() for sample_type in data_sources if sample_type.required]
        actual_sample_types = [sample.key.upper() for sample in samples]
        required_sample_types.sort()
        actual_sample_types.sort()
        if not set(required_sample_types).issubset(actual_sample_types):
            raise SdsParamValidationError("Data[DataSample, DataArtifact]", f'Data[DataSample, DataArtifact] не совпадают с требованиями методики {required_sample_types}')

        for sample in samples:
            sample.validate()

        _exclude_type = 'EXCLUDED'

        errors = []
        # check columns requirements (all columns in sample.selector are filled with type+role using defaults if needed)
        if method.columns and len(method.columns) > 0:
            _method_columns_with_excluded = [col.role.upper() for col in method.columns] + [_exclude_type]
            for sample in (_ for _ in samples if isinstance(_, DataSample)):
                if not sample.selector.defaultRole.upper() in _method_columns_with_excluded:
                    raise SdsParamValidationError("samples.column", f"дефолтная роль '{sample.selector.defaultRole}' отсутствует в методике")

            _method_roles = [col.get_role() for col in method.columns]
            _any_method_role = _method_roles[0]
            _any_method_types = [col.get_types() for col in method.columns if col.get_role().upper() == _any_method_role]

            for sample in (_ for _ in samples if isinstance(_, DataSample)):
                for name, col in sample.selector.rolesAndTypes.items():
                    col_role = col.get_role().upper()
                    col_def = [col_req for col_req in method.columns if col_req.role.upper() == col.role.upper()]
                    _not_excluded = col_role != _exclude_type
                    if (col_def is None or len(col_def) == 0) and _not_excluded:
                        errors.append({'message': f"Недопустимая роль {col_role} для колонки {name}. " +
                                                  f"Допустимы роли '{_method_roles}'",
                                       'solutionAdvice': f"Исправьте роль в sdk, например так: columns.add('{name}', " +
                                                         f"role='{_any_method_role}', column_type='{_any_method_types[0]}')"})
                    elif _not_excluded:
                        _req_types = [types.upper() for types in col_def[0].types]
                        _req_types.append('AUTO')
                        if sample.selector.rolesAndTypes[name].type.upper() not in _req_types:
                            errors.append({'message': f"Не соответствует тип для роли {col_role} в колонке {name}. " +
                                                      f"Задана роль {col_role} с типом {col.get_type().upper()}. "
                                                      f"Допустимы типы '{col_def[0].get_types()}'",
                                           'solutionAdvice': f"Задайте правильный тип колонки, например так: columns.add('{name}', " +
                                                             f"role='{col_role}', column_type='{_req_types[0]}')"})

            # not found in request but required
            for col in (_ for _ in method.columns if _.required):
                for sample in (_ for _ in samples if isinstance(_, DataSample)):
                    col_def = [col_req for col_req in sample.selector.rolesAndTypes if sample.selector.rolesAndTypes[col_req].role.upper() == col.role.upper()]
                    if (col_def is None or len(col_def) == 0) and col.role.upper() != sample.selector.get_default_role().upper():
                        errors.append({'message': f"Не задана обязательная роль {col.get_role()}. " +
                                                  f"Требуется колонка с ролью {col.get_role()} и одним из типов {col.get_types()}.",
                                       'solutionAdvice': f"Исправьте роль в sdk, например так: columns.add('<<name>>', role='{col.get_role()}', column_type='{col.get_types()[0]}')"})

        else:
            # 1 No requrements for columns in methodics
            # 2 sample columns has default role = excluded
            # 3 no other columns(with role !=excluded) defined
            PreValidationSettings.check_excluded_columns(method, samples, errors, finance)
        if len(errors) > 0:
            raise SdsColumnRolesValidationError(errors)

        if validate_settings:
            PreValidationSettings.check_setting(method.settings, settings)

    @staticmethod
    def check_excluded_columns(method, samples, errors, finance):
        _exclude_type = 'EXCLUDED'
        for sample in (_ for _ in samples if isinstance(_, DataSample) and _.selector.get_default_role().upper() == _exclude_type):
            if sample.selector.rolesAndTypes is None \
                or len(sample.selector.rolesAndTypes) == 0 \
                or all(val.role is None or val.role.upper() == _exclude_type for val in sample.selector.rolesAndTypes.values()):
                    main_class = 'financial_effect_estimator' if finance else 'auto_validator'
                    errors.append({'message': f"Для DataSample key='{sample.key}', необходимо разметить минимум одну колонку ролью, отличной от '{_exclude_type.lower()}'.\n"
                                             f"То, какую разметку ожидает получить выбранная методика {method.info.method_key} можно найти в разделе Требования к методике " +
                                             f"после выполнения {main_class}.select_method('{method.info.method_key}').\n"
                                             f"Если требований к разметке нет - укажите в ColumnsSelector параметр default_role = 'input' (ColumnsSelector(default_role: str = 'input')).",
                                  'solutionAdvice': f"Разметьте колонки датасета key='{sample.key}' согласно требованиям методики, методом columns.add('<<name>>', role='<<role>>', column_type='<<type>>').\n"
                                                    f" Пример: columns.add([col_name_1, col_name_2], role='input', column_type='interval')."})

    @staticmethod
    def check_setting(config: dict, setting: dict):
        supported = config is not None and 'groups' in config and bool(config['groups'])

        if not supported and setting:
            raise SdsParamValidationError("settings_validation", "данная методика не поддерживает настройки")

        if not supported and not setting:
            return

        groups: dict = config['groups']

        for key, value in groups.items():
            if value['requirements']:
                if not (key in setting):
                    raise SdsSettingsValidationError(f"Не указан обязательный параметр {key}", "добавьте настройку")

        for key in setting:
            if not (key in groups):
                raise SdsSettingsValidationError(f"Неизвестный параметр '{key}'", f"Допустимые параметры: {list(groups.keys())}")
