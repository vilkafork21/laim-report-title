# custom solution advice map {code: advice}
ADVICE_MAP = {'AUTO-0018': 'Запустите функцию run, указав параметр resources, укажите значение памяти и cpu больше чем '
                           'при текущем запуске'}
