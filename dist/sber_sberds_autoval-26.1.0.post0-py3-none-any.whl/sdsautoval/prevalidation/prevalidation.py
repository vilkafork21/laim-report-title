from sdsautoval.warnings import SdsWarning
from .error_helper import ADVICE_MAP
from .prevalidation_runner import PrevalidationRunner, LogProgressInterfaceSimple
from .prevalidation_web_client import IPrevalidationWebClient
from ..utils.args import is_dict_with_elements
from ..context.constants import DEFAULT_SERVICE_CONTACTS
from ..error_util import format_node_error
from ..utils.conjugating_word import ConjugatingWord
from ..zone_util import ZoneUtil

PV_STATUS_UNKNOWN = 'unknown'
PV_STATUS_EXISTS = 'exists'
PV_STATUS_NONE = 'none'


class Prevalidation:
    def __init__(self, client: IPrevalidationWebClient, host: str, parameters, zone: ZoneUtil, internal=False):
        self._pv_status = PV_STATUS_UNKNOWN
        self._client = client
        self._host = host
        self._parameters = parameters
        self.prevalidation_id = None
        self.project_id = None
        self._current_status = None
        self._zone = zone
        self.persistent_volume = None
        self._service_contacts = None
        self._internal = internal
        self.run_id = None

    def get_method_id(self):
        if self._parameters:
            return self._parameters.get('methodId', None)
        else:
            return None

    def create(self):
        prevalidation = self._client.create(self._parameters)
        self.prevalidation_id = prevalidation['preValidationId']
        self._current_status = {'status': 'CONFIGURING'}
        self.persistent_volume = prevalidation.get('persistent_volume', None)

    def create_all(self):
        prevalidation = self._client.create_all(self._parameters)
        self.run_id = prevalidation['runId']
        print(f'Run {self.run_id} was started')

    def get_prevalidations_id(self, run_id=None, trigger_node_id=None):
        run_id = run_id if run_id else self.run_id
        trigger_node_id = trigger_node_id if trigger_node_id else self.get_trigger_node_id()

        all_status = self._client.get_current_status_all(run_id, trigger_node_id=trigger_node_id)
        return [status['preValidationId'] for status in all_status]

    def set_existed_prevalidation(self, prevalidation_id):
        self.prevalidation_id = prevalidation_id
        self._current_status = {'status': 'CONFIGURING'}
        self.persistent_volume = self._client.get_status(self.prevalidation_id).get('persistentVolume', None)

    def start(self, method_id: str = "", job_name: ConjugatingWord = None, widget: LogProgressInterfaceSimple=None,
              auto_model: bool = False, content_keeper=None, timeout=None, question_service=None):
        PrevalidationRunner(self, method_id=method_id, job_name=job_name, auto_model=auto_model,
                            content_keeper=content_keeper, timeout=timeout, internal=self._internal,
                            question_service=question_service).run_prevalidation(
            widget)

    def update_current_status(self):
        try:
            self._current_status = self._client.get_current_status(self.prevalidation_id,
                                                                   True)
        except Exception as ex:
            print(f"Не удалось получить статус проекта")
            raise ex

    def get_current_status(self):
        return self._current_status

    def get_status(self):
        if not self._current_status:
            return ''
        return self._current_status['status']

    def get_request_status(self):
        if not self._current_status:
            return ''
        return self._current_status['requestStatus']

    def get_error(self) -> any:
        if not self._current_status:
            return None
        if 'error' in self._current_status:
            return self._current_status['error']
        return None

    def get_validation_errors(self) -> list:
        if not self._current_status:
            return []
        if 'validationErrors' in self._current_status:
            return self._current_status['validationErrors']
        return []

    def get_nodes_errors(self) -> list:
        if not self._current_status:
            return []
        if 'projectNodeErrors' in self._current_status:
            return self._current_status['projectNodeErrors']
        return []

    def get_warnings(self) -> list:
        return SdsWarning.convert_list(self.get_raw_warnings())

    def get_raw_warnings(self) -> list:
        if not self._current_status:
            return []
        if 'warnings' in self._current_status:
            return self._current_status['warnings']
        return []

    def get_error_text(self) -> str:
        error = self.get_error()
        if error is not None and len(error) > 0:
            return error

        error = self.get_validation_errors()
        if error is not None and len(error) > 0:
            return f"Validation errors: {', '.join([err['message'] for err in error])}"

        error = self.get_nodes_errors()
        if error is not None and len(error) > 0:
            node_errors = '\n'.join([format_node_error(err,
                                                       advice_override=ADVICE_MAP
                                                       .get(err['code'],
                                                            err['solutionAdvice']),
                                                       separator=', ')
                                     for err in error])
            return f"Node errors: {node_errors}"

        return ''

    def get_main_traffic_light(self):
        if not self._current_status:
            return ''
        if 'mainTrafficLight' in self._current_status:
            return self._current_status['mainTrafficLight']
        return ''

    def get_main_traffic_light_info(self):
        if not self._current_status:
            return dict()
        if 'mtlInfo' in self._current_status:
            return self._current_status['mtlInfo']
        return dict()

    def get_project_link(self):
        if not self._current_status:
            return ''
        if 'projectUrl' in self._current_status and self._current_status['projectUrl']:
            return self._update_link(self._current_status['projectUrl'])

        return ''

    def get_report_link(self):
        if not self._current_status:
            return ''
        if 'reportUrl' in self._current_status and self._current_status['reportUrl']:
            return self._update_link(self._current_status['reportUrl'])
        return ''

    def _update_link(self, link: str):
        return self._zone.convert_link(link, self._host)

    def get_model_version_id(self):
        return self._parameters.get('modelVersionId', None)

    def get_run_id(self):
        return self._parameters.get('runId', None)

    def get_run_group_id(self):
        return self._parameters.get('runGroupId', None)

    def get_parent_project_id(self):
        return self._parameters.get('parentProjectId', None)

    def get_trigger_node_id(self):
        if isinstance(self._parameters, list):
            return self._parameters[0].get('triggerNodeId', None)
        return self._parameters.get('triggerNodeId', None)

    def get_persistent_volume(self, force_update=False):
        if self._pv_status == PV_STATUS_NONE and not force_update:
            return None
        if is_dict_with_elements(self.persistent_volume):
            return self.persistent_volume
        prevalidation_all_info = self._client.get_status(self.prevalidation_id)
        self.persistent_volume = prevalidation_all_info.get('persistentVolume', None)
        if not is_dict_with_elements(self.persistent_volume):
            self._pv_status = PV_STATUS_NONE
        else:
            self._pv_status = PV_STATUS_EXISTS
        return self.persistent_volume

    def get_service_contacts(self):
        if self._service_contacts is None:
            try:
                self._service_contacts = self._client.get_service_contacts(self.prevalidation_id)
            except Exception as _:
                pass
        if self._service_contacts is None or len(self._service_contacts) == 0:
            self._service_contacts = DEFAULT_SERVICE_CONTACTS
        return self._service_contacts

    def get_questions(self):
        if not self._current_status:
            return []
        if 'questions' in self._current_status:
            return self._current_status['questions']
        return []

    def __repr__(self):
        return f'Prevalidation with id {self.prevalidation_id}'
