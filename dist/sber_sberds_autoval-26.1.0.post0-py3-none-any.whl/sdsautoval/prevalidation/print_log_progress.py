from .log_progress import LogProgressInterface, LogProgressInterfaceSimple
from ..utils.conjugating_word import ConjugatingWord
from ..util import pretty_json

class PrintLogProgress(LogProgressInterface):
    """ Log progress as text. """
    
    def __init__(self, job_name: ConjugatingWord = None):
        super().__init__(job_name=job_name)
        self._last_status = None
        self._need_newline = False
        self._printed_errors = 0

    def log_progress_update(self, status: dict) -> None:
        log = f'status={status["status"]} nodes={status["nodes"]}'
        if log == self._last_status:
            print('.', end='')
            self._need_newline = True
        else:
            self._last_status = log
            if self._need_newline:
                print(f'\n{self.get_time()}')
            else:
                print(self.get_time())
            self._need_newline = False
            print(f'Выполнено узлов: {status["nodes"]["done"]} / {status["nodes"]["all"]}')
            print(f'выполняются {status["nodes"]["launched"]}')
            print(f'(ошибок: {status["nodes"]["error"]})')
            if 'projectNodeErrors' in status and status['projectNodeErrors'] is not None and len(status['projectNodeErrors']) > 0:
                if self._printed_errors < len(status['projectNodeErrors']):
                    print('Ошибки выполнения нод')
                    LogProgressInterface.log_node_errors(status['projectNodeErrors'], "", self._printed_errors)
                    self._printed_errors = len(status['projectNodeErrors'])

    def log_report_step(self, main_traffic_light,
                        main_traffic_light_info: dict,
                        report_url, link_to_workflow_ui) -> None:
        print(self.get_time())
        print(f'Результат: {main_traffic_light}')
        if main_traffic_light_info is not None:
            print(f'Информация по светофору:\n {pretty_json(main_traffic_light_info)}')
        print(f'Ссылка на отчет: {report_url}')
        print(f'Ссылка на проект: {link_to_workflow_ui}')
        if report_url is None:
            print('Отчет не сформирован')

        print(f'Для доступа к отчету и проекту {self.get_job_name().get(1)} необходимо заходить в SberDS из той же зоны в которой запущена {self.get_job_name().get(0)}.')
        print(f'При скачивании отчета из SberDS в дополнительных настройках необходимо указать галочку Фон.')



class PrintBarProgress(LogProgressInterfaceSimple):
    """Progress bar with thread safe tqdm"""
    def log_progress_update(self, status: dict) -> None:
        """ Log process """
