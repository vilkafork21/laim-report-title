from .prevalidation_web_client import IPrevalidationWebClient
from ..zone_util import ZoneUtil


class PreValidationRun:
    def __init__(self, client: IPrevalidationWebClient, host: str, parameters, zone: ZoneUtil):
        self._client = client
        self._host = host
        self._parameters = parameters
        self.run_id = None
        self._zone = zone

    def create(self):
        run = self._client.create_all(self._parameters)
        self.run_id = run['runId']
        print(f'Run {self.run_id} was started')

    def create_refits(self):
        run = self._client.create_refits(self._parameters)
        self.run_id = run['runId']
        print(f'Run {self.run_id} was started')

    def __repr__(self):
        return f'Run with id {self.run_id}'
