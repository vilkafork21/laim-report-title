from .error_helper import ADVICE_MAP
from ..colors import Colors
from ..error_util import format_error, format_node_error


def update_prevalidation_node_errors(prevalidation: dict):
    node_errors = prevalidation['project_node_errors']
    error_message = ''
    if node_errors is not None and len(node_errors) > 0:
        for n, error in enumerate(node_errors):
            error_message += f"{n + 1}.\n"
            error_message += f"{format_node_error(error, advice_override=(ADVICE_MAP.get(error['code'], error['solutionAdvice'])))}"

    prevalidation['project_node_errors'] = error_message
