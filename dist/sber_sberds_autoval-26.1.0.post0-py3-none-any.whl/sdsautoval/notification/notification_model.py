import textwrap
from datetime import datetime

RELEASE_NOTE_TYPE = 'Release Notes'
SYSTEM_LIMITATION_TYPE = 'Info'

AREAS_DICT = {
    'UB risks autovalidation': 'Риски УБ',
    'autovalidation': 'Тестовый',
    'av_service': 'Сервисы',
    'av_hr': 'HR',
    'av_rb': 'B2C',
    'av_fin_estimate': 'Пилотный (Финансы)',
    'av_grc': 'GRC',
    'av_kib': 'КИБ',
    'av_risks_rb': 'Риски B2C',
    'av_risks_kib': 'Риски КИБ',
    'av_sp': 'Сеть продаж',
    'av_technology': 'Технологии',
    'av_fin': 'Финансы',
    'ab_cib': 'КИБ (A/B тестирование)',
    'ab_sp': 'Сеть продаж (A/B тестирование)'
}


class NotificationModel:
    """ Notification model.

    Attributes:
        type              notification type
        summary           notification summary
        text              notification text
        projectAreaNames  notification projectAreaNames (in case notification specific to areas)
        update_date       notification update datetime
    """
    def __init__(self, type, summary, text, project_area_names, update_date):
        self.type = type
        self.summary = summary
        self.text = text
        self.project_area_names = project_area_names
        self.update_date = datetime.strptime(update_date, '%Y-%m-%dT%H:%M:%S.%fZ')

    def print_text(self):
        print(f'  {self.summary}')
        print(textwrap.indent(f'{self.text}\n', '    '))

    @staticmethod
    def convert_block(code):
        return AREAS_DICT.get(code, code)
