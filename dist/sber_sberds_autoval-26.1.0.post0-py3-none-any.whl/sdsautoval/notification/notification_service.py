from .notification_model import NotificationModel, RELEASE_NOTE_TYPE, SYSTEM_LIMITATION_TYPE
from .notification_web_client import NotificationWebClient
from ..colors import FText


class NotificationService:

    def __init__(self, host, session, token, is_internal=False):
        self._host = host
        self._session = session
        self._token = token
        self._client = NotificationWebClient(host, session, token, is_internal)

    def print_on_start(self, project_area_type: str):
        notifications = []
        try:
            notifications = self._client.get_on_start(project_area_type)
        except Exception:
            pass

        release_notes = list(filter(lambda n: n.get('type', 0) == RELEASE_NOTE_TYPE, notifications))
        limitations = list(filter(lambda n: n.get('type', 0) == SYSTEM_LIMITATION_TYPE, notifications))

        if len(release_notes) > 0:
            print('\n\nОбратите внимание на Release Notes:')
            self._print_text_notes(release_notes, "Release Notes")
            print(f'Для прочтения всех Release notes вызовите '
                  f'{NotificationService._get_example_name(project_area_type)}.get_release_notes()')
        if len(limitations) > 0:
            print('\n\n' + FText.yellow('Обратите внимание') + ' на Уведомления:')
            self._print_text_notes(limitations, "Уведомления")

    def print_release_notes(self, project_area_type: str, limit: int):
        notifications = self._client.get_release_notes(project_area_type)
        common_notes = list(filter(lambda n: len(n.get('projectAreaNames', [])) == 0, notifications))
        area_notes = list(filter(lambda n: len(n.get('projectAreaNames', [])) > 0, notifications))

        if len(common_notes) > 0:
            print('\nRelease Notes:')
            NotificationService._print_notes_group("Release Notes", None, common_notes, limit)
        if len(area_notes) > 0:
            area_note_groups = {}
            for note in area_notes:
                areas_key = NotificationService._get_areas_key(note['projectAreaNames'])
                if areas_key not in area_note_groups:
                    area_note_groups[areas_key] = []
                area_note_groups[areas_key].append(note)

            for key, value in area_note_groups.items():
                NotificationService._print_notes_group("Release Notes", key, value, limit)

    @staticmethod
    def _print_text_notes(notes, prefix):
        common_notes = list(filter(lambda n: len(n.get('projectAreaNames', [])) == 0, notes))
        area_notes = list(filter(lambda n: len(n.get('projectAreaNames', [])) > 0, notes))

        NotificationService._print_notes_group(prefix, None, common_notes)

        area_note_groups = {}
        for note in area_notes:
            areas_key = NotificationService._get_areas_key(note['projectAreaNames'])
            if areas_key not in area_note_groups:
                area_note_groups[areas_key] = []
            area_note_groups[areas_key].append(note)

        for key, value in area_note_groups.items():
            NotificationService._print_notes_group(prefix, key, value)

    @staticmethod
    def _print_notes_group(prefix, area_names, area_notes, limit=-1):
        if area_names is not None:
            NotificationService._print_title_part(prefix, area_names)

        sorted_notes = sorted(area_notes, key=lambda d: d['updateDate'], reverse=True)
        if limit > 0:
            sorted_notes = sorted_notes[:limit]
        for sorted_note in sorted_notes:
            note = NotificationService.convert_response(sorted_note)
            note.print_text()

    @staticmethod
    def _print_title_part(prefix, project_area_names):
        parts = project_area_names.split(", ")
        if len(parts) > 1:
            print(f'{prefix} для блоков {", ".join(map(NotificationModel.convert_block, parts))}:')
        else:
            print(f'{prefix} для блока {", ".join(map(NotificationModel.convert_block, parts))}:')

    @staticmethod
    def _get_areas_key(area_names: list) -> str:
        return ", ".join(sorted(area_names))

    @staticmethod
    def convert_response(response):
        return NotificationModel(
            response['type'],
            response['summary'],
            response['text'],
            response['projectAreaNames'],
            response['updateDate'])

    @staticmethod
    def _get_example_name(project_area_type) -> str:
        if project_area_type == 'ab_testing':
            return 'financial_effect_estimator'
        else:
            return 'auto_validator'
