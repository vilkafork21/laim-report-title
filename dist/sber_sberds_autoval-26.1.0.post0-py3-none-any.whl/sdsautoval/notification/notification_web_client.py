import urllib

from .notification_model import RELEASE_NOTE_TYPE, SYSTEM_LIMITATION_TYPE
from ..base_requester import BaseRequester
from ..utils.retry import withretry


class NotificationWebClient:
    _SERVICE_PATH = 'template-selector'
    _END_POINT = '/api/notification'

    def __init__(self, host, session, token, is_internal=False):
        self._requester = BaseRequester(host, session, service_name=self.__class__._SERVICE_PATH)
        self._is_internal = is_internal
        self._token = token

    @withretry()
    def get_on_start(self, project_area_type):
        """
        Get active notifications on start
        :param project_area_type project area type (autovalidation, ab_testing)

        :return: notifications list
        """
        url = urllib.parse.quote_plus(
            f"{self._base_path()}?projectAreaType={project_area_type}"
            f"&notificationTypes={RELEASE_NOTE_TYPE}&notificationTypes={SYSTEM_LIMITATION_TYPE}"
            f"&notificationActive=true", safe='/?&=')

        response = self._requester.request(
            method='get',
            endpoint=url,
            headers=self._headers(self._token)
        )
        return response.json()

    @withretry()
    def get_release_notes(self, project_area_type):
        """
        Get release notes
        :param project_area_type project area type (autovalidation, ab_testing)

        :return: notifications list
        """
        url = urllib.parse.quote_plus(
            f"{self._base_path()}?projectAreaType={project_area_type}"
            f"&notificationTypes={RELEASE_NOTE_TYPE}"
            f"&notificationActive=false", safe='/?&=')

        response = self._requester.request(
            method='get',
            endpoint=url,
            headers=self._headers(self._token)
        )
        return response.json()

    def _base_path(self):
        return self._SERVICE_PATH + self._END_POINT if not self._is_internal else self._END_POINT

    @staticmethod
    def _headers(token):
        return {
            'Authorization': f'Bearer {token}',
        }
