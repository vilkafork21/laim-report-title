class VersionModel:
    """ Version model.

    Attributes:
        minimal_version        minimum version
        current_version        current version
        result                 OK, COMPATIBLE, NEED_UPGRADE
    """

    def __init__(self, json):
        self.minimal_version = json['minimalVersion']
        self.current_version = json['currentVersion']
        self.result = json['result']
