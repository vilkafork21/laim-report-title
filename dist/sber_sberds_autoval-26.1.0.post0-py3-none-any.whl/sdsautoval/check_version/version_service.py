from .version_web_client import VersionWebClient
from .version_model import VersionModel


class VersionService:
    def __init__(self, host, session, token, is_internal=False):
        self._host = host
        self._session = session
        self._token = token

        self._client = VersionWebClient(host, session, token, is_internal)

    def check_version(self, version: str) -> VersionModel:
        version_response = self._client.check(version)
        return VersionModel(version_response)

