from ..base_requester import BaseRequester, custom_retry_condition
from ..exceptions.exceptions import BadRequestError, ForbiddenError, UnauthorizedError
from ..utils.retry import withretry


class IVersionWebClient:
    def check(self, sdk_version: str):
        """
        Checks version

        :sdk_version: sdk version
        :return: sdk version response json
        """
        pass


class VersionWebClient(IVersionWebClient):
    _SERVICE_PATH = 'template-selector'
    _END_POINT = '/api/version'

    def __init__(self, host, session, token, is_internal=False):
        self._requester = BaseRequester(host, session, service_name=self.__class__._SERVICE_PATH)
        self._is_internal = is_internal
        self._token = token

    @withretry(retry_condition=custom_retry_condition(
        abort_on_exceptions=[BadRequestError, ForbiddenError, UnauthorizedError]))
    def check(self, sdk_version: str):
        end_point = f"{self._base_path()}?sdkVersion={sdk_version}"
        response = self._requester.request(
            method='post',
            endpoint=end_point,
            headers=self._headers(self._token),
        )

        return response.json()

    def _base_path(self):
        return self._SERVICE_PATH + self._END_POINT if not self._is_internal else self._END_POINT

    @staticmethod
    def _headers(token):
        return {
            'Authorization': f'Bearer {token}',
        }
