from urllib.parse import urlparse, urlunparse

from sdsautoval.context.user_context import UserContext

zone_hosts = {
    'ALPHA_CRIT': 'office.sberds.omega.sbrf.ru',
    'ALPHA_NONCRIT': 'remote.sberds.omega.sbrf.ru',
    'ALPHA_DFCRIT': 'df-office.sberds.omega.sbrf.ru',
    'ALPHA_DFNONCRIT': 'df-remote.sberds.omega.sbrf.ru'
}


class ZoneUtil:
    def __init__(self, zone):
        self._zone = zone
        if zone is None:
            self._zone_host = None
        else:
            self._zone_host = zone_hosts.get(zone, None)

    def substitute_host(self, url: str):
        if url is None or not isinstance(url, str):
            return url
        url = url.strip()
        if len(url) <= 0:
            return url
        if (not UserContext.get().should_substitute_host()) or \
                self._no_host_for_zone():
            return url
        else:
            parsed_url = urlparse(url)
            # noinspection PyProtectedMember
            replaced = parsed_url._replace(netloc=str(self._zone_host))
            return urlunparse(replaced)

    def convert_link(self, link: str, host: str):
        converted_link = link
        if host and not link.startswith(host):
            idx = link.find('/group/')
            if idx > 0:
                converted_link = f'{host.strip("/")}{link[idx:]}'
        if self._zone is not None:
            return self.substitute_host(str(converted_link))
        return ZoneUtil.ensure_slash_de(converted_link)

    @staticmethod
    def zone_host_de_in(url: str) -> bool:
        if url is None or not isinstance(url, str):
            return False
        for name, host in zone_hosts.items():
            if f'{host}/de/' in url:
                return True
        return False

    @staticmethod
    def ensure_slash_de(url: str):
        if url is None or not isinstance(url, str):
            return url
        if UserContext.get().internal_auth and not ZoneUtil.zone_host_de_in(url):
            parsed_url = urlparse(url)
            # noinspection PyProtectedMember
            replaced = parsed_url._replace(path=f'/de{parsed_url.path}')
            return urlunparse(replaced)
        return url

    def update_prevalidation_info(self, prevalidation: dict, host: str):
        if prevalidation['project_url'] and isinstance(
                prevalidation['project_url'], str):
            prevalidation['project_url'] = self.convert_link(
                prevalidation['project_url'], host)
        if prevalidation['report_url'] and isinstance(
                prevalidation['report_url'], str):
            prevalidation['report_url'] = self.convert_link(
                prevalidation['report_url'], host)
        prevalidation['sberds_zone'] = prevalidation['sberdsZone']
        del prevalidation['sberdsZone']

    def _no_host_for_zone(self):
        return self._zone_host is None or not isinstance(self._zone_host, str)
