import json
import time

from sdsautoval.context.constants import SBERDS_MAIL
from .utils.conjugating_word import ConjugatingWord
from .utils.misc import get_responsible_users_publish, get_service_contacts_publish
from .zone_util import ZoneUtil


class _Publisher:

    def __init__(self, prevalidation_id, status_requester, wait_timeout, host, zone: ZoneUtil, job_name: ConjugatingWord):
        self._prevalidation_id = prevalidation_id
        self.status_requester = status_requester
        self.wait_timeout = wait_timeout
        self.host = host
        self._zone = zone
        self.job_name = job_name

    def process_response(self, response):
        result = response['result']
        message = response['message']
        success = response['success']

        success_response = True

        responsible_users = get_responsible_users_publish(response)
        service_contacts = get_service_contacts_publish(response)
        service_contacts = [contact for contact in service_contacts if contact.get('serviceName', None) is not None]
        filtered_service_contacts = []
        for contact in service_contacts:
            if contact.get('serviceName', None) is not None:
                item = f'{contact["description"]}: <{contact.get("email", "нет почты")}>'
                if item not in service_contacts:
                    filtered_service_contacts.append(item)
        service_contacts_str = '\n'.join(filtered_service_contacts)

        or_service_contacts = f'или на почту {SBERDS_MAIL}'
        if len(service_contacts_str) > 0:
            or_service_contacts = f'или по одному из сервисных контактов:\n{service_contacts_str}'


        if result == 'ALREADY_PUBLISHING':
            print(
                f'Запрос на публикацию результатов {self.job_name.get(2)} с ID=\'{str(self._prevalidation_id)}\' уже был создан ранее. Узнать статус можно, выполнив auto_validator.get_status(\'{str(self._prevalidation_id)}\'). '
                f'Если увидите ошибочный статус - внесите исправления согласно рекомендациям и повторите публикацию через 5 минут.'
            )

        elif result == 'ALREADY_PUBLISHED':
            print(
                f'Результаты {self.job_name.get(2)} с ID=\'{str(self._prevalidation_id)}\' '
                f'были опубликованы ранее. Если в Библиотеке Моделей отображаются некорректные результаты - обратитесь в службу поддержки через метод auto_validator.create_issue {or_service_contacts}'
            )

        elif result == 'INVALID_STATUS':
            print(
                f'Публикация результатов {self.job_name.get(2)} с ID=\'{str(self._prevalidation_id)}\' '
                f'пока невозможна, потому что она не была успешно завершена. Попробуйте продолжить указанную {self.job_name.get(3)} / создайте новую или обратитесь в службу поддержки через метод auto_validator.create_issue {or_service_contacts}'
            )

        elif not success:
            if result == 'NO_RIGHT_TO_PUBLISH_RED_MTL':
                project_url = response.get('projectUrl', '')
                if project_url and len(project_url) > 0:
                    project_url = self._zone.convert_link(project_url, self.host)
                if len(responsible_users) == 0:
                    responsible_users = get_responsible_users_publish(response)
                resp_text = ""
                for user in responsible_users:
                    resp_text += user['fullName']
                    if 'email' in user:
                        resp_text += f" ({user['email']})\n"
                    else:
                        resp_text += "\n"

                print(f"Запрос на публикацию результатов {self.job_name.get(2)} ID='{str(self._prevalidation_id)}' невозможно отправить.")
                print(f"Вы пытаетесь опубликовать в Библиотеку Моделей результат {self.job_name.get(2)} с красным итоговым светофором (RED).\n")
                print(f"Это можно сделать только через ответственного Валидатора, для этого напишите сообщение на почту")
                print(f"{resp_text}")
                print(f"Можете использовать текст ниже для сообщения валидатору:\n")
                print(f"Коллеги, добрый день!")
                print(f"Хочу опубликовать в БМ {self.job_name.get(3)} с результатом RED")
                print(f"{project_url}")
            else:
                print(
                    f'Запрос на публикацию результатов {self.job_name.get(2)} ID=\'{str(self._prevalidation_id)}\' '
                    f'невозможно отправить. System Message: {message}. Обратитесь в службу поддержки через метод auto_validator.create_issue {or_service_contacts}'
                )

        else:
            print(
                f'Запрос на публикацию {self.job_name.get(2)} с ID=\'{str(self._prevalidation_id)}\' успешно '
                'создан. Ожидаем ответ от Библиотеки Моделей...', end=""
            )
            wait_result = self._wait_publishing()

            if wait_result == 'published':
                print(
                    f'Результаты превалидации с ID=\'{str(self._prevalidation_id)}\' успешно '
                    'опубликованы'
                )

            elif wait_result == 'timeout':
                print(
                    f'Не удалось дождаться окончания публикации результатов {self.job_name.get(2)} '
                    f'с ID=\'{str(self._prevalidation_id)}\' за время timeout=\'{self.wait_timeout} с\'. Но публикация продолжается - можете узнать её статус, выполнив '
                    f'auto_validator.get_status(\'{str(self._prevalidation_id)}\')'
                )

            else:
                print(
                    f'Публикация {self.job_name.get(2)} с ID=\'{str(self._prevalidation_id)}\' завершилась с ошибкой'
                )
                success_response = False
        
        return success_response

    def _wait_publishing(self):
        sleeps = [3, 2, 1]
        other_sleep = 5
        counter = 0
        end = time.time() + self.wait_timeout
        while time.time() < end:
            if len(sleeps) > 0:
                time.sleep(sleeps.pop())
            else:
                time.sleep(other_sleep)
            status = self.status_requester(self._prevalidation_id)
            if counter > 0:
                print('.', end='')
            counter += 1
            if 'publish_status' in status and status['publish_status'] is not None:
                if status['publish_status'] == 'SUCCESS':
                    print()
                    return 'published'
                else:
                    # be sure we use same publish_request_id
                    if 'publish_request_id' in status and status['publish_request_id'] is not None:
                        if 'publish_response' in status and status['publish_response'] is not None:
                            pr = status.get("publish_response")
                            pr = json.loads(pr if pr else "{}")
                            error_request_id = pr.get("requestId", '')
                            if error_request_id == status['publish_request_id']:
                                print()
                                return 'error'
        print()
        return 'timeout'
