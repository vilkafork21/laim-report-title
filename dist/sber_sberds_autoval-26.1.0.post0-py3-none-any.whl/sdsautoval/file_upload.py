import hashlib
import io
import json
import os
import pathlib
import threading
import urllib.parse
import uuid
from concurrent.futures import FIRST_EXCEPTION, ThreadPoolExecutor, wait
from datetime import timedelta, datetime
from math import ceil
from os.path import getsize, splitext

from sdsautoval.clui.widgets.progress import ProgressBarWidget, ProgressWidget
from .base_requester import BaseRequester
from .exceptions.base import SberDSError
from .exceptions.exceptions import IllegalStateException
from .exceptions.sds_exceptions import SdsFileUploadError, SdsFileUploadEventsError
from .rest_utils import DEFAULT_TIMEOUT_SECONDS, UserSession
from .utils.atomics import AtomicInteger
from .utils.average import Average
from .utils.retry import withretry, withwait


class HashCalculator:
    def __init__(self):
        self._calculated_hash = hashlib.sha512()

    def update(self, chunk):
        self._calculated_hash.update(chunk)

    def get(self):
        return self._calculated_hash.hexdigest()


def generate_file_hash(file_path, log_prefix='Хэширование файла',
                       chunk_size=1048576):
    file_hash = HashCalculator()
    with open(file_path, "rb") as f:
        try:
            file_size = getsize(file_path)
            chunks_total = ceil(file_size / chunk_size)
            chunks_completed = 0
            file_name = pathlib.Path(file_path).name
            with ProgressBarWidget(log_prefix + ' ' + file_name,
                                   show_percentage=True) as progress_logger:
                while True:
                    chunk = f.read(chunk_size)
                    if not chunk:
                        break
                    file_hash.update(chunk)
                    chunks_completed += 1
                    progress_logger.update(chunks_completed,
                                           chunks_total)
        except FileNotFoundError as _:
            raise SdsFileUploadError(
                message="Файл не найден: " + str(file_path),
                advise="Проверьте правильно ли указан путь к файлу и " +
                       "повторите снова")
    return file_hash.get()


class CsvUploaderClient:
    FILE_UPLOAD_TIMEOUT_SECONDS = 180
    _SERVICE_PATH = 'data-source'
    _END_POINT = '/api/'

    def __init__(self, host, session, token):
        self._requester = BaseRequester(host, session, service_name=self.__class__._SERVICE_PATH)
        self._token = token

    def create_folder(self, name, path='/'):
        return self._do_request(
            f'{self._base_path()}settings/folders/csv?path='
            f'{str(path)}&folderName={str(name)}',
            'post', None)

    def get_root(self):
        return self._do_request(f'{self._base_path()}settings/folders/csv',
                                'get')

    def test(self, file_path):
        return self._do_request(f'{self._base_path()}connections/test',
                                'post',
                                data=json.dumps({
                                    'filePath': str(file_path),
                                    'type': 'csv',
                                }),
                                wrapper=False)

    def get_folder_content(self, path='/'):
        params = {
            'path': str(path),
        }
        url_path = f'{self._base_path()}' + 'settings/folders/csv?' + \
                   urllib.parse.urlencode(
                       params)
        return self._do_request(
            url_path, 'get')

    def assembled_path(self, project_id, node_id, resumable_identifier):
        params = {
            'resumableIdentifier': str(resumable_identifier),
        }
        path = 'upload/csv/assembly/poll?' + urllib.parse.urlencode(params)
        return self._do_request_for_project_and_node(
            project_id=project_id,
            node_id=node_id,
            path=path,
            method='get',
            timeout_seconds=CsvUploaderClient.FILE_UPLOAD_TIMEOUT_SECONDS
        )

    def upload_chunk(self, resumable_identifier, project_id, node_id, file_path,
                     file_name,
                     chunk,
                     current_chunk_size, chunk_size, current_chunk_number,
                     total_chunks,
                     file_size,
                     file_type, instance):

        params = {
            'instance': str(instance),
            'resumableChunkNumber': str(current_chunk_number),
            'resumableChunkSize': str(chunk_size),
            'resumableCurrentChunkSize': str(current_chunk_size),
            'resumableTotalSize': str(file_size),
            'resumableType': str(file_type),
            'resumableIdentifier': str(resumable_identifier),
            'resumableFilename': str(file_name),
            'resumableRelativePath': str(file_path),
            'resumableTotalChunks': str(total_chunks),
            'async': str('true')
        }
        path = 'upload/csv?' + urllib.parse.urlencode(params)

        headers = self._headers(self._token, content_type='application/binary')
        return self._do_request_for_project_and_node(project_id=project_id,
                                                     node_id=node_id,
                                                     path=path,
                                                     data=chunk,
                                                     method='post',
                                                     headers=headers,
                                                     timeout_seconds=CsvUploaderClient.FILE_UPLOAD_TIMEOUT_SECONDS)

    @staticmethod
    def _headers(token, content_type='application/json'):
        return {
            'Accept': 'application/json',
            'Authorization': f'Bearer {token}',
            'Content-Type': content_type
        }

    def _do_request_for_project_and_node(self, project_id, node_id, path='',
                                         data=None, method=None, headers=None,
                                         timeout_seconds=DEFAULT_TIMEOUT_SECONDS,
                                         wrapper=True):
        end_point = f'{self._base_path()}{project_id}/node/{node_id}/{path}'
        return self._do_request(end_point,
                                method,
                                data=data,
                                headers=headers,
                                timeout_seconds=timeout_seconds,
                                wrapper=wrapper)

    def _do_request(self, end_point, method, data=None, headers=None,
                    timeout_seconds=DEFAULT_TIMEOUT_SECONDS,
                    wrapper=True):
        if method is None:
            real_method = 'get' if data is None else 'post'
        else:
            real_method = method
        if headers is None:
            headers = self._headers(self._token)
        if wrapper:
            return self._requester.request(
                method=real_method,
                endpoint=end_point,
                headers=headers,
                data=data,
                timeout_seconds=timeout_seconds
            )
        else:
            return self._requester.request_no_wrapper(
                method=real_method,
                endpoint=end_point,
                headers=headers,
                data=data,
                timeout_seconds=timeout_seconds
            )

    def _base_path(self):
        return self._SERVICE_PATH + self._END_POINT

    def chunk_exists(self, resumable_identifier, project_id, node_id,
                     chunk,
                     current_chunk_number,
                     total_chunks,
                     instance):
        params = {
            'instance': str(instance),
            'resumableChunkNumber': str(current_chunk_number),
            'resumableIdentifier': str(resumable_identifier),
            'resumableTotalChunks': str(total_chunks),
        }
        path = 'upload/csv?' + urllib.parse.urlencode(params)

        headers = self._headers(self._token, content_type='application/binary')
        return self._do_request_for_project_and_node(project_id=project_id,
                                                     node_id=node_id,
                                                     path=path,
                                                     data=chunk,
                                                     method='get',
                                                     headers=headers,
                                                     timeout_seconds=CsvUploaderClient.FILE_UPLOAD_TIMEOUT_SECONDS,
                                                     wrapper=False)


class CsvUpload:
    def __init__(self,
                 file,
                 file_name: str,
                 file_path: str,
                 chunk_size: int,
                 project_id, node_id,
                 instance: str,
                 client: CsvUploaderClient,
                 threads: int = 1,
                 calculate_hash: bool = False,
                 before_all=None,
                 before_part=None):
        self.file = file
        self.file_name = file_name
        self.chunk_size = chunk_size
        self._client = client
        self.file_path = file_path
        self.file_size = getsize(file)
        self.chunks_count = ceil(self.file_size / self.chunk_size)
        self.uploaded_file_path = None
        self.uploaded_chunks_count = 0
        self.resumable_identifier = uuid.uuid4()
        self.project_id = project_id
        self.node_id = node_id
        self.instance = instance
        self._threads = threads
        self.before_part = before_part
        self.before_all = before_all
        self.exception_raised = False
        self.chunks_in_memory = AtomicInteger()
        if calculate_hash:
            self._hash_calculator = HashCalculator()
        else:
            self._hash_calculator = None

    @withretry(retries=5, retry_delay=[0, 3, 5, 10])
    def do_upload_chunk(self, chunk, chunk_number: int):
        if not self.chunk_exists(chunk, chunk_number):
            try:
                return self._client.upload_chunk(self.resumable_identifier, self.project_id, self.node_id,
                                                 self.file_path, self.file_name, chunk, len(chunk), self.chunk_size,
                                                 chunk_number, self.chunks_count, self.file_size, 'text/csv',
                                                 self.instance)
            finally:
                self.chunks_in_memory.dec()
        else:
            return None

    def chunk_exists(self, chunk, chunk_number):
        try:
            self._client.chunk_exists(self.resumable_identifier, self.project_id, self.node_id, chunk,
                                      chunk_number, self.chunks_count, self.instance)
            return True
        except SberDSError as _:
            return False

    def run(self):
        with open(self.file, 'rb',
                  buffering=self.chunk_size * self._threads) as file_stream:
            with ProgressBarWidget(f'Загрузка файла {str(self.file_name)}',
                                   show_percentage=True,
                                   segments=10) as progress:
                self._do_run(file_stream, progress)
            with ProgressWidget(f'Cборка файла {str(self.file_name)} на сервере') as _:
                self.wait_for_assembly()
        return self.uploaded_file_path, self._get_hash()

    def _do_run(self, file_stream, progress_logger):
        chunk_number = 1
        executor = ThreadPoolExecutor(max_workers=self._threads,
                                      thread_name_prefix='upload_csv')
        if self.before_part:
            self.before_all(self.chunks_count)
        lock = threading.Lock()
        futures = []
        try:
            while True:
                chunk = None
                try:
                    self.chunks_in_memory.wait_until(lambda x: x < 256)
                    self.chunks_in_memory.inc()
                    chunk = file_stream.read(self.chunk_size)
                except Exception as e:
                    self.cancel_all_futures(futures, executor)
                    raise e
                if not chunk:
                    break
                self._update_hash(chunk)
                futures.append(
                    executor.submit(self.upload_chunk,
                                    chunk,
                                    chunk_number,
                                    progress_logger,
                                    lock))
                chunk_number += 1
            done, pending = wait(futures, return_when=FIRST_EXCEPTION)
            self.cancel_all_futures(pending, executor)
            try:
                for future in done:
                    self._handle_result(future.result())
            except Exception as e:
                self._handle_result(e)
        finally:
            executor.shutdown(wait=False)

    def _update_hash(self, chunk):
        if self._hash_calculator:
            self._hash_calculator.update(chunk)

    def _get_hash(self):
        if self._hash_calculator:
            return self._hash_calculator.get()
        return None

    @staticmethod
    def cancel_all_futures(futures: list, executor: ThreadPoolExecutor):
        for future in futures:
            future.cancel()
        executor.shutdown(wait=False)

    def _handle_result(self, result):
        if result:
            if isinstance(result, Exception):
                if not self.exception_raised:
                    raise result

    def upload_chunk(self, chunk, chunk_number, progress_logger, lock):
        start_time = datetime.now()
        if self.before_part:
            self.before_part(chunk, chunk_number, self.chunks_count)
        upload_result = self.do_upload_chunk(chunk, chunk_number)
        result = None
        if upload_result and upload_result.text:
            result = upload_result.text
        with lock:
            self.uploaded_chunks_count += 1
            progress_logger.update(
                completed=self.uploaded_chunks_count,
                total=self.chunks_count)
        delta = datetime.now() - start_time
        total_seconds = delta.total_seconds()
        if total_seconds <= 0:
            total_seconds = 1
        CsvUploader.CHUNK_UPLOAD_SECONDS.add(total_seconds)
        return result

    def wait_for_assembly(self):
        self.uploaded_file_path = self._wait_assembled_path()

    @withwait(wait_delay=[1, 2, 5, 10, 15])
    def _wait_assembled_path(self):
        path = self._get_assembled_path()
        if path is not None and isinstance(path, str):
            return path
        return None

    @withretry(retries=5, retry_delay=[0, 3, 5, 10])
    def _get_assembled_path(self):
        response = self._client.assembled_path(self.project_id, self.node_id, self.resumable_identifier)
        if (response is not None
                and response.text is not None
                and isinstance(response.text, str)):
            stripped_response_text = response.text.strip()
            if len(stripped_response_text) > 0:
                return stripped_response_text
        return None


class FileCache:
    def __init__(self):
        self.cache_map = dict()

    class Key:
        def __init__(self,
                     local_file_path,
                     remote_file_path,
                     remote_file_name,
                     hash_code=None,
                     file_modification_time=None):
            self.local_file_path = local_file_path
            self.remote_file_path = remote_file_path
            self.remote_file_name = remote_file_name
            if file_modification_time is None:
                file_modification_time = os.path.getmtime(local_file_path)
            self.file_modification_time = file_modification_time
            self._hash_code = None
            if hash_code:
                self._hash_code = str(hash_code)

        def get_hash_code(self):
            self.ensure_hash_code()
            return self._hash_code

        def copy_with_hash(self, hash_code):
            return FileCache.Key(self.local_file_path, self.remote_file_path,
                                 self.remote_file_name, hash_code=hash_code,
                                 file_modification_time=self.file_modification_time)

        def ensure_hash_code(self):
            if self.hash_needed():
                self._hash_code = str(
                    generate_file_hash(
                        self.local_file_path,
                        log_prefix='Проверка изменений в файле'))

        def hash_needed(self):
            return self._hash_code is None

        def __key(self):
            return (
                self.local_file_path, self.remote_file_path,
                self.remote_file_name,
                self.file_modification_time)

        def __str__(self):
            s = f'{self.local_file_path} {self.remote_file_path} ' + \
                f'{self.remote_file_name} {self.file_modification_time}'
            if self.hash_needed():
                return s
            return s + f' {self.get_hash_code()}'

        def __hash__(self):
            return hash(self.__key())

        def __eq__(self, other):
            if isinstance(other, FileCache.Key):
                if self.__key() == other.__key():
                    return self.get_hash_code() == other.get_hash_code()
            return False

    def clear(self):
        self.cache_map = dict()

    def keys(self):
        return self.cache_map.keys()

    def get(self, key: Key):
        if key in self.cache_map.keys():
            return self.cache_map.get(key)
        return None

    def put(self, key: Key, value):
        key.ensure_hash_code()
        self.cache_map.update({key: value})


FILE_CACHE = FileCache()


class CsvUploader:
    CHUNK_UPLOAD_SECONDS = Average(2)
    _CHUNK_SIZE = 524_288  # as on frontend
    _THREADS = 3  # as on frontend, but 7 works best

    def __init__(self,
                 user_session: UserSession,
                 project_id, node_id,
                 method=None,
                 event_service=None):
        self.check_events_delay = timedelta(minutes=3)
        self.supported_extensions = ['csv', '.csv', 'pkl', '.pkl', 'pickle', '.pickle', 'joblib', '.joblib', 'parquet', '.parquet', 'pqt', '.pqt']
        self.project_id = project_id
        self.node_id = node_id
        self._instance = user_session.instance
        self._client = CsvUploaderClient(host=user_session.host,
                                         session=user_session.session,
                                         token=user_session.token)
        self.file_cache = FILE_CACHE
        self.method = method
        self.event_service = event_service
        self.next_event_check = None

    def upload_file(self, file: str, file_folder: str, file_name: str = None,
                    chunk_size=_CHUNK_SIZE):
        file_cache = self.file_cache
        if file is None or not file.strip():
            raise SdsFileUploadError("Не указан файл",
                                     "Укажите файл и попробуйте снова")
        file = file.strip()
        self.check_file_extension(file)
        if not self.method:
            raise IllegalStateException("No method in CsvUploader")
        if not file_name:
            file_name = pathlib.Path(file).name
        if self.should_create_folder(file_folder):
            self._client.create_folder(name=file_folder)
        try:
            file_path = '/' + file_folder + '/'
            print('Проверка необходимости загрузки файла ' + file_name + ' ...')
            file_cache_key = FileCache.Key(file, file_path, file_name)
            uploaded_file_path = file_cache.get(file_cache_key)
            if uploaded_file_path is None or \
                    not self.check_file_exists_on_remote(uploaded_file_path):
                csv_upload = CsvUpload(file, file_name, file_path,
                                       chunk_size,
                                       self.project_id, self.node_id,
                                       self._instance,
                                       self._client,
                                       threads=self._THREADS,
                                       calculate_hash=file_cache_key.hash_needed(),
                                       before_all=lambda total_chunks: self.check_events(file, total_chunks),
                                       before_part=lambda chunk, chunk_number, total_chunks:
                                       self.check_events_at_percent(file,
                                                                    chunk_number,
                                                                    total_chunks))
                uploaded_file_path, calculated_hash = csv_upload.run()
                if uploaded_file_path is None or \
                        not self.check_file_exists_on_remote(uploaded_file_path):
                    raise SdsFileUploadError()
                if calculated_hash:
                    file_cache_key = file_cache_key.copy_with_hash(
                        calculated_hash)
                file_cache.put(file_cache_key, uploaded_file_path)
            else:
                print(
                    f'Файл {file_name} уже загружен, повторная загрузка не ' +
                    'требуется\n')
            return {
                'name': file_name,
                'fileName': file_name,
                'filePath': uploaded_file_path,
                'virtualPath': file_path
            }
        except FileNotFoundError as _:
            raise SdsFileUploadError(
                message="Файл не найден: " + str(file),
                advise="Проверьте правильно ли указан путь к файлу и " +
                       "повторите снова")

    def check_file_exists_on_remote(self, uploaded_file_path):
        try:
            test = self._client.test(uploaded_file_path)
            if test and 200 <= test.status_code < 300:
                return True
            else:
                return False
        except Exception as e:
            return False

    def should_create_folder(self, file_folder):
        root = self._client.get_root()
        root = root.json()
        names = [o['name'] for o in root]
        return file_folder not in names

    def check_file_extension(self, file):
        filename, file_extension = splitext(file)
        if not file_extension:
            raise SdsFileUploadError(
                message="Не удаётся определить тип файла для " + str(file),
                advise="Выберите файл поддерживаемого типа " +
                       self._get_supported_extensions_str())
        if file_extension.lower() not in self.supported_extensions:
            raise SdsFileUploadError(
                message="Неподдерживаемый тип файла: " + str(file_extension),
                advise="Выберите файл поддерживаемого типа " +
                       self._get_supported_extensions_str())

    def _get_supported_extensions_str(self):
        return ','.join(self.supported_extensions)

    def check_events(self, file, chunks_left=0):
        if self.event_service is None:
            return
        method_id = self.method.info.method_id
        seconds_per_chunk = CsvUploader.CHUNK_UPLOAD_SECONDS.get()
        if seconds_per_chunk <= 0:
            seconds_per_chunk = 1
        interval = self.check_events_delay + timedelta(seconds=chunks_left * seconds_per_chunk)
        should_abort, cause_events = self.event_service.should_abort_by_method(method_id,
                                                                               interval_before=self.check_events_delay,
                                                                               interval_after=interval)
        self.next_event_check = datetime.now() + self.check_events_delay
        if should_abort:
            cause_events_str = ''
            with io.StringIO() as string_io:
                self.event_service.print_events_list(cause_events, file=string_io)
                cause_events_str = string_io.getvalue()
            raise SdsFileUploadEventsError(
                message=f"Загрузка файла {file} была отменена из-за технических работ",
                advise="Повторите попытку после окончания технических работ",
                cause_events_str=cause_events_str
            )

    def check_events_at_percent(self, file, chunk_number, total_chunks):
        if self.next_event_check:
            if datetime.now() >= self.next_event_check:
                self.check_events(file, total_chunks - chunk_number)
        else:
            self.check_events(file, total_chunks - chunk_number)
