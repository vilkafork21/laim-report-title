from sdsautoval import SdsExceptionLogPrinter
from sdsautoval.context.user_context import UserContext
from sdsautoval.exceptions.exception_decorator import exception_logger, keyboard_interrupt_handler
from sdsautoval.session.session_interface import SessionInterface
from sdsautoval.util import SimpleTable
from sdsautoval.utils.args import is_dict_with_elements as is_dict_with_elements
from sdsautoval.utils.conjugating_word import ConjugatingWord, SimpleConjugatingWord

FINANCIAL_EFFECT_WORD = SimpleConjugatingWord({
    # именительный
    0: ['финансовая оценка', 'финансовые оценки'],
    # родительный
    1: ['финансовой оценки', 'финансовых оценок'],
    # дательный
    2: ['финансовой оценке', 'финансовым оценкам'],
    # винительный
    3: ['финансовую оценку', 'финансовые оценки'],
    # творительный
    4: ['финансовой оценкой', 'финансовыми оценками'],
    # предложный
    5: ['о финансовой оценке', 'о финансовых оценках'],
})


class FinancialEffectEstimator(SessionInterface):
    def __init__(self):
        super().__init__()
        self.project_area_type = 'ab_testing'
        UserContext.get().job_name = self.get_job_name()
        self.method_columns = None

    def get_job_name(self) -> ConjugatingWord:
        return FINANCIAL_EFFECT_WORD

    def default_object_name(self):
        return "financial_effect_estimator"

    def prevalidation_id_name(self):
        return 'fin_effect_id'

    def get_prevalidations_name(self):
        return 'get_estimations()'

    def get_estimations(self, pilot_version=None, status=None, date_to=None, date_from=None, limit=200) -> SimpleTable:
        """Показать основную информацию по финансовым оценкам, запущенным
        пользователем (проверка пользователя по login), сортировка по дате
        создания от последней созданной к более ранней


        Parameters
        ----------

        pilot_version : str, list, опциональный параметр
            идентификатор из БМ или список идентификаторов
        status : str, list, опциональный параметр
            статус процесса финансовой оценкаи
            доступные варианты: RUNNING, DONE, ERROR, PAUSED, TECHNICAL_PAUSED
        date_to : str, datetime-like, в формате "YYYY-MM-DD", опциональный параметр
            дата для фильтрации выборки, дата после которой финансовые оценки не попадут в выборку
        date_from : str, datetime-like, в формате "YYYY-MM-DD", опциональный параметр
            дата для фильтрации выборки, дата до которой финансовые оценки не попадут в выборку
        limit : int, опциональный параметр
            количество финансовых оценок в выборке, по умолчанию limit=200


        Returns
        -------

        функция возвращает информацию по финансовым оценкам:

        create_date : str, datetime-like
            дата время создания финансовой оценки
        update_date : str, datetime-like
            дата время последнего изменения статуса финансовой оценки (если
            финансовая оценка завершена, то дата завершения финансовой оценки)
        prevalidation_id : str
            идентификатор финансовой оценки (является параметром для функций
            get_status или stop)
        method_key : str
            идентификатор методики финансовой оценки
        pilot_version : str
            идентификатор из БМ
        project_url : str
            ссылка на проект SberDS
        report_url : str
            ссылка на отчет SberDS
        status : str
            пользовательский статус финансовой оценки (RUNNING - финансовая оценка в
            процессе исполнения,  PAUSED - пользователь остановил финансовую оценку,
            TECHNICAL_PAUSED - финансовая оценка преостановлена на время инцидента,
            DONE или ERROR - финальные статусы)
        main_traffic_light : str
            итоговый светофор
        error_message : str
            сообщение об ошибке (если финансовая оценка не завершилась успешно и не
            создан итоговый отчет)

        Examples
        --------

        financial_effect_estimator.get_estimations(pilot_version=['34','123']) - функция
            вернет общую информацию по 200 последним финансовым оценкам, запущенным
            пользователем, для которых pilot_version = '34' или  pilot_version = '123',
            сортировка по дате создания (сначала новые потом старые)
        """
        return super()._get_jobs(pilot_version, status, date_to, date_from, limit)

    def run(self, pilot_version, data, settings: dict,
            validate_settings=True,
            resources=None,
            cpu_only=False,
            **kwargs):
        """ Валидация параметров и запуск финансовой оценки

        Parameters
        ----------
        pilot_version : int
            Идентификатор версии

        data : list
            Источники данных и разметка колонок, определяются функцией DataSample
            Артефакты моделирования определяются функцией DataArtifact

        settings : dict [JSON settings of template SberDS]
            Настройки определенные в шаблоне финансовой оценки SberDS

        validate_settings : bool
            Проверять ли настройки, введенные пользователем (по умолчанию да)

        resources: str, default='7gb1cpu', если не заданы иные внутри методики
            Ресурсы для запуска узлов финансовой оценки.
            Допустимые значения: строки виде "{N}gb{M}cpu".format(N=N, M=M), где
                N - целое число от 1 до 512, M - целое число, от 1 до 16
            Пример: 32gb8cpu или 128gb2cpu

            Если нужно указать требования только к одному из параметров ресурсов (RAM или CPU), то можно задавать
                каждый из них по отдельности
            Пример: 32gb для RAM или 2cpu для CPU

            При выборе ресурсов, где число CPU > 3 или объем RAM > 7GB, запуск вычислений будет производиться
                в экспериментальном режиме на отдельном кластере, например, могут не показываться логи в realtime
            В случае проблем и непонятных ошибок напишите, пожалуйста, нам через метод financial_effect_estimator.create_issue
                или на почту mailto:AutoValidation@sberbank.ru, mailto:sberds@omega.sbrf.ru
        cpu_only: bool
            Запустить только на CPU

        Returns
        -------
        функция сохраняет параметры в объекте FinancialEffectEstimator и создает запрос на проведение финансовой оценки
        в случае, если все проверки прошли успешно, то создается проект финансовой оценки и
        возвращается объект FinancialEffectEstimator

        Examples
        --------
        # Валидация параметров и запуск финансовой оценки
        financial_effect_estimator.run(
            pilot_version=34,
            data=data,
            settings=settings
        )
        """
        disable_pv = False
        if is_dict_with_elements(kwargs):
            disable_pv = kwargs.get('disable_pv', False)
        return self._run_job(pilot_version, data, settings, validate_settings, resources, finance=True,
                             disable_pv=disable_pv, cpu_only=cpu_only)

    @exception_logger(logger=SdsExceptionLogPrinter())
    def resume(self, fin_effect_id, resources=None, cpu_only=False, only_current=False):
        """
        Дозапустить процесс финансовой оценки.
        Актуально, если финансовая оценка завершилась с ошибкой или стоит на паузе.


        Parameters
        ----------
        fin_effect_id : str
            Идентификатор финансовой оценки
        resources: str
            Ресурсы для дозапуска узлов.
            Допустимые значения: строки виде "{N}gb{M}cpu".format(N=N, M=M), где
                N - целое число от 1 до 512, M - целое число, от 1 до 16
            Пример: 32gb8cpu или 128gb2cpu

            Если нужно указать требования только к одному из параметров ресурсов (RAM или CPU), то можно задавать
                каждый из них по отдельности
            Пример: 32gb для RAM или 2cpu для CPU

            При выборе ресурсов, где число CPU > 3 или объем RAM > 7GB, запуск вычислений будет производиться
                в экспериментальном режиме на отдельном кластере, например, могут не показываться логи в realtime
            В случае проблем и непонятных ошибок напишите, пожалуйста, нам через метод financial_effect_estimator.create_issue
                или на почту mailto:AutoValidation@sberbank.ru, mailto:sberds@omega.sbrf.ru
        cpu_only: bool
            Дозапустить только на CPU
        only_current: bool
            Дозапустить только текущую финоценку, не запуская дочерние.

        Returns
        -------
            функция возвращает результат дозапуска финансовой оценки

        Examples
        --------
        financial_effect_estimator.resume(fin_effect_id='65e92db8-7cd4-4cf4-95fa-adc00e61d6b1', resources='16gb2cpu')

        финансовая оценка '65e92db8-7cd4-4cf4-95fa-adc00e61d6be' успешно дозапущена
        """
        super()._resume_job(fin_effect_id, resources, cpu_only=cpu_only, only_current=only_current)

    @exception_logger(logger=SdsExceptionLogPrinter())
    def get_status(self, estimation_id):
        """Показать всю информацию по одной финансовой оценке запущенной пользователем,

        Если финансовая оценка не исполнена, то функция будет запрашивать статус до
        тех пор пока процесс финансовой оценки остается в статусе RUNNING


        Parameters
        ----------

        estimation_id : str
        идентификатор финансовой оценки


        Returns
        -------

        функция возвращает информацию по финансовой оценке

        create_date : str
            дата время создания финансовой оценки
        update_date : str
            дата время последнего изменения статуса финансовой оценки (если
            автовалидация завершена, то дата завершения финансовой оценки)
        prevalidation_id : str
            идентификатор финансовой оценки (является параметром для функций
             get_status или stop)
        method_key : str
            идентификатор методики финансовой оценки
        model_version_id : str
            идентификатор из БМ
        project_url : str
            ссылка на проект SberDS
        report_url : str
            ссылка на отчет SberDS
        status : str
            пользовательский статус финансовой оценки (RUNNING - финансовая оценка в
            процессе исполнения,  PAUSED - пользователь остановил процесс финансовой оценки,
            TECHNICAL_PAUSED - финансовая оценка преостановлена на время инцидента,
            DONE или ERROR - финальные статусы)
        main_traffic_light : str
            итоговый светофор
        error : json
            сообщение об ошибке (если финансовая оценка не завершилась успешно и не
            создан итоговый отчет)
        project_node_errors: list
            список ошибок исполнения нод проекта
        samples : list
            путь к источнику данных, типы выборок, разметка колонок, указанные
            при запуске финансовой оценки
        settings : list
            дополнительные настройки шаблона, указанные при
            запуске финансовой оценки

        Examples
        --------

        financial_effect_estimator.get_status(estimation_id='65e92db8-7cd4-4cf4-95fa-adc00e61d6b1')
        """
        self._do_get_status(estimation_id)

    @exception_logger(logger=SdsExceptionLogPrinter())
    def get_release_notes(self, limit=5):
        """ Получить Release notes сервиса финансовой оценки.

        Parameters
        ----------
        limit: int
            сколько последних Release notes напечатать (по блоку / общие)

        Returns
        -------
        Возвращает Release notes сервиса финансовой оценки

        Examples
        --------
        auto_validator.get_release_notes(limit=5)
            если созданы Release notes для определенных проектных областей,
            то будут напечатаны 5 последних Release Notes для каждой проектной области
        """
        self._do_get_release_notes(limit)

    @exception_logger(logger=SdsExceptionLogPrinter())
    def create_issue(self, description: str, subject: str = 'AB_Testing'):
        """ Отправить отчет об ошибке.

        Загрузка данных K1 и K2 запрещена.


        Parameters
        ----------
        description : str
            Описание ошибки в свободной форме.

        subject : str
            Классификатор ошибок, указать: AB_Testing


        Returns
        -------
        issueId идентификатор обращения


        Examples
        --------
        financial_effect_estimator.create_issue('Описание ошибки', 'AB_Testing')

        """
        super().create_issue(description, subject)

    @keyboard_interrupt_handler()
    def send_feedback(self, usability: int, valuability: int, fin_effect_id=None):
        """
        Оценить полезность сервиса финоценки

        Parameters
        ----------

        usability: int
            Для оценки удобства работы с сервисом, принимаются целые значения от 1 до 5, где 1 - совсем не удобно, а 5 - очень удобно

        valuability: int
            Для оценки полезности сервиса, принимаются целые значения от 1 до 5, где 1 - совсем не полезно, а 5 - очень полезно

        fin_effect_id: bool
            ID превалидации, если опустить, используется последняя проведенная финоценка

        Examples
        --------
        financial_effect_estimator.send_feedback(usability=5, valuability=5)
        financial_effect_estimator.send_feedback(usability=5, valuability=5, fin_effect_id='2c3a06a2-3c70-496f-8626-21c304f285b5')
        """
        self._send_feedback(usability, valuability, fin_effect_id)
