from .job_management import JobManagementSession
# noinspection PyProtectedMember
# noinspection PyProtectedMember
# noinspection PyProtectedMember
from ..context.user_context import UserContext
from ..exceptions.exception_decorator import exception_logger, keyboard_interrupt_handler
from ..exceptions.sds_exceptions import *
from ..method.method_models import MethodExtendedModel
from ..utils import keyboard_interrupt_handlers as ki_handlers


class SelectMethodSession(JobManagementSession):
    """Основной объект - сессия работы


    Examples
    --------
    session = SessionInterface()


    See Also
    --------
    Общая последовательность использования функций SDK
    0. создать обьект "сессия"
    1. authorize: авторизация пользователя
    2.1 ModelProperties: ввод параметров для определения методики
    2.2 ColumnsSelector, add: разметка колонок источников данных
    2.3 DataConnection, DataSample: определение источников данных
    3. run_job: запуск проекта
    """

    @exception_logger(logger=SdsExceptionLogPrinter())
    @keyboard_interrupt_handler(ki_handler=ki_handlers.session_interface_select_methods)
    def select_method(self, method_id: str) -> MethodExtendedModel:
        """ Выбрать методику.

        Parameters
        ----------
        method_id : str
            Уникальный идентификатор методики.

        Returns
        -------
        Функция сохраняет выбор методики в объекте сессии,
        возвращает общую информацию о методике, требования к источникам данных и разметке, в том числе settings из шаблона SberDS

        Examples
        --------
        auto_validator.select_method()

        :return:
        """
        self._ensure_authorized()
        self._selected_method = self._method_service.get_method_info(method_id)
        method_key = self._selected_method.info.method_key
        self._selected_method_id = method_id
        UserContext.get().current_method = method_key
        self._content_keeper.update(method_key=method_key, keep_prevalidation=False)
        self._event_service.print_by_method(self._selected_method.info.method_id)
        return self._selected_method


class SessionInterface(SelectMethodSession):
    """Основной объект - сессия работы


    Examples
    --------
    session = SessionInterface()


    See Also
    --------
    Общая последовательность использования функций SDK
    0. создать обьект "сессия"
    1. authorize: авторизация пользователя
    2.1 ModelProperties: ввод параметров для определения методики
    2.2 ColumnsSelector, add: разметка колонок источников данных
    2.3 DataConnection, DataSample: определение источников данных
    3. run_job: запуск проекта
    """

    @exception_logger(logger=SdsExceptionLogPrinter())
    @keyboard_interrupt_handler(ki_handler=ki_handlers.session_interface_select_methods)
    def select_draft_method(self, method_id: str) -> MethodExtendedModel:
        """ Выбрать драфт методики.

        Parameters
        ----------
        method_id : str
            Уникальный идентификатор методики.

        Returns
        -------
        Функция сохраняет выбор методики в объекте сессии,
        возвращает общую информацию о методике, требования к источникам данных и разметке, в том числе settings из шаблона SberDS

        Examples
        --------
        auto_validator.select_draft_method()

        :return:
        """
        self._ensure_authorized()
        self._selected_method = self._method_service.get_draft_method_info(method_id)
        method_key = self._selected_method.info.method_key
        UserContext.get().current_method = method_key
        self._content_keeper.update(method_key=method_key, keep_prevalidation=False)
        self._event_service.print_by_method(self._selected_method.info.method_id)
        return self._selected_method
