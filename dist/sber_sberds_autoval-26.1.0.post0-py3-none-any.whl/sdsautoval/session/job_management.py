import datetime
import html
import os
from urllib.parse import urlparse

from .feature_store import FeatureStoreSession
from ..clui.utils import is_in_jupyter
# noinspection PyProtectedMember
from ..context.constants import _HOSTS
# noinspection PyProtectedMember
from ..context.constants import _HOST_MAPPING
# noinspection PyProtectedMember
from ..context.constants import _PROM_HOSTS
from ..context.user_context import LastRun, UserContext
from ..dto.capabilities import CapabilitiesList
from ..exceptions.exception_decorator import exception_logger, keyboard_interrupt_handler, return_self
from ..exceptions.sds_exceptions import *
from ..modprop import DataSample, correct_role
from ..prevalidation.log_progress import LogProgressInterfaceSimple
from ..prevalidation.prevalidation import Prevalidation
from ..prevalidation.prevalidation_converter import PreValidationConverter
from ..prevalidation.prevalidation_run import PreValidationRun
from ..prevalidation.prevalidation_runner import PrevalidationRunner
from ..prevalidation.prevalidation_settings import PreValidationSettings
from ..prevalidation.prevalidation_utils import *
from ..prevalidation.prevalidation_web_client import PrevalidationWebClient
from ..prevalidation.print_log_progress import PrintLogProgress, PrintBarProgress
from ..rest_utils import UserSession
from ..util import json_to_datasamples, make_list, SimpleTable, is_valid_uuid
from ..utils import keyboard_interrupt_handlers as ki_handlers
from ..utils.addict import addict
from ..utils.args import is_dict_with_elements
from ..utils.conjugating_word import ConjugatingWord, DummyConjugatingWord


class JobManagementSession(FeatureStoreSession):
    """Основной объект - сессия работы


    Examples
    --------
    session = SessionInterface()


    See Also
    --------
    Общая последовательность использования функций SDK
    0. создать обьект "сессия"
    1. authorize: авторизация пользователя
    2.1 ModelProperties: ввод параметров для определения методики
    2.2 ColumnsSelector, add: разметка колонок источников данных
    2.3 DataConnection, DataSample: определение источников данных
    3. run_job: запуск проекта
    """

    def __init__(self):
        super().__init__()
        self.split_settings = None
        self.task = None

    def default_object_name(self):
        return 'session_interface'

    def prevalidation_id_name(self):
        return 'prevalidation_id'

    def get_prevalidations_name(self):
        return 'get_prevalidations()'

    @return_self()
    @exception_logger(logger=SdsExceptionLogPrinter())
    @keyboard_interrupt_handler(ki_handler=ki_handlers.session_interface_run_job)
    def _run_job(self, model_version_id, data, settings: dict,
                 validate_settings=True,
                 resources=None,
                 finance=False,
                 trigger_node_id=None,
                 project_id=None, disable_pv=False,
                 cpu_only=False):
        """ Валидация параметров и запуск проекта

        Parameters
        ----------
        model_version_id : int
            Идентификатор версии модели в библиотеки моделей

        data : list
            Источники данных и разметка колонок, определяются функцией DataSample
            Артефакты моделирования определяются функцией DataArtifact

        settings : dict [JSON settings of template SberDS]
            Настройки определенные в шаблоне проекта SberDS

        validate_settings : bool
            Проверять ли настройки, введенные пользователем (по умолчанию да)

        resources: str, default='7gb1cpu', если валидатор не задал иных внутри методики
            Ресурсы для запуска узлов превалидации.
            Допустимые значения: строки виде "{N}gb{M}cpu".format(N=N, M=M), где
                N - целое число от 1 до 512, M - целое число, от 1 до 16
            Пример: 32gb8cpu или 128gb2cpu

            Если нужно указать требования только к одному из параметров ресурсов (RAM или CPU), то можно задавать
                каждый из них по отдельности
            Пример: 32gb для RAM или 2cpu для CPU

            При выборе ресурсов, где число CPU > 3 или объем RAM > 7GB, запуск вычислений будет производиться
                в экспериментальном режиме на отдельном кластере, например, могут не показываться логи в realtime
            В случае проблем и непонятных ошибок напишите, пожалуйста, нам через метод auto_validator.create_issue
                или на почту mailto:AutoValidation@sberbank.ru, mailto:sberds@omega.sbrf.ru

        Returns
        -------
        функция сохраняет параметры в объекте AutoValidator и создает запрос на запуск проекта
        в случае, если все проверки прошли успешно, то создается проект превалидации и
        возвращается объект SessionInterface

        Examples
        --------
        # Валидация параметров и запуск проекта
        auto_validator.run(
            model_version_id=34,
            data=data,
            settings=settings
        )
        """
        self._ensure_can_validate()
        PreValidationSettings.validate_params(model_version_id, self._selected_method, data, settings, finance=finance,
                                              validate_settings=validate_settings)

        user_session = UserSession(self._host, self._session, self._token)

        for data_sample in data:
            data_sample.prepare(user_session, method=self._selected_method, event_service=self._event_service)

        self._event_service.print_by_method(self._selected_method.info.method_id)

        logger = PrintLogProgress(self.get_job_name())
        self._create_prevalidation(model_version_id, data, settings, validate_settings, resources, logger,
                                   disable_pv=disable_pv,
                                   cpu_only=cpu_only,
                                   trigger_node_id=trigger_node_id,
                                   project_id=project_id)
        self._prevalidation.start(widget=logger,
                                  job_name=self.get_job_name(),
                                  content_keeper=self._content_keeper,
                                  question_service=self._question_service)
        return self

    @return_self()
    @exception_logger(logger=SdsExceptionLogPrinter())
    @keyboard_interrupt_handler(ki_handler=ki_handlers.session_interface_run_job)
    def _run_job_all(self, params: list, validate_settings=True, permission_data=False):
        self._ensure_can_validate()
        user_session = UserSession(self._host, self._session, self._token)

        request = []
        for param in params:
            model_version_id = param.get('model_version_id', 0)
            data = param.get('data', [])
            settings = param.get('settings', {})
            resources = param.get('resources', None)
            trigger_node_id = param.get('trigger_node_id', None)
            project_id = param.get('project_id', None)
            if project_id is None:
                project_id = os.getenv("PROJECT_ID", None)
            disable_pv = param.get('disable_pv', False)
            method_id = param.get('method_id', None)
            cpu_only = param.get('cpu_only', False)
            PreValidationSettings.validate_params(model_version_id, self._selected_method, data, settings, False,
                                                  validate_settings)
            for data_sample in data:
                data_sample.prepare(user_session,
                                    method=self._selected_method,  # todo: fix in automodeling
                                    event_service=self._event_service)
            request.append(PreValidationConverter.convert_to_transport(model_version_id,
                                                                       self._selected_method.info.method_id if method_id is None else method_id,
                                                                       data, settings, validate_settings,
                                                                       resources, permission_data,
                                                                       trigger_node_id, project_id, cpu_only,
                                                                       disable_pv))

        self._prevalidation_run = PreValidationRun(self._get_client(), self._host, request, self._zone)
        self._prevalidation_run.create()

        self._content_keeper.update(run=self._prevalidation_run)

    def _do_get_release_notes(self, limit=5):
        self._ensure_authorized()
        self._notification_service.print_release_notes(self.project_area_type, limit)

    def get_capabilities(self, method_id=None, project_area_id=None, all_project_areas=False):
        if self._selected_method is None or all_project_areas:
            real_method_id = method_id
            real_project_area_id = project_area_id
        else:
            real_method_id = self._selected_method.info.method_id
            real_project_area_id = None
        if project_area_id is not None and not all_project_areas:
            real_project_area_id = project_area_id
            real_method_id = None
        return CapabilitiesList(
            json=self._get_client().get_capabilities(method_id=real_method_id, project_area_id=real_project_area_id))

    @exception_logger(logger=SdsExceptionLogPrinter())
    @keyboard_interrupt_handler(ki_handler=ki_handlers.session_interface_get_methods)
    def get_methods(self):
        """ Получить доступные для пользователя методики.

        Returns
        -------
        функция возвращает информацию о доступных методиках

        Examples
        --------
        auto_validator.get_methods()

        """
        self._ensure_authorized()
        self._print_all_events()
        return self._method_service.get_methods(project_area_type=self.project_area_type) \
            .filter(keep_columns=self.method_columns)

    @exception_logger(logger=SdsExceptionLogPrinter())
    @keyboard_interrupt_handler(ki_handler=ki_handlers.session_interface_get_methods)
    def get_draft_methods(self):
        """ Получить доступные для валидатора черновики методик.

        Returns
        -------
        функция возвращает информацию о доступных валидатору черновиках методика

        Examples
        --------
        auto_validator.get_draft_methods()

        """
        self._ensure_authorized()
        self._print_all_events()
        return self._method_service.get_draft_methods(project_area_type=self.project_area_type) \
            .filter(keep_columns=self.method_columns)

    @exception_logger(logger=SdsExceptionLogPrinter())
    @keyboard_interrupt_handler(ki_handler=ki_handlers.session_interface_get_methods)
    def print_methods(self):
        """ Показать доступные для пользователя методики.

        Parameters
        ----------
        project_area_type - тип проектной области

        Returns
        -------
        функция печатает возвращает информацию о доступных методиках

        Examples
        --------
        auto_validator.print_methods()

        """
        self._ensure_authorized()
        self._print_all_events()
        self._method_service.print_methods_response(
            self._method_service.get_methods(project_area_type=self.project_area_type))

    @exception_logger(logger=SdsExceptionLogPrinter())
    @keyboard_interrupt_handler(ki_handler=ki_handlers.session_interface_stop)
    def stop(self, prevalidation_id=None, run_id=None, trigger_node_id=None, only_current=False):
        """Остановить процесс выполнения проекта или группы проектов

        Parameters
        ----------
        prevalidation_id : str
            идентификатор запущенной превалидации
        run_id : str
            идентификатор группы запуска
        trigger_node_id : str
            идентификатор триггерной ноды запуска
        only_current : bool
            остановить только запущенный проект

        Returns
        -------
            функция возвращает результат остановки

        Examples
        --------
        auto_validator.stop(prevalidation_id='65e92db8-7cd4-4cf4-95fa-adc00e61d6b1')

        автовалидация/фин.оценка '65e92db8-7cd4-4cf4-95fa-adc00e61d6be' успешно остановлена
        """
        if prevalidation_id is not None:
            self._stop(prevalidation_id, only_current=only_current)
        else:
            self._stop_all(run_id, trigger_node_id)

    def _stop(self, prevalidation_id=None, only_current=False):
        if not is_valid_uuid(prevalidation_id):
            print(
                f'Похоже, вы указали неверный {self.prevalidation_id_name()}, подставьте {self.prevalidation_id_name()} из вашей {self.get_job_name().get(1)}.')
            return
        self._ensure_authorized()
        self._event_service.print_by_prevalidation(prevalidation_id)
        self._get_client().stop(prevalidation_id, only_current=only_current)
        print(f'{self.get_job_name()} \'{str(prevalidation_id)}\' успешно остановлена')

    def _stop_all(self, run_id, trigger_node_id=None):
        if not is_valid_uuid(run_id):
            print(f'Похоже, вы указали неверный run_id, подставьте run_id из вашего запуска.')
            return
        self._ensure_authorized()
        self._get_client().stop_all(run_id, trigger_node_id)
        print(f'Запуск \'{str(run_id)}\' успешно остановлен')

    def _add_common_val_method(self, settings: dict, method_name: str):
        if not settings.get('Validation Method Name'):
            self._ensure_authorized()
            validation_methods_info = self.get_avm_links(
                avm_user_method_ids=[method_name],
                status='ACTIVE',
                team=self._team
            )

            validation_name = validation_methods_info[0].get('userMethodId') if validation_methods_info else None
            print('Validation Method: "{}"'.format(validation_name))

            if validation_name:
                all_val_settings = self._method_service.get_method_info(validation_name).settings
                validation_settings = {name: setting['value'] for name, setting in all_val_settings['groups'].items()} \
                    if all_val_settings.get('groups') else ''
            else:
                validation_settings = None

            settings['Validation Method Name'] = validation_name
            settings['Validation Settings'] = validation_settings

        return settings

    @exception_logger(logger=SdsExceptionLogPrinter())
    @keyboard_interrupt_handler(ki_handler=ki_handlers.session_interface_get_jobs)
    def _get_jobs(self, model_version_id=None, status=None, date_to=None, date_from=None, limit=200) -> SimpleTable:
        """Показать основную информацию по проектам, запущенным
        пользователем (проверка пользователя по login), сортировка по дате
        создания от последней созданной к более ранней


        Parameters
        ----------

        model_version_id : str, list, опциональный параметр
            идентификатор из БМ или список идентификаторов
        status : str, list, опциональный параметр
            статус процесса автовалидации
            доступные варианты: RUNNING, DONE, ERROR, PAUSED, TECHNICAL_PAUSED
        date_to : str, datetime-like, в формате "YYYY-MM-DD", опциональный параметр
            дата для фильтрации выборки, дата после которой автовалидации не попадут в выборку
        date_from : str, datetime-like, в формате "YYYY-MM-DD", опциональный параметр
            дата для фильтрации выборки, дата до которой автовалидации не попадут в выборку
        limit : int, опциональный параметр
            количество автовалидации в выборке, по умолчанию limit=200


        Returns
        -------

        функция возвращает информацию по автовалидациям:

        create_date : str, datetime-like
            дата время создания автовалидации
        update_date : str, datetime-like
            дата время последнего изменения статуса автовалидации (если
            автовалидация завершена, то дата завершения автовалидации)
        prevalidation_id : str
            идентификатор автовалидации (является параметром для функций
            get_status или stop)
        method_key : str
            идентификатор методики автовалидации
        model_version_id : str
            идентификатор из БМ
        project_url : str
            ссылка на проект SberDS
        report_url : str
            ссылка на отчет SberDS
        status : str
            пользовательский статус автовалидации (RUNNING - автовалидация в
            процессе исполнения,  PAUSED - пользователь остановил автовалидацию,
            TECHNICAL_PAUSED - автовалидация преостановлена на время инцидента,
            DONE или ERROR - финальные статусы)
        main_traffic_light : str
            итоговый светофор
        error_message : str
            сообщение об ошибке (если автовалидация не завершилась успешно и не
            создан итоговый отчет)

        Examples
        --------

        auto_validator.get_jobs(model_version_id=['34','123']) - функция
            вернет общую информацию по 200 последним автовалидациям, запущенным
            пользователем, для которых model_version_id = '34' или  model_version_id = '123',
            сортировка по дате создания (сначала новые потом старые)
        """

        self._ensure_authorized()
        self._print_all_events()

        client = self._get_client()

        params = self._get_jobs_params(date_from, date_to, limit, make_list(model_version_id), make_list(status))

        prevalidations = client.get_prevalidations(params)
        for prevalidation in prevalidations:
            self._zone.update_prevalidation_info(prevalidation, self._host)

        columns = [
            'create_date',
            'model_version_id',
            'prevalidation_id',
            'method_key',
            'sberds_zone',
            'status',
            'main_traffic_light',
            'publish_status',
            'method_id',
            'project_url',
            'report_url',
            'update_date',
            'continue_numbers'
        ]

        return SimpleTable.from_records(prevalidations, columns)

    @exception_logger(logger=SdsExceptionLogPrinter())
    @keyboard_interrupt_handler(ki_handler=ki_handlers.session_interface_get_status)
    def _do_get_status(self, prevalidation_id=None, run_id=None, trigger_node_id=None, auto_model=False):
        if prevalidation_id is None:
            return self._do_get_status_all(run_id, trigger_node_id)
        else:
            if not is_valid_uuid(prevalidation_id):
                print(
                    f'Похоже, вы указали неверный {self.prevalidation_id_name()}, подставьте {self.prevalidation_id_name()} из вашей {self.get_job_name().get(1)}.')
                return
            self._ensure_can_validate()
            self._event_service.print_by_prevalidation(prevalidation_id)

            prevalidation_all_info = self._get_status_request(prevalidation_id)
            self._prevalidation = self._prevalidation_all_info_to_prevalidation(prevalidation_all_info)
            self._content_keeper.update(prevalidation=self._prevalidation, keep_method_key=False)

            s_text = f"Отслеживаем статус {self.get_job_name().get(1)}"
            i_text = f"Информация {self.get_job_name().get(5)}:"
            if is_in_jupyter():
                h3_open = "<h3>"
                h3_close = "</h3>"
                from IPython.core.display import HTML
                from IPython.display import display
                display(HTML(
                    f"{h3_open}{s_text} <span style='color:blue'>\
                    {html.escape(str(self._prevalidation.prevalidation_id))}</span>{h3_close}\n\
                    {h3_open}{i_text}{h3_close}\n"
                ))
            else:
                print(f"{s_text} {self._prevalidation.prevalidation_id}\n{i_text}\n")

            t = [[k, v] for k, v in prevalidation_all_info.items()]
            for i in t:
                if i[0] == "prevalidation_id":
                    i[0] = self.prevalidation_id_name()
            c = ["name", "value"]
            st = SimpleTable(t, c, max_width=80)
            if is_in_jupyter():
                st._ipython_display_()
            else:
                print(st)

            status = prevalidation_all_info.get("status")

            if not PrevalidationRunner.is_status_finished(status):
                logger = PrintBarProgress(self.get_job_name()) if auto_model else PrintLogProgress(self.get_job_name())
                self._prevalidation.start(widget=logger, job_name=self.get_job_name(),
                                          content_keeper=self._content_keeper,
                                          question_service=self._question_service)

            return None

    def _do_get_status_all(self, run_id, trigger_node_id=None):
        if not is_valid_uuid(run_id):
            print(f'Похоже, вы указали неверный run_id, подставьте run_id из вашего запуска.')
            return
        self._ensure_authorized()
        return self._get_client().get_status_all(run_id, trigger_node_id)

    def _prevalidation_all_info_to_prevalidation(self, prevalidation_all_info):
        prevalidation_all_info = self._substitute_url(prevalidation_all_info, 'project_url')
        prevalidation_all_info = self._substitute_url(prevalidation_all_info, 'report_url')
        prevalidation = self._load_prevalidation(client=self._get_client(),
                                                 model_version_id=prevalidation_all_info['model_version_id'],
                                                 samples=json_to_datasamples(
                                                     prevalidation_all_info.get('data_source', None)),
                                                 settings=prevalidation_all_info.get('settings', None),
                                                 resources=prevalidation_all_info.get('docker_resource', None))

        prevalidation.prevalidation_id = prevalidation_all_info['prevalidation_id']
        prevalidation._current_status = {
            'status': prevalidation_all_info['status'],
            'project_url': prevalidation_all_info['project_url'],
            'warnings': prevalidation_all_info.get('warnings', [])
        }
        persistent_volume = prevalidation_all_info.get('persistent_volume', None)
        if is_dict_with_elements(persistent_volume):
            if persistent_volume.get('usePV', False):
                prevalidation.persistent_volume = persistent_volume
        else:
            prevalidation.persistent_volume = None
        return prevalidation

    def _substitute_url(self, prevalidation_all_info, url_key: str):
        _url = prevalidation_all_info[url_key]
        _url = self._zone.substitute_host(_url)
        prevalidation_all_info[url_key] = _url
        return prevalidation_all_info

    def _reset_prevalidation(self, settings: dict, params: dict, logger: LogProgressInterfaceSimple,
                             validate_settings: bool, prevalidation_id: str):
        client = self._get_client()
        self._prevalidation = Prevalidation(
            client,
            self._host,
            settings,
            self._zone,
            self._internal_mode
        )

        self._content_keeper.update(prevalidation=self._prevalidation, keep_method_key=True)

        if not validate_settings:
            logger.log_no_validate_settings()

        self._prevalidation.set_existed_prevalidation(prevalidation_id)

        UserContext.get().last_run = LastRun(datetime.datetime.now(),
                                             self._prevalidation.prevalidation_id,
                                             model_version_id=params.get('model_version_id', None),
                                             samples=params.get('samples', None),
                                             settings=params.get('settings', None),
                                             resources=params.get('resources', None))

    def _create_prevalidation(self, model_version_id: int, samples: [DataSample], settings: dict,
                              validate_settings: bool, resources: str, logger: LogProgressInterfaceSimple,
                              permission_data: bool = False, disable_pv=False, trigger_node_id=None, project_id=None,
                              cpu_only=False):
        self._ensure_authorized()

        client = self._get_client()

        self._prevalidation = self._make_prevalidation(client, model_version_id, samples,
                                                       settings, validate_settings, resources,
                                                       trigger_node_id=trigger_node_id,
                                                       project_id=project_id,
                                                       permission_data=permission_data,
                                                       disable_pv=disable_pv,
                                                       cpu_only=cpu_only)

        self._content_keeper.update(prevalidation=self._prevalidation, keep_method_key=True)

        if not validate_settings:
            logger.log_no_validate_settings()

        self._prevalidation.create()

        UserContext.get().last_run = LastRun(datetime.datetime.now(),
                                             self._prevalidation.prevalidation_id,
                                             model_version_id,
                                             samples,
                                             settings,
                                             resources)

    def _make_prevalidation(self, client, model_version_id, samples,
                            settings: dict, validate_settings: bool, resources=None, method_id=None,
                            trigger_node_id=None, project_id=None, permission_data=False,
                            disable_pv=False, cpu_only=False):

        if method_id is None:
            method_id = self._selected_method.info.method_id

        return Prevalidation(client, self._host,
                             PreValidationConverter.convert_to_transport(
                                 model_version_id,
                                 method_id,
                                 samples,
                                 settings,
                                 validate_settings,
                                 resources,
                                 trigger_node_id=trigger_node_id,
                                 permission_data=permission_data,
                                 project_id=project_id,
                                 cpu_only=cpu_only,
                                 disable_pv=disable_pv),
                             self._zone,
                             self._internal_mode)

    def _load_prevalidation(self, client, model_version_id, samples, settings, resources=None,
                            trigger_node_id=None, project_id=None, permission_data=False):
        return Prevalidation(client, self._host,
                             PreValidationConverter.convert_to_transport(
                                 model_version_id,
                                 '',
                                 samples,
                                 settings,
                                 True,
                                 resources,
                                 trigger_node_id=trigger_node_id,
                                 permission_data=permission_data,
                                 project_id=project_id),
                             self._zone,
                             self._internal_mode)

    def _get_client(self):
        if self._client is None:
            self._client = PrevalidationWebClient(self._host, self._session, self._token, self._internal_mode)
        return self._client

    def _ensure_can_validate(self):
        self._ensure_authorized()
        if not self._can_validate:
            raise SdsNonCompatibleVersionError(self._version, self._get_update_info())

    def _ensure_authorized(self):
        if self._token is None:
            raise SdsNotAuthorizedError()

    @staticmethod
    def _resolve_host(host_name: str):
        if not host_name or len(host_name) == 0:
            raise SdsUrlParseError(f"Метод auto_validator('host') требует заполнить параметр 'host'")

        profile = _HOSTS.get(host_name)
        if profile:
            additionals = profile.get('additional', [])
            alt_hosts = []
            for additional in additionals:
                alt_host = _HOST_MAPPING.get(additional)
                if alt_host:
                    alt_hosts.append({'key': additional, 'name': alt_host['name']})
            UserContext.get().short_host = True
            return _HOST_MAPPING.get(profile['main']), alt_hosts

        host = _HOST_MAPPING.get(host_name)
        if host:
            UserContext.get().short_host = True
            return host, []

        parsed_uri = urlparse(host_name)
        if (parsed_uri.scheme not in ['http', 'https']) or parsed_uri.netloc == '':
            raise SdsUrlParseError(f'host должен быть одним из {_PROM_HOSTS} или валидным URL')
        UserContext.get().short_host = False
        return {'url': host_name, 'name': host_name}, []

    def _get_jobs_params(self, date_from, date_to, limit, model_version_id, status):
        pairs = []
        if model_version_id:
            pairs.append(('model_version_id', model_version_id))
        if status:
            pairs.append(('status', status))
        if date_to:
            pairs.append(('date_to', date_to))
        if date_from:
            pairs.append(('date_from', date_from))
        if limit:
            pairs.append(('limit', limit))

        pairs.append(('project_area_type', self.project_area_type))

        return dict(pairs)

    def _get_status_request(self, prevalidation_id):
        prevalidation_all_info = self._get_client().get_status(prevalidation_id)
        self._zone.update_prevalidation_info(prevalidation_all_info, self._host)
        update_prevalidation_node_errors(prevalidation_all_info)
        return prevalidation_all_info

    @exception_logger(logger=SdsExceptionLogPrinter())
    @keyboard_interrupt_handler(ki_handler=ki_handlers.session_interface_resume_job)
    def _resume_job(self, prevalidation_id, run_id, trigger_node_id, resources, cpu_only=False, only_current=False):
        if prevalidation_id is None:
            self._resume_job_all(run_id, resources, trigger_node_id)
        else:
            if not is_valid_uuid(prevalidation_id):
                print(
                    f'Похоже, вы указали неверный {self.prevalidation_id_name()}, подставьте {self.prevalidation_id_name()} из вашей {self.get_job_name().get(1)}.')
                return
            self._ensure_authorized()
            self._event_service.print_by_prevalidation(prevalidation_id)
            self._get_client().resume(prevalidation_id,
                                      PreValidationConverter.prepare_resume_body(resources, cpu_only=cpu_only),
                                      only_current=only_current)

            print(f'{self.get_job_name().get(0)} \'{str(prevalidation_id)}\' успешно дозапущена')

            prevalidation_all_info = self._get_status_request(prevalidation_id)
            self._prevalidation = self._prevalidation_all_info_to_prevalidation(prevalidation_all_info)
            self._content_keeper.update(prevalidation=self._prevalidation, keep_method_key=False)
            logger = PrintLogProgress()
            self._prevalidation.start(widget=logger, job_name=self.get_job_name(), content_keeper=self._content_keeper,
                                      question_service=self._question_service)

    def _resume_job_all(self, run_id, resources, trigger_node_id=None):
        if not is_valid_uuid(run_id):
            print(f'Похоже, вы указали неверный run_id, подставьте run_id из вашего запуска.')
            return
        self._ensure_authorized()
        self._get_client().resume_all(run_id, PreValidationConverter.prepare_resume_body(resources, trigger_node_id))
        print(f'Запуск \'{str(run_id)}\' успешно дозапущен')

    @exception_logger(logger=SdsExceptionLogPrinter())
    def get_settings(self, run_id=None, prevalidation_id=None, project_id=None, parent_project_id=None,
                     trigger_node_id=None):
        if run_id is None and prevalidation_id is None and project_id is None and parent_project_id is None:
            prevalidation_id = self.content.prevalidation_id
        return addict(self._get_client().get_settings(
            run_id=run_id,
            prevalidation_id=prevalidation_id,
            project_id=project_id,
            parent_project_id=parent_project_id,
            trigger_node_id=trigger_node_id
        ))

    @exception_logger(logger=SdsExceptionLogPrinter())
    def get_project_details(self, project_id=None):
        if project_id is None:
            project_id = os.getenv('PROJECT_ID', None)
        return self._get_client().get_project_details(project_id)

    def _selected_methods_list(self):
        selected_methods = [self._selected_method]
        if '_selected_methods' in self.__dict__:
            selected_methods = getattr(self, '_selected_methods').methods
        return selected_methods

    @exception_logger(logger=SdsExceptionLogPrinter())
    def check_running_settings(self, run_id=None, prevalidation_id=None, project_id=None, parent_project_id=None,
                               trigger_node_id=None, settings=None, data=None):

        result = True
        if len(settings) > 0:
            methods = self._selected_methods_list()
            prev_val_info = self.get_settings(run_id, prevalidation_id, project_id, parent_project_id, trigger_node_id)
            prev_columns = self._get_columns_info_from_settings(prev_val_info)

            prev_val_dict = {el['methodKey']: el['settings'] for el in prev_val_info if
                             'settings' in el and el['settings']}
            prev_settings = [prev_val_dict[method.info.name] for method in methods]

            curr_settings = self._prepare_settings(settings)
            curr_columns = {col: dataset.selector.rolesAndTypes[col].role.lower() for dataset in data for col in
                            dataset.selector.rolesAndTypes} if data else {}

            print('prev_settings: {}'.format(prev_settings))
            print('curr_settings: {}'.format(curr_settings))

            print('prev_columns: {}'.format(prev_columns))
            print('curr_columns: {}'.format(curr_columns))

            if prev_settings == curr_settings:
                result *= True
                print('Settings are equal')
            else:
                result *= False
                print('Settings are different')

            if prev_columns == curr_columns:
                result *= True
                print('Columns and Roles are equal')
            else:
                result *= False
                print('Columns and Roles are different')

            if result:
                return True

        return False

    @staticmethod
    def _get_columns_info_from_settings(prev_val_settings):
        validation_data_sources = [el['dataSource'] for el in prev_val_settings if
                                   'dataSource' in el and el['dataSource']]

        validation_cols_roles = [el['columns'] for data in validation_data_sources for el in data if
                                 'columns' in el and el['columns']]

        columns_to_compare = {col['name']: correct_role(col['role'].lower()) for data in
                              validation_cols_roles for col in data if
                              correct_role(col['role'].lower()) != 'score'}
        return columns_to_compare

    def _prepare_settings(self, settings):
        all_settings = []
        methods = self._selected_methods_list()
        for method_model in methods:
            settings_from_method = self._method_service.get_method_info(method_model.info.name).settings
            if "groups" in settings_from_method and settings_from_method["groups"] is None:
                settings = {}
            else:
                settings = {} if isinstance(settings, str) else settings
                settings = {**settings, **self.task}
                settings = {**settings, **self.split_settings}
                settings = self._add_common_val_method(settings, method_model.info.name)
                settings = self.setting_dict_checking(settings, eval(
                    self._method_service.get_method_info(method_model.info.name).get_settings_json(
                        settings_from_method).replace(
                        'settings=', '')))
            all_settings.append(settings)
        return all_settings

    @exception_logger(logger=SdsExceptionLogPrinter())
    def get_avm_links(self, avm_user_method_ids, status='ACTIVE', team=None):
        """ Получить доступные методы АВ для пайплайнов АВМ.

        Parameters
        ----------

        avm_user_method_ids: list
            ключи методик АВМ

        status: str
            статус методик (по умолчанию ACTIVE)

        team: str
            доп фильтрация по блоку или команде

        Returns
        -------
        функция возвращает информацию о доступных методах АВ для пайплайнов АВМ

        Examples
        --------
        auto_validator.get_avm_links()

        """
        self._ensure_authorized()
        self._print_all_events()
        return self._method_service.get_avm_links(avm_user_method_ids, status, team)

    def get_job_name(self) -> ConjugatingWord:
        return DummyConjugatingWord(self.project_area_type)

    @staticmethod
    def setting_dict_checking(fact_set_dict: dict, set_from_sdk: dict) -> dict:
        pass
