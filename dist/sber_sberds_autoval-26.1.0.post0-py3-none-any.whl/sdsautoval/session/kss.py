# noinspection PyProtectedMember
# noinspection PyProtectedMember
# noinspection PyProtectedMember
from .question import QuestionSession
from ..exceptions.exception_decorator import exception_logger, keyboard_interrupt_handler
from ..exceptions.sds_exceptions import *
from ..utils import keyboard_interrupt_handlers as ki_handlers


class KssSession(QuestionSession):
    @exception_logger(logger=SdsExceptionLogPrinter())
    @keyboard_interrupt_handler(ki_handler=ki_handlers.session_interface_kss)
    def get_kss_info(self, has_methods=True):
        """
        Получить ML-задачи и подклассы бизнес-задач по которым можно запускать автомоделирование

        Метод возвращает 2 списка: ML-задачи и подклассы бизнес-задач, которые можно использовать для получения рейтинга пайплайнов

        Parameters
        ----------

        has_methods: bool
            показать только те задачи, по которым можно запускать автомоделирование

        Examples
        --------
        auto_modeling.get_kss_info()
        """
        self._kss_service.get_kss_info(has_methods)

    @exception_logger(logger=SdsExceptionLogPrinter())
    @keyboard_interrupt_handler(ki_handler=ki_handlers.session_interface_kss)
    def get_kss_pipelines(self, ml_task=None, business_task_subclass=None, device=None, has_methods=True, tags=None):
        """
        Получить список пайплайнов для выбранного подкласса бизнес-задачи или для ML-задачи

        Parameters
        ----------

        ml_task: str
            ML-задача, полученная методом get_kss_info()

        business_task_subclass: str
            Подкласс бизнес-задачи, полученный методом get_kss_info()

        device: str
            Фильтр по использованию железа, принимает значения GPU или CPU

        has_methods: bool
            показать только те задачи, по которым можно запускать автомоделирование

         tags: bool
            Набор тегов для фильтрации результатов

        Examples
        --------
        auto_modeling.get_kss_pipelines(ml_tasks='BINARY_CLASS')
        """
        self._kss_service.get_kss_pipelines(ml_task=ml_task, business_task_subclass=business_task_subclass,
                                            device=device,
                                            has_methods=has_methods, tags=tags)
