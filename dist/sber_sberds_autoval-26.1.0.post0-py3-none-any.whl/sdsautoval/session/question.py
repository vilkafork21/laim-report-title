# noinspection PyProtectedMember
# noinspection PyProtectedMember
# noinspection PyProtectedMember
from .feedback import FeedbackSession
from ..exceptions.exception_decorator import exception_logger, keyboard_interrupt_handler
from ..exceptions.sds_exceptions import *
from ..utils import keyboard_interrupt_handlers as ki_handlers


class QuestionSession(FeedbackSession):
    @exception_logger(logger=SdsExceptionLogPrinter())
    def _send_question(self, prevalidation_id, node_id, q_key, q_text, q_type="INPUT", q_selection=None, timeout=600):
        """ Отправить вопрос.

         Parameters
        ----------

        prevalidation_id: uuid
            id запущенной превалидации, можно получить через get_settings, подставив env['PROJECT_ID']
        node_id: uuid
            id запущенной ноды, можно получить, подставив env['NODE_ID']
        q_key: str
            ключ вопроса, для удобства и использования при дозапуске
        q_text: str
            текст вопроса
        q_type: str
            тип вопроса, INPUT или SELECT
        q_selection: list
            список вариантов ответа, актуально для типа SELECT
        timeout: int
            таймаут ожидания ответа в секундах, по умолчанию 600=10минут

        Examples
        --------
        auto_validator._send_question('ac13d831-f261-4c41-8c56-d75024127fc7', 'ac13d831-f261-4c41-8c56-d75024127fc4',
            '1', 'Выполняли ли вы качественный анализ?', 'SELECT', ['да','нет'])
        """
        return self._question_service.send_question(prevalidation_id, node_id, q_key, q_type, q_text, q_selection,
                                                    timeout)

    @exception_logger(logger=SdsExceptionLogPrinter())
    def _send_notification(self, prevalidation_id, node_id, q_key, q_text):
        """ Отправить нотификацию.

         Parameters
        ----------

        prevalidation_id: uuid
            id запущенной превалидации, можно получить через get_settings, подставив env['PROJECT_ID']
        node_id: uuid
            id запущенной ноды, можно получить, подставив env['NODE_ID']
        q_key: str
            ключ вопроса, для удобства и использования при дозапуске
        q_text: str
            текст нотификации

        Examples
        --------
        auto_validator._send_notification('ac13d831-f261-4c41-8c56-d75024127fc7', 'ac13d831-f261-4c41-8c56-d75024127fc4',
            '1', 'Доброе утро, вас приветствует Айва')
        """
        return self._question_service.send_notification(prevalidation_id, node_id, q_key, q_text)

    @exception_logger(logger=SdsExceptionLogPrinter())
    @keyboard_interrupt_handler(ki_handler=ki_handlers.session_interface_kss)
    def _send_answer(self, prevalidation_id, question_request_id, a_text):
        """ Отправить ответ на вопрос.

         Parameters
        ----------

        prevalidation_id: uuid
            id запущенной превалидации
        question_request_id: uuid
            id вопроса
        a_text: str
            текст ответа

        Examples
        --------
        auto_validator._send_answer('ac13d831-f261-4c41-8c56-d75024127fc7', 'ac13d831-f261-4c41-8c56-d75024127fc4', 'да')
        """
        return self._question_service.send_answer(prevalidation_id, question_request_id, a_text)

    @exception_logger(logger=SdsExceptionLogPrinter())
    def _get_questions(self, prevalidation_id, node_id, question_request_id=None):
        """ Получить список вопросов.
            Используется для ожидания ответа по конкретному вопросу или на запуске ноды для проверки, не отвечали ли мы ранее,
            а нода была перезапущена.

        Parameters
        ----------

        prevalidation_id: uuid
            id запущенной превалидации, можно получить через get_settings, подставив env['PROJECT_ID']
        node_id: uuid
            id запущенной ноды, можно получить, подставив env['NODE_ID']
        question_request_id: uuid
            id вопроса

        Examples
        --------
        auto_validator._get_questions('ac13d831-f261-4c41-8c56-d75024127fc7', 'ac13d831-f261-4c41-8c56-d75024127fc4')
        """
        return self._question_service.get_questions(prevalidation_id, node_id, question_request_id)

    @exception_logger(logger=SdsExceptionLogPrinter())
    def _send_question_and_wait(self, prevalidation_id, node_id, q_key, q_text, q_type="INPUT", q_selection=None,
                                timeout=600):
        """ Отправить вопрос и в цикле ожидать ответа.

        Parameters
        ----------

        prevalidation_id: uuid
            id запущенной превалидации, можно получить через get_settings, подставив env['PROJECT_ID']
        node_id: uuid
            id запущенной ноды, можно получить, подставив env['NODE_ID']
        q_key: str
            ключ вопроса, для удобства и использования при дозапуске
        q_text: str
            текст вопроса
        q_type: str
            тип вопроса, INPUT или SELECT
        q_selection: list
            список вариантов ответа, актуально для типа SELECT
        timeout: int
            таймаут ожидания ответа в секундах, по умолчанию 600=10минут

        Returns
        --------
        tuple (статус, ответ)
        статусы 'error', 'timeout', 'success'

        Examples
        --------
        auto_validator._send_question_and_wait('ac13d831-f261-4c41-8c56-d75024127fc7', 'ac13d831-f261-4c41-8c56-d75024127fc4',
            '1', 'Выполняли ли вы качественный анализ?', 'SELECT', ['да','нет'])
        """
        return self._question_service.send_question_and_wait(prevalidation_id, node_id, q_key, q_type, q_text,
                                                             q_selection, timeout)
