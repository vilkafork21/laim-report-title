# noinspection PyProtectedMember
from .job_management import JobManagementSession


# noinspection PyProtectedMember


# noinspection PyProtectedMember


class BasicSession(JobManagementSession):
    pass
