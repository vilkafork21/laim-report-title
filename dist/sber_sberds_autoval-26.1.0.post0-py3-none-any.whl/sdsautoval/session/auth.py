import sys
from urllib.parse import urlparse

from .root import SessionRoot
from ..authorizator import Authorizator
from ..authorizator import InternalAuthorizator, Credentials
from ..check_version.version_service import VersionService
from ..colors import FText
from ..context.constants import AUTOVALIDATION_MAIL, SBERDS_MAIL
# noinspection PyProtectedMember
from ..context.constants import _HOSTS
# noinspection PyProtectedMember
from ..context.constants import _HOST_MAPPING
# noinspection PyProtectedMember
from ..context.constants import _PROM_HOSTS
from ..context.user_context import UserContext
from ..event.event_service import EventService
from ..exceptions.exception_decorator import exception_logger, keyboard_interrupt_handler
from ..exceptions.sds_exceptions import *
from ..feedback.feedback_service import FeedbackService
from ..feedback.score_service import ScoreService
from ..fs.fs_service import FsService
from ..jwt_util import parse_jwt
from ..kss.kss_service import KssService
from ..method.method_service import MethodService
from ..mms.mms_service import MmsService
from ..notification.notification_service import NotificationService
from ..prevalidation.prevalidation_utils import *
from ..prevalidation.prevalidation_web_client import PrevalidationWebClient
from ..question.prevalidation_question_service import PreValidationQuestionService
from ..utils import keyboard_interrupt_handlers as ki_handlers
from ..utils.conjugating_word import ConjugatingWord, DummyConjugatingWord
from ..version import __version__
from ..zone_util import ZoneUtil


class AuthSession(SessionRoot):
    """Основной объект - сессия работы


    Examples
    --------
    session = SessionInterface()


    See Also
    --------
    Общая последовательность использования функций SDK
    0. создать обьект "сессия"
    1. authorize: авторизация пользователя
    2.1 ModelProperties: ввод параметров для определения методики
    2.2 ColumnsSelector, add: разметка колонок источников данных
    2.3 DataConnection, DataSample: определение источников данных
    3. run_job: запуск проекта
    """


    @property
    def content(self):
        return self._content_keeper.content()

    def default_object_name(self):
        return 'session_interface'

    def prevalidation_id_name(self):
        return 'prevalidation_id'

    def get_prevalidations_name(self):
        return 'get_prevalidations()'

    @exception_logger(logger=SdsExceptionLogPrinter())
    def authorize_internal(self):
        """
            Авторизация пользователя изнутри SberDS.
        """

        self._host = 'http://sds-template-selector-service:7080'
        self._internal_mode = True

        authorizator = InternalAuthorizator()
        self._token = authorizator.authorize()

        UserContext.get().internal_auth = True
        self._post_authorize()

    @exception_logger(logger=SdsExceptionLogPrinter())
    @keyboard_interrupt_handler(ki_handler=ki_handlers.session_interface_authorize)
    def authorize(self, host=None, domain='omega', credentials: Credentials = None, otp: str = None):
        """Авторизация пользователя.

        Для создания проекта пользователь должен пройти авторизацию в SberDS.
        В параметрах функции необходимо указать константу (prom, psi, ift) или URL стенда.
        Далее последовательно ввести login и password пользователя SberDS.


        Parameters
         ----------
        host: str
            URL стенда SberDS

        domain: str
            домен пользователя СУДИР, допустимые варианты: omega, sigma, alpha, delta
            по умолчанию используется omega

        credentials: Credentials
            предзаведенные логин и пароль

        otp: str
            предзаведенный код из приложения OTP

        Examples
        --------
        auto_validator.authorize('prom')
        auto_validator.authorize('prom', domain='alpha', credentials=Credentials('my_login', 'my_password'))

        See Also
        --------
        Общая последовательность использования функций SDK
        0. создать обьект "сессия"
        1. authorize: авторизация пользователя
        2.1 select_method: выбор методики
        2.2 ColumnsSelector, add: разметка колонок источников данных
        2.3 DataConnection, DataSample, DataArtifact: определение источников данных и артефактов моделирования
        2.4 Settings: формирование дополнительных настроек для запуска проекта
        3. run: запуск проекта
        """
        main_host, alt_hosts = AuthSession._resolve_host(host)
        self._internal_mode = False
        self._host = main_host['url']

        authorizator = Authorizator(main_host, alt_hosts, self._session)
        UserContext.get().internal_auth = False
        self._login, self._token = authorizator.authorize(domain, credentials, otp)
        self._post_authorize()
        UserContext.get().last_env = host

    def _post_authorize(self):
        if self._token is not None:
            self._parsed_token = parse_jwt(self._token)
            self._zone = ZoneUtil(self._parsed_token.zone)
            self._method_service = MethodService(self._host, self._session, self._token, self._internal_mode)
            self._feedback_service = FeedbackService(self._host, self._session, self._token)
            self._score_service = ScoreService(self._host, self._session, self._token)
            self._event_service = EventService(self._host, self._session, self._token, self._internal_mode)
            UserContext.get().event_service = self._event_service
            self._notification_service = NotificationService(self._host, self._session, self._token,
                                                             self._internal_mode)
            self._version_service = VersionService(self._host, self._session, self._token, self._internal_mode)
            self._kss_service = KssService(self._host, self._session, self._token, self._internal_mode)
            self._mms_service = MmsService(self._host, self._session, self._token, self._internal_mode)
            self._fs_service = FsService(self._host, self._session, self._token, self._internal_mode)
            self._question_service = PreValidationQuestionService(self._host, self._session, self._token,
                                                                  self._internal_mode)
            self._check_version()
            self._print_all_events()
            if not UserContext.get().internal_auth:
                self._print_notifications_on_start()
        else:
            self._parsed_token = None
            self._zone = ZoneUtil(None)

    def _print_all_events(self):
        self._event_service.print_all()

    @exception_logger(logger=SdsExceptionLogPrinter())
    def _print_notifications_on_start(self):
        self._notification_service.print_on_start(self.project_area_type)

    def _check_version(self):
        self._ensure_authorized()

        self._version = self._version_service.check_version(__version__)

        if self._version.result == 'OK':
            self._can_validate = True
        elif self._version.result == 'COMPATIBLE':
            self._can_validate = True
            print("Обратите внимание: доступна новая версия SDK.\n" +
                  "\n" +
                  f"Минимально допустимая версия SDK {self._version.minimal_version}\n" +
                  f"Рекомендуем обновить SDK до {self._version.current_version}\n" +
                  "\n" +
                  "Для получения инструкции по обновлению SDK выполните команду:\n" +
                  f"{self.default_object_name()}.get_update_info()")
        else:
            self._can_validate = False
            raise SdsNonCompatibleVersionError(self._version, self._get_update_info())

    def get_update_info(self):
        print(self._get_update_info())

    def _get_update_info(self):
        return f"Для установки {FText.bold('не нужен')} token SberOSC, так как используются только встроенные библиотеки python3.\n" + \
            f"\n" + \
            f"Для обновления SDK в лабораторной зоне воспользуйтесь любым из способов, предложенных ниже.\n" + \
            f"После установки сделать Restart kernel" + Colors.ENDC + "\n" + \
            f"\n" + \
            FText.bold('Способ 1.') + ' Установка из git (предпочтительно в терминале):' + \
            f'   git config http.sslVerify "false"' + \
            f'   pip install --upgrade git+https://df-bitbucket.ca.sbrf.ru/scm/autoval/sds-autoval-sdk.git' + \
            f'   \n' + \
            f'   Потребуется логин/пароль от BitBucket DF.\n' + \
            f"\n" + \
            FText.bold('Способ 2.') + ' Установка из .whl файла.\n' + \
            f'   Скачайте .whl из ветки master по https://df-bitbucket.ca.sbrf.ru/projects/AUTOVAL/repos/sds-autoval-sdk/browse/dist/\n' + \
            f'   Выполните команду: \n' + \
            f'   {sys.executable} -m pip install --upgrade <полный путь к скачанному SDK + полное имя файла вместе с его расширением .whl> --user\n' + \
            f'   Для установки библиотеки на DataLab не нужно указывать --user\n' + \
            f'\n' + \
            f'   Пример:\n' + \
            f'      {sys.executable} -m pip install --upgrade /data/yarn/workspace/20233449_omega-sbrf-ru/notebooks/autovalidation/sdsautoval-23.10.0.post1-py3-none-any.whl --user\n' + \
            FText.bold('Способ 3.') + ' Клонирование репозитория.\n' + \
            f'   Выполните git clone https://df-bitbucket.ca.sbrf.ru/scm/autoval/sds-autoval-sdk.git\n' + \
            f'   Установите библиотеку из .whl аналогично способу 2.\n' + \
            f'\n' + \
            f"Если возникли трудности с установкой, пожалуйста, свяжитесь с нами:\n" + \
            f"Почта: {AUTOVALIDATION_MAIL}, {SBERDS_MAIL}\n" + \
            f"Тема: Не получается установить SDK автовалидации"

    def _set_dev_zone(self, zone: str):
        """
        Устанавливает зону для запросов к серверу (для DEV/ST тестирования).
        """
        self._session.set_zone(zone)

    def _set_qa_mode(self):
        """
        Устанавливает cookie для возможности бета-тестирования.
        """
        self._session.set_qa_mode()

    def _unset_qa_mode(self):
        """
        Устанавливает cookie, который убирает воможность бета-тестирования.
        """
        self._session.unset_qa_mode()

    def _get_client(self):
        if self._client is None:
            self._client = PrevalidationWebClient(self._host, self._session, self._token, self._internal_mode)
        return self._client

    def _ensure_can_validate(self):
        self._ensure_authorized()
        if not self._can_validate:
            raise SdsNonCompatibleVersionError(self._version, self._get_update_info())

    def _ensure_authorized(self):
        if self._token is None:
            raise SdsNotAuthorizedError()

    @staticmethod
    def _resolve_host(host_name: str):
        if not host_name or len(host_name) == 0:
            raise SdsUrlParseError(f"Метод auto_validator('host') требует заполнить параметр 'host'")

        profile = _HOSTS.get(host_name)
        if profile:
            additionals = profile.get('additional', [])
            alt_hosts = []
            for additional in additionals:
                alt_host = _HOST_MAPPING.get(additional)
                if alt_host:
                    alt_hosts.append({'key': additional, 'name': alt_host['name']})
            UserContext.get().short_host = True
            return _HOST_MAPPING.get(profile['main']), alt_hosts

        host = _HOST_MAPPING.get(host_name)
        if host:
            UserContext.get().short_host = True
            return host, []

        parsed_uri = urlparse(host_name)
        if (parsed_uri.scheme not in ['http', 'https']) or parsed_uri.netloc == '':
            raise SdsUrlParseError(f'host должен быть одним из {_PROM_HOSTS} или валидным URL')
        UserContext.get().short_host = False
        return {'url': host_name, 'name': host_name}, []



    def get_job_name(self) -> ConjugatingWord:
        return DummyConjugatingWord(self.project_area_type)
