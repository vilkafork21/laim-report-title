# noinspection PyProtectedMember
from .auth import AuthSession
# noinspection PyProtectedMember
from ..exceptions.exception_decorator import exception_logger
from ..exceptions.exceptions import NotFoundError, ForbiddenError, BadRequestError
from ..exceptions.sds_exceptions import *
# noinspection PyProtectedMember
from ..util import is_valid_uuid


class FeedbackSession(AuthSession):
    @exception_logger(logger=SdsExceptionLogPrinter())
    def create_issue(self, description: str, subject: str = 'AutoValidation'):
        """ Отправить отчет об ошибке.

        Загрузка данных K1 и K2 запрещена.


        Parameters
        ----------
        description : str
            Описание ошибки в свободной форме.

        subject : str
            Классификатор ошибок, указать: AutoValidation


        Returns
        -------
        issueId идентификатор обращения


        Examples
        --------
        auto_validator.create_issue('Описание ошибки', 'AutoValidation')

        """
        self._ensure_authorized()
        url = self._host
        if self._prevalidation is not None:
            workflow_url = self._prevalidation.get_project_link()
            if workflow_url is not None:
                url = workflow_url

        self._feedback_service.send_feedback(url, description, subject)

    def _send_feedback(self, usability: int, valuability: int, prevalidation_id=None):
        pv_id = prevalidation_id
        if pv_id is None and self._prevalidation is not None:
            pv_id = self._prevalidation.prevalidation_id

        if pv_id is None:
            print(
                f'Активная {self.get_job_name().get(0)} не найдена, мы не можем зафиксировать оценку без {self.prevalidation_id_name()}, '
                f'пожалуйста запустите проект или заполните параметр {self.prevalidation_id_name()}.\n'
                f'Например: send_feedback(usability=5, valuability=5, {self.prevalidation_id_name()}=\'укажите тут uuid\')')
            return

        if not is_valid_uuid(pv_id):
            print(
                f'Похоже, вы указали неверный {self.prevalidation_id_name()}, подставьте {self.prevalidation_id_name()} из вашей {self.get_job_name().get(1)}.')
            return

        if prevalidation_id is not None:
            try:
                self._get_client().get_status_impl(prevalidation_id)
            except (NotFoundError, ForbiddenError, BadRequestError) as _:
                print(
                    f'Мы не нашли указанный {self.prevalidation_id_name()} в списке ваших {self.get_job_name().get(1, plural=True)}.\n'
                    f'Пожалуйста, запустите {self.get_job_name().get(3)} или укажите идентификатор {self.prevalidation_id_name()}.\n'
                    f'Список ваших {self.get_job_name().get(1, plural=True)} можно получить методом {self.get_prevalidations_name()}')
                return

        # method_id from prevalidation when use current else None
        method_id = None
        if prevalidation_id is None:
            if self._prevalidation is not None:
                method_id = self._prevalidation.get_method_id()
            if method_id is None and self._selected_method is not None:
                method_id = self._selected_method.info.method_id

        if not 1 <= usability <= 5:
            print(
                'Пожалуйста укажите оценки - целое число от 1 до 5, где 1 - совсем не удобно / не полезно, а 5 - очень удобно / очень полезно')
            return
        if not 1 <= valuability <= 5:
            print(
                'Пожалуйста укажите оценки - целое число от 1 до 5, где 1 - совсем не удобно / не полезно, а 5 - очень удобно / очень полезно')
            return

        self._score_service.send_score(usability, 'USABILITY', pv_id, method_id)
        self._score_service.send_score(valuability, 'VALUE', pv_id, method_id)
        print(
            f'Вы оценили проведенную {self.get_job_name().get(3)} так: Полезность = {valuability}, Удобство = {usability}. '
            f'Спасибо за вашу обратную связь!')
