# noinspection PyProtectedMember
# noinspection PyProtectedMember
from .kss import KssSession
from ..dto.model_version_info import ModelVersionInfo
# noinspection PyProtectedMember
from ..exceptions.exception_decorator import exception_logger
from ..exceptions.sds_exceptions import *


class MmsSession(KssSession):
    @exception_logger(logger=SdsExceptionLogPrinter())
    def get_mms_schema(self):
        """ Получить схему данных из библиотеки моделей (MMS).

        Returns
        -------
        Схема данных, доступная в библиотеке моделей

        Examples
        --------
        auto_validator.get_mms_schema()
        """
        return self._mms_service.get_mms_schema()

    @exception_logger(logger=SdsExceptionLogPrinter())
    def get_model_version_info(self, model_version_id: int) -> ModelVersionInfo:
        """ Получить Информацию о версии модели из библиотеки моделей.

        Parameters
        ----------

        model_version_id: int
            идентификатор модели в БМ

        Returns
        -------
        ModelVersionInfo с атрибутами:
            model_version_id             ID версии модели
            data_type                    Тип данных
            task_type                    Тип задачи
            modeling_method              Метод моделирования
            weights_in_command_space     Ссылка на веса модели в командном пространстве
            model_code_bitbucket         Ссылка на код модели в BitBucket
            artifacts_repository_bb      Ссылка на репозиторий, содержащий артефакты в Bitbucket
            branch_bitbucket             Ветка репозитория, содержащего артефакты в Bitbucket
            model_code_refit_bb          Ссылка на репозиторий, содержащий артефакты код дообучения модели в Bitbucket
            model_code_refit_branch_bb   Ветка репозитория, содержащего код дообучения в Bitbucket
            pkl_link                     Ссылка на prod-репозиторий в MLStorage (.pkl)
            data_set_link                Ссылка на датасеты в MLStorage
            model_version_status         Статус версии модели
            developer_block              Наименование блока разработчиков
            cds_block                    Наименование блока центра валидации
            importance_umr               Степень значимости
            new_importance_umr           Новая степень значимости
            feature_store_id             ID проекта в FeatureStore

        Examples
        --------
        auto_validator.get_model_version_info(476740)

        """
        return self._mms_service.get_model_version_info(model_version_id)

    @exception_logger(logger=SdsExceptionLogPrinter())
    def edit_model_version(self, prevalidation_id=None, snapshot_id=None, model_version=None, data=None, timeout=60):
        """ Отправить запрос на редактирование модели в БМ и в цикле ожидать ответа.

        Parameters
        ----------

        prevalidation_id: uuid
            id превалидации, выполняемой внутри проекта дообучения, из которого будут переданы записи в карточку библиотеки моделей
        snapshot_id: uuid
            id проекта дообучения, из которого будут переданы записи в карточку библиотеки моделей
        model_version: int
            id версии модели в БМ, которую нужно редактировать
        data: dict
            данные для редактирования модели в БМ
        timeout: int
            таймаут ожидания ответа в секундах, по умолчанию 60=1минута

        Returns
        --------
        tuple (статус, ответ)
        статусы 'error', 'in_process', 'success'

        Examples
        --------
        auto_validator.edit_model_version(prevalidation_id='ac13d831-f261-4c41-8c56-d75024127fc7', snapshot_id='ac13d831-f261-4c41-8c56-d75024127fc4')
        auto_validator.edit_model_version(model_version=123, data={"TEST": "one", "TEST2": ["two"], "TEST3": ["one","two"]})
        """
        return self._mms_service.edit_model_version(prevalidation_id, snapshot_id, model_version, data, timeout)

    @exception_logger(logger=SdsExceptionLogPrinter())
    def edit_model_version_status(self, request_id, timeout=60):
        """ Проверить запрос на редактирование модели в БМ и в цикле ожидать ответа если редактирование не завершено.

        Parameters
        ----------

        request_id: uuid
            id запроса на редактирование модели в библиотеке моделей
        timeout: int
            таймаут ожидания ответа в секундах, по умолчанию 60=1минута

        Returns
        --------
        tuple (статус, ответ)
        статусы 'error', 'in_process', 'success'

        Examples
        --------
        auto_validator.edit_model_version_status('ac13d831-f261-4c41-8c56-d75024127fc7')
        """
        return self._mms_service.edit_model_version_status(request_id, timeout)

    @exception_logger(logger=SdsExceptionLogPrinter())
    def clone_model_version(self, model_version_id, timeout=60):
        """ Отправить запрос на клонирование модели в БМ и в цикле ожидать ответа.

        Parameters
        ----------

        model_version_id: int
            id клонируемой модели
        timeout: int
            таймаут ожидания ответа в секундах, по умолчанию 60=1минута

        Returns
        --------
        tuple (статус, request_id, model_version_id)
        статусы 'error', 'in_progress', 'success'

        Examples
        --------
        auto_validator.clone_model_version(444444)
        """
        return self._mms_service.clone_model_version(model_version_id, timeout)

    @exception_logger(logger=SdsExceptionLogPrinter())
    def clone_model_version_status(self, request_id, timeout=60):
        """ Проверить запрос на клонирование модели в БМ и в цикле ожидать ответа если редактирование не завершено.

        Parameters
        ----------

        request_id: uuid
            id запроса на редактирование модели в библиотеке моделей
        timeout: int
            таймаут ожидания ответа в секундах, по умолчанию 60=1минута

        Returns
        --------
        tuple (статус, ответ)
        статусы 'error', 'in_progress', 'success'

        Examples
        --------
        auto_validator.clone_model_version_status('ac13d831-f261-4c41-8c56-d75024127fc7')
        """
        return self._mms_service.clone_model_version_status(request_id, timeout)

    @exception_logger(logger=SdsExceptionLogPrinter())
    def get_model_version(self, project_id):
        return self._mms_service.get_model_version(project_id)
