# noinspection PyProtectedMember
# noinspection PyProtectedMember
# noinspection PyProtectedMember
from .mms import MmsSession
from ..exceptions.exception_decorator import exception_logger
from ..exceptions.sds_exceptions import *
from ..score.score import Scores
from ..utils.args import kwargs_get


class FeatureStoreSession(MmsSession):

    @exception_logger(logger=SdsExceptionLogPrinter())
    def get_long_list(self, feature_store_project_id, timeout=60):
        """ Отправить запрос на получение long-list и в цикле ожидать ответа.

        Parameters
        ----------

        feature_store_project_id: int
            id проекта в FeatureStore
        timeout: int
            таймаут ожидания ответа в секундах, по умолчанию 60=1минута

        Returns
        --------
        tuple (статус, request_id, feature_store_project_id)
        статусы 'error', 'in_progress', 'success'

        Examples
        --------
        auto_validator.get_long_list(444444)
        """
        return self._fs_service.get_long_list(feature_store_project_id, timeout)

    @exception_logger(logger=SdsExceptionLogPrinter())
    def get_long_list_status(self, request_id, timeout=60):
        """ Проверить запрос на получение long-list и в цикле ожидать ответа если он ещё не получен.

        Parameters
        ----------

        request_id: uuid
            id запроса на получение long-list
        timeout: int
            таймаут ожидания ответа в секундах, по умолчанию 60=1минута

        Returns
        --------
        tuple (статус, ответ)
        статусы 'error', 'in_progress', 'success'

        Examples
        --------
        auto_validator.get_long_list_status('ac13d831-f261-4c41-8c56-d75024127fc7')
        """
        return self._fs_service.get_long_list_status(request_id, timeout)

    @exception_logger(logger=SdsExceptionLogPrinter())
    def get_short_list(self, feature_store_project_id, timeout=60):
        """ Отправить запрос на получение short-list и в цикле ожидать ответа.

        Parameters
        ----------

        feature_store_project_id: int
            id проекта в FeatureStore
        timeout: int
            таймаут ожидания ответа в секундах, по умолчанию 60=1минута

        Returns
        --------
        tuple (статус, request_id, feature_store_project_id)
        статусы 'error', 'in_progress', 'success'

        Examples
        --------
        auto_validator.get_short_list(444444)
        """
        return self._fs_service.get_short_list(feature_store_project_id, timeout)

    @exception_logger(logger=SdsExceptionLogPrinter())
    def get_short_list_status(self, request_id, timeout=60):
        """ Проверить запрос на получение short-list и в цикле ожидать ответа если он ещё не получен.

        Parameters
        ----------

        request_id: uuid
            id запроса на получение short-list
        timeout: int
            таймаут ожидания ответа в секундах, по умолчанию 60=1минута

        Returns
        --------
        tuple (статус, ответ)
        статусы 'error', 'in_progress', 'success'

        Examples
        --------
        auto_validator.get_short_list_status('ac13d831-f261-4c41-8c56-d75024127fc7')
        """
        return self._fs_service.get_short_list_status(request_id, timeout)

    @exception_logger(logger=SdsExceptionLogPrinter())
    def submit_shortlist(self, fs_project_id, aliases, scores=None, **kwargs):
        """ Отправить запрос short-list и в цикле ожидать ответа если он ещё не получен.

        Parameters
        ----------

        fs_project_id: uuid
            id проекта FeatureStore
        aliases:
            список алиасов
        scores: Scores, optional
            объект Scores, содержащий список score-ов с полями scoreAlias, scoreId, modelVersion
        timeout: int
            таймаут ожидания ответа в секундах, по умолчанию 60=1минута

        Returns
        --------
        tuple (статус, ответ)
        статусы 'error', 'in_progress', 'success'

        Examples
        --------
        # Без scores
        auto_validator.submit_shortlist(300817, ['fraud_flag', 'transaction_amount'])

        # С scores
        scores = Scores()
        scores.add(score_alias='IM456029_Score_1', score_id='MV456033_pd_bki', model_version_id=456033)
        scores.add(score_alias='IM456029_Score_2', score_id='MV456030_pd_bki', model_version_id=456030)
        auto_validator.submit_shortlist(300817, ['fraud_flag'], scores=scores)
        """
        timeout = kwargs_get(kwargs, 'timeout', 60)

        # Формируем параметры для передачи в _submit_shortlist
        if scores is not None:
            scores = Scores.sanitize(scores)
            scores_data = scores.to_dict_camel()
            return self._submit_shortlist(fs_project_id, aliases, scores_data, timeout=timeout)
        else:
            return self._submit_shortlist(fs_project_id, aliases, {}, timeout=timeout)

    def _submit_shortlist(self, fs_project_id, aliases, scores_data, timeout=60):
        return self._fs_service.submit_shortlist(fs_project_id, aliases, scores_data, timeout=timeout)

    def check_submit_shortlist(self, request_id, **kwargs):
        """ Проверить запрос short-list и в цикле ожидать ответа если он ещё не получен.

        Parameters
        ----------

        request_id: uuid
            id запроса short-list
        timeout: int
            таймаут ожидания ответа в секундах, по умолчанию 60=1минута

        Returns
        --------
        tuple (статус, ответ)
        статусы 'error', 'in_progress', 'success'

        Examples
        --------
        auto_validator.check_submit_shortlist('ac13d831-f261-4c41-8c56-d75024127fc7')
        """
        timeout_seconds = kwargs_get(kwargs, 'timeout_seconds', 60)
        return self._check_submit_shortlist(request_id, timeout_seconds=timeout_seconds)

    def _check_submit_shortlist(self, request_id, timeout_seconds=60):
        return self._fs_service.check_submit_shortlist(request_id, timeout_seconds=timeout_seconds)
