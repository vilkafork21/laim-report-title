import sys
from typing import Optional

from ..colors import FText
from ..content import ContentKeeper
from ..context.constants import AUTOVALIDATION_MAIL, SBERDS_MAIL
# noinspection PyProtectedMember
# noinspection PyProtectedMember
# noinspection PyProtectedMember
from ..context.user_context import UserContext
from ..prevalidation.prevalidation_utils import *
from ..prevalidation.prevalidation_web_client import PrevalidationWebClient
from ..rest_utils import SimpleSession
from ..utils.conjugating_word import ConjugatingWord, DummyConjugatingWord
from ..version import __version__
from ..zone_util import ZoneUtil


class _CommunicationData:
    def __init__(self):
        self._session = SimpleSession()
        self._token = Optional[str]


class SessionRoot:
    """Основной объект - сессия работы


    Examples
    --------
    session = SessionInterface()


    See Also
    --------
    Общая последовательность использования функций SDK
    0. создать обьект "сессия"
    1. authorize: авторизация пользователя
    2.1 ModelProperties: ввод параметров для определения методики
    2.2 ColumnsSelector, add: разметка колонок источников данных
    2.3 DataConnection, DataSample: определение источников данных
    3. run_job: запуск проекта
    """

    def __init__(self):
        self._client = None
        self._session = SimpleSession()
        self._method_prevalidation_map = {}
        self._token = None
        self._host = None
        self._team = None
        self._internal_mode = None
        self._feedback_service = None
        self._score_service = None
        self._event_service = None
        self._notification_service = None
        self._version_service = None
        self._method_service = None
        self._kss_service = None
        self._mms_service = None
        self._fs_service = None
        self._question_service = None
        self._prevalidation = None
        self._can_validate = False
        self._version = None
        self._methods = None
        self._selected_method = None
        self._selected_method_id = None
        self._login = None
        self._parsed_token = None
        self._zone = ZoneUtil(None)
        self.project_area_type = None
        self.method_columns = None
        self._prevalidation_run = None
        UserContext.get().version = __version__
        self._content_keeper = ContentKeeper(session=self)

    @property
    def content(self):
        return self._content_keeper.content()

    def default_object_name(self):
        return 'session_interface'

    def prevalidation_id_name(self):
        return 'prevalidation_id'

    def get_prevalidations_name(self):
        return 'get_prevalidations()'

    def get_job_name(self) -> ConjugatingWord:
        return DummyConjugatingWord(self.project_area_type)

    def get_update_info(self):
        print(self._get_update_info())

    def _get_update_info(self):
        return f"Для установки {FText.bold('не нужен')} token SberOSC, так как используются только встроенные библиотеки python3.\n" + \
            f"\n" + \
            f"Для обновления SDK в лабораторной зоне воспользуйтесь любым из способов, предложенных ниже.\n" + \
            f"После установки сделать Restart kernel" + Colors.ENDC + "\n" + \
            f"\n" + \
            FText.bold('Способ 1.') + ' Установка из git (предпочтительно в терминале):' + \
            f'   git config http.sslVerify "false"' + \
            f'   pip install --upgrade git+https://df-bitbucket.ca.sbrf.ru/scm/autoval/sds-autoval-sdk.git' + \
            f'   \n' + \
            f'   Потребуется логин/пароль от BitBucket DF.\n' + \
            f"\n" + \
            FText.bold('Способ 2.') + ' Установка из .whl файла.\n' + \
            f'   Скачайте .whl из ветки master по https://df-bitbucket.ca.sbrf.ru/projects/AUTOVAL/repos/sds-autoval-sdk/browse/dist/\n' + \
            f'   Выполните команду: \n' + \
            f'   {sys.executable} -m pip install --upgrade <полный путь к скачанному SDK + полное имя файла вместе с его расширением .whl> --user\n' + \
            f'   Для установки библиотеки на DataLab не нужно указывать --user\n' + \
            f'\n' + \
            f'   Пример:\n' + \
            f'      {sys.executable} -m pip install --upgrade /data/yarn/workspace/20233449_omega-sbrf-ru/notebooks/autovalidation/sdsautoval-23.10.0.post1-py3-none-any.whl --user\n' + \
            FText.bold('Способ 3.') + ' Клонирование репозитория.\n' + \
            f'   Выполните git clone https://df-bitbucket.ca.sbrf.ru/scm/autoval/sds-autoval-sdk.git\n' + \
            f'   Установите библиотеку из .whl аналогично способу 2.\n' + \
            f'\n' + \
            f"Если возникли трудности с установкой, пожалуйста, свяжитесь с нами:\n" + \
            f"Почта: {AUTOVALIDATION_MAIL}, {SBERDS_MAIL}\n" + \
            f"Тема: Не получается установить SDK автовалидации"

    def _set_dev_zone(self, zone: str):
        """
        Устанавливает зону для запросов к серверу (для DEV/ST тестирования).
        """
        self._session.set_zone(zone)

    def _set_qa_mode(self):
        """
        Устанавливает cookie для возможности бета-тестирования.
        """
        self._session.set_qa_mode()

    def _unset_qa_mode(self):
        """
        Устанавливает cookie, который убирает воможность бета-тестирования.
        """
        self._session.unset_qa_mode()

    def _get_client(self):
        if self._client is None:
            self._client = PrevalidationWebClient(self._host, self._session, self._token, self._internal_mode)
        return self._client
