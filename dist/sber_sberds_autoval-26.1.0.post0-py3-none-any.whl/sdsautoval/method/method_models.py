import ast
import io
import json
import pprint
import textwrap
from collections import UserList

from sdsautoval.context.user_context import UserContext
from ..colors import Colors
from ..examples.examples import EXAMPLES
from ..modprop import ModelConstants
from ..util import SimpleTable, text_table, _render_html, HtmlHelper, PrettyList, CommaSeparatedListFormatter, \
    TableDisplayStyle, CellDisplayStyle, SUMMARY_CSS, HRef
from ..utils.args import is_dict_with_elements
from ..utils.stream import stream

MAX_DESCRIPTION_LEN = 120


class DictionaryMapper:
    def __init__(self, dictionaries: dict):
        self.dictionaries = dictionaries
        self.keys = {
            "department": "Бизнес-Блок",
            "researchPhase": "Этап расчета",
            "researchObject": "Объект воздействия",
            "testTypeCode": "Тип теста",
            "activityTypeCode": "Тип активности",
            "homogeneityFeatureName": "Название признака однородности",
            "productName": "Продукт",
            "channel": "Целевой канал",
            "crossChannelCan": "Кросс-канальная каннибализация",
            "crossProductCan": "Кросс-продуктовая каннибализация",
            "operationalMetric": "Операционная метрика",
            "keyOperationalIndicator": "Ключевой операционный показатель",
            "financialMetric": "Ключевая финансовая метрика",
            "dataType": "Тип данных",
            "cdsBlock": "Название блока",
            "taskType": "Тип задачи",
            "metricsName": "Название метрики",
            "columnType": "Тип столбца",
            "sampleType": "Тип образца",
            "columnRole": "Роль столбца",
            "description": "Описание"
        }

    def __len__(self):
        if self.dictionaries:
            return len(self.dictionaries)
        else:
            return 0

    def get(self, dict_id, key):
        return self.dictionaries.get(dict_id, {}).get(key, key)

    def get_key(self, key):
        return self.keys.get(key, key)


class DataSourceModel:
    columns = ['key', 'type', 'description', 'required', 'structured']

    def __init__(self, key, type, description, required, structured):
        self.key = key
        self.type = type
        self.description = description
        self.required = required
        self.structured = structured

    def to_list(self):
        return [self.key, self.type, self.description, self.required,
                self.structured]

    @staticmethod
    def from_list(records):
        return stream(records) \
            .filter(lambda x: x is not None) \
            .map(lambda x:
                 DataSourceModel(
                     x.get('key', None),
                     x.get('type', None),
                     x.get('description', None),
                     x.get('required', None),
                     x.get('structured', None))) \
            .collect(list)

    def __str__(self):
        return f'{self.key}'

    def __repr__(self):
        return self.__str__()


class MethodModel:
    """ Pre-validation method model.

    Attributes:
        method_id    method id
        method_key user method id
        name         method name
        description  method description
        data_type    method data type
        task_type    method task type
        metrics_name method main metric name
        cds_block    CDS block
        data_sources_sample  list of data source sample names, e.g. ['train', 'out_of_sample']
        data_sources_artifact  list of data source artifact names, e.g. ['model']
    """

    def __init__(self, dicts: DictionaryMapper,
                 method_id: str, method_key: str, name: str,
                 description: str, data_type: str, task_type: str, metrics_name: str,
                 cds_block: str,
                 responsible_users: list, contacts: list,
                 version, ready_to_activate,
                 data_sources: [DataSourceModel],
                 additional_fields=None,
                 persistent_volume=None):

        if additional_fields is None:
            additional_fields = []
        self.method_id = method_id
        self.method_key = method_key
        self.name = name
        self.version = version
        self.ready_to_activate = ready_to_activate
        self.description = description
        self.data_type = data_type
        self.task_type = task_type
        self.metrics_name = metrics_name
        self.cds_block = cds_block
        self.data_sources_sample = [source for source in data_sources if source.type == 'sample']
        self.data_sources_artifact = [source for source in data_sources if source.type == 'artifact']
        self.responsible_users = [user for user in responsible_users if user.get('fullName', None) is not None]
        self.contacts = [contact for contact in contacts if contact.get('serviceName', None) is not None]
        self.additional_fields = additional_fields
        self.dicts = dicts
        self.translated_additional_fields = self.translate_additional_fields()
        self.persistent_volume = None
        if is_dict_with_elements(persistent_volume):
            if persistent_volume.get('usePV', False):
                self.persistent_volume = persistent_volume
        self.draft = False
        self.method_example_url = self.get_method_example_url()

    def get_method_example_url(self):
        env = 'sigma'
        if UserContext.get().last_env_is_prom():
            env = 'alpha'
        elif UserContext.get().last_env_is_lab_ift():
            env = 'delta'
        return EXAMPLES.get(self.method_key, {}).get(env, None)

    def get_block_info(self):
        def _append_to_info(info_str, key, value):
            if value:
                info_str += f"* {key}: {value}\n"
            return info_str
        info = "Информация о выбранной методике:\n\n"
        info = _append_to_info(info, 'method_id', self.method_id)
        info = _append_to_info(info, 'method_key', self.method_key)
        info = _append_to_info(info, 'name', self.name)
        info = _append_to_info(info, 'description', self.description)

        if self.persistent_volume:
            info = _append_to_info(info, 'persistent volume', str(self.persistent_volume.get('pvSize', 0)) + ' GiB')

        for key, value in self.translated_additional_fields.items():
            info = _append_to_info(info, key, value)

        if self.responsible_users and len(self.responsible_users) > 0:
            info += "Валидаторы, ответственные за методику:\n"
            for user in self.responsible_users:
                info += user['fullName']
                if 'email' in user:
                    info += f" ({user['email']})\n"
                else:
                    info += "\n"
            info += "\n"

        info += "Требования к источникам данных:\n"
        info += text_table([x.to_list() for x in self.data_sources_sample],
                           DataSourceModel.columns)
        info += "Требования к артефактам моделирования:\n"
        info += text_table([x.to_list() for x in self.data_sources_artifact],
                           DataSourceModel.columns)
        info += "\n"
        return info

    def get_block_info_html(self):
        def row(*argv, header=None, escape=True):
            out = '<tr>'
            if header is not None:
                out += f'<th>{HtmlHelper.escape(header)}</th>'
            for cell in argv:
                if escape:
                    out += f'<td>{HtmlHelper.escape(cell)}</td>'
                else:
                    out += f'<td>{cell}</td>'
            out += '</tr>'
            return out

        def append_row(out, header, value, escape=True):
            if value:
                out += row(value, header=header, escape=escape)
            return out

        out = """
            <script>
                function closeDetail(detailsElement) {
                    detailsElement.removeAttribute("open");
                    window.location = '#' + detailsElement.id;
                }
            </script>
            <div class='rendered_html'>
            <style scoped>
                .dataframe tbody tr th {
                    text-align: left;
                }
                .dataframe tbody tr td {
                    text-align: left;
                }
                .spoiler >  input + .box {
                    display: none;
                }
                .spoiler >  input:checked + .box {
                    display: block;
                }
            </style>
        """
        out += SUMMARY_CSS
        out += "<h2>Информация о выбранной методике</h2>"
        out += '<table border="1" class="dataframe">'
        out += '<thead><tr><th>Name</th><th>Value</th></tr></thead>'
        out += '<tbody>'
        out = append_row(out, 'method_id', self.method_id)
        out = append_row(out, 'method_key', self.method_key)
        out = append_row(out, 'name', self.name)

        if self.draft:
            out = append_row(out, 'Версия', self.version)
            out = append_row(out, 'Готово к активации', self.ready_to_activate)

        description = self.description
        description = shorten_description(description)
        out = append_row(out, 'description', description, escape=False)

        if self.persistent_volume:
            out = append_row(out, 'persistent volume', str(self.persistent_volume.get('pvSize', 0)) + ' GiB')

        for key, value in self.translated_additional_fields.items():
            out = append_row(out,  key, value)

        example_url = self.method_example_url
        if example_url:
            out = append_row(out, "Пример использования методики", f"<a href='{example_url}'>{example_url}</a>",
                             escape=False)

        out += '</tbody></table>'

        if (self.responsible_users and len(self.responsible_users) > 0):
            out += f'<h3>Валидаторы, ответственные за методику</h3>'
            out += '<table border="1" class="dataframe"><thead></thead>'
            out += '<thead><tr><th>ФИО</th><th>Email</th></tr></thead>'
            out += '<tbody>'
            for user in self.responsible_users:
                out += row(user['fullName'], user.get('email', ''))
            out += '</tbody></table>'

        if len(self.data_sources_sample) > 0:
            out += f'<h3>Требования к источникам данных</h3>'
            out += '<table border="1" class="dataframe"><thead></thead>'
            out += '<thead><tr><th>Key</th><th>Required</th><th>Description</th></tr></thead>'
            out += '<tbody>'
            for sample in self.data_sources_sample:
                out += row(sample.required, sample.description, header=sample)
            out += '</tbody></table>'

        if len(self.data_sources_artifact) > 0:
            out += f'<h3>Требования к артефактам моделирования</h3>'
            out += '<table border="1" class="dataframe"><thead></thead>'
            out += '<thead><tr><th>Key</th><th>Required</th><th>Description</th></tr></thead>'
            out += '<tbody>'
            for sample in self.data_sources_artifact:
                out += row(sample.required, sample.description, header=sample)
            out += '</tbody></table>'

        out += '</div>'
        return out

    def __str__(self):
        return self.get_block_info()

    def translate_additional_fields(self) -> dict:
        translated_additional_fields = {}
        for field in self.additional_fields:
            key = field['key']
            value = field['value']
            translated_key = self.translate_key(key)
            translated_value = self.translate_value(key, value)
            self.merge_key_to_dict(translated_additional_fields, translated_key, translated_value)
        return translated_additional_fields

    def merge_key_to_dict(self, dict_, key, value):
        if key in dict_.keys():
            old_value = dict_[key]
            old_value = self.merge_values_if_needed(old_value, value)
            dict_[key] = old_value
        else:
            dict_[key] = value

    # noinspection PyMethodMayBeStatic
    def merge_values_if_needed(self, old_value, translated_value):
        if not (isinstance(old_value, list) or isinstance(old_value, UserList)):
            old_value = PrettyList([old_value, translated_value], formatter=CommaSeparatedListFormatter())
        else:
            old_value.append(translated_value)
        return old_value

    def translate_value(self, key, value):
        return self.dicts.get(key, value)

    def translate_key(self, key):
        return self.dicts.get_key(key)

    def get_example_html(self):
        if self.method_example_url:
            return HRef(HtmlHelper.escape(f'[Перейти к примеру]'), self.method_example_url)
        else:
            return None


def shorten_description(description):
    if description is None:
        return description
    description = HtmlHelper.escape(str(description))
    if len(description) > MAX_DESCRIPTION_LEN:
        wrap = textwrap.wrap(description, MAX_DESCRIPTION_LEN)
        summary = wrap[0]
        details = '\n'.join(wrap)
        description = (f'<details>' +
                       f'<summary><div class="summary-text">{summary}</div></summary>' +
                       f'{details}' +
                       f'<div class="summary-close-button" onclick="closeDetail(this.parentElement)">Свернуть</div>' +
                       f'</details>')
    return description


class MethodList:

    def __init__(self, methods: [MethodModel]):
        self.methods = methods
        self.keep_columns = None
        self._not_printing_cols = ['Тип данных']

    def to_dataframe(self):
        return self.to_table().filter(self.keep_columns).to_dataframe()

    def to_table(self) -> SimpleTable:
        table_display_style = TableDisplayStyle(cell_style=CellDisplayStyle(max_characters=120))
        default_fields = [
            'method_key',
            'data_samples',
            'artifacts',
            'name',
            'description',
            'Пример'
        ]

        items = []

        for model in self.methods:
            if len(model.data_sources_sample) > 0:
                _ds_sample = PrettyList(model.data_sources_sample, formatter=CommaSeparatedListFormatter())
            else:
                _ds_sample = '-'
            if len(model.data_sources_artifact) > 0:
                _ds_artifact = PrettyList(model.data_sources_artifact, formatter=CommaSeparatedListFormatter())
            else:
                _ds_artifact = '-'

            values = [
                model.method_key,
                _ds_sample,
                _ds_artifact,
                model.name,
                model.description,
                model.get_example_html(),
                model.task_type,
                model.metrics_name,
                model.cds_block
            ]

            item = {}
            for i in range(len(default_fields)):
                item[default_fields[i]] = values[i]
            for key, value in model.translated_additional_fields.items():
                if key not in self._not_printing_cols:
                    item[key] = value
            items.append(item)

        fields = []
        table = []
        for item in items:
            for key in item.keys():
                if key not in fields:
                    fields.append(key)
        for item in items:
            row = []
            for field in fields:
                if field in item.keys():
                    value = item.get(field, None)
                    if field == 'description':
                        value = shorten_description(value)
                    row.append(value)
                else:
                    row.append(None)
            table.append(row)
        return SimpleTable(table, fields, display_style=table_display_style) \
            .filter_empty() \
            .filter(keep_columns=self.keep_columns) \
            .replace_empty(replacement='-')

    def __str__(self):
        out = ''
        for m in self.methods:
            out += m.get_block_info() + '\n'
        return out

    def filter(self, keep_columns: list):
        self.keep_columns = keep_columns
        return self

    def _ipython_display_(self):
        self.to_table()._ipython_display_()
        self._print_methods_users()

    def _print_methods_users(self):
        _resps = []
        for method in self.methods:
            for resp in method.responsible_users:
                if resp.get('fullName', None) is not None:
                    item = f'{resp["fullName"]}: <{resp.get("email", "нет почты")}>'
                    if item not in _resps:
                        _resps.append(item)

        if len(_resps) > 0:
            print(f'\n{Colors.BOLD + "Контакты валидаторов:" + Colors.ENDC}')
            for resp in _resps:
                print(f'\u0009\u00B7 {resp}')

        _contacts = []
        for method in self.methods:
            for contact in method.contacts:
                if contact.get('description', None) is not None:
                    item = f'{contact["description"]}: <{contact.get("email", "нет почты")}>'
                    if item not in _contacts:
                        _contacts.append(item)

        if len(_contacts) > 0:
            print(f'{Colors.BOLD + "Сервисные контакты:" + Colors.ENDC}')
            for contact in _contacts:
                print(f'\u0009\u00B7 {contact}')


class Column:
    """ Pre-validation method model.

    Attributes:
        role         column role
        description  column description
        required     if column required
        types         possible types list
    """

    def __init__(self, role: str, required: bool, types: list, description: str):
        self.role = role
        self.required = required
        self.types = types
        self.description = description

    def get_role(self):
        return ModelConstants.markuproles_dict.get(self.role.lower()).upper()

    def get_types(self):
        return [ModelConstants.markuptypes_dict.get(_type.lower()).upper() for _type in self.types]


class MethodExtendedModel:
    """ Pre-validation extended method model.

    Attributes:
        info        method info
        columns     method columns requirements
        settings    method settings
        draft       flag 'draft method'
    """

    def __init__(self, info: MethodModel, columns: [Column], settings: dict, draft=False):
        self.info = info
        self.columns = columns
        self.settings = settings
        self.info.draft = draft

    @property
    def method_example_url(self):
        return self.info.method_example_url

    def print_block(self) -> str:
        out = ''
        out += str(self.info) + '\n'
        out += "Требования к разметке:\n\n"
        table = []
        for column in self.columns:
            table.append([column.role, column.required, column.types, column.description])

        field_names = ['Role', 'Required', 'Types', 'Description']

        out += text_table(table, field_names)

        if self.is_settings_exist():
            out += f"\n\nДанная методика {UserContext.get().job_name.get(1)} имеет следующие настройки:\n\n"
            out += MethodExtendedModel.get_settings_table(self.settings, max_width=15)
            out += "\nИзмените этот словарь своими настройками и подставьте в переменную settings в ячейке ниже:\n\n"
            out += MethodExtendedModel.get_settings_json(self.settings)
        else:
            out += f"\n\nДанная методика {UserContext.get().job_name.get(1)} не имеет настроек.\n\n"
        example_url = self.method_example_url
        if example_url:
            out += f"\n\nПример использования методики можно посмотреть по ссылке: {example_url}\n\n"
        return out

    def _create_html(self) -> str:
        out = ''
        out += self.info.get_block_info_html()
        out += "<h3>Требования к разметке</h3>"
        if len(self.columns) > 0:
            table = []
            for column in self.columns:
                table.append([column.role, column.required, column.types, column.description])

            field_names = ['Role', 'Required', 'Types', 'Description']
            out += _render_html(SimpleTable(table, field_names))
        else:
            out += "<p>Требования к разметке отсутствуют</p>"

        out += "<h3>Настройки методики</h3>"
        out += '<p>'
        if self.is_settings_exist():
            out += f"<p>Данная методика {UserContext.get().job_name.get(1)} имеет следующие " \
                   "настройки:</p>"
            out += self.get_settings_html()
            out += "<p>Измените этот словарь своими настройками и подставьте " \
                   "в переменную settings в ячейке ниже:</p>"
            out += '<pre>' + MethodExtendedModel.get_settings_json(self.settings) + '</pre>'
        else:
            out += f"<p>Данная методика {UserContext.get().job_name.get(1)} не имеет дополнительных " \
                   "настроек, оставьте переменную settings пустой</p>"
        return out

    def add_settings_table(self, out=''):
        out += f"<h3>Настройки методики {self.info.name}</h3>"
        out += '<p>'
        if self.is_settings_exist():
            out += f"<p>Данная методика {UserContext.get().job_name.get(1)} имеет следующие " \
                   "настройки:</p>"
            out += self.get_settings_html()
        else:
            out += f"<p>Данная методика {UserContext.get().job_name.get(1)} не имеет дополнительных " \
                   "настроек, оставьте переменную settings пустой</p>"
        out += '</p>'
        return out

    @staticmethod
    def get_settings_table(settings, max_width=60) -> str:
        table, field_names = MethodExtendedModel._make_settings_table(settings)

        return text_table(table, field_names, max_width)

    def get_settings_html(self) -> str:
        table, field_names = MethodExtendedModel._make_settings_table(self.settings)

        return _render_html(SimpleTable(table, field_names))

    @staticmethod
    def get_settings_json(settings) -> str:
        out = io.StringIO()
        try:
            settings_dict = {}
            settings_errors = {}
            for key, value in settings['groups'].items():
                settings_dict[key], has_error = MethodExtendedModel.get_settings_json_value(value)
                if has_error:
                    settings_errors[key] = value

            print("settings=", end='', file=out)
            pprint.pprint(settings_dict, stream=out)

            if len(settings_errors) > 0:
                print('''\nВ выбранной методике наблюдаются проблемы и есть вероятность, что она не отработает корректно.
Рекомендуем обратиться к валидатору за изменением в методике.
Ключи настроек, где выявлены проблемы:
''', file=out)
                for key, value in settings_errors.items():
                    print(f"""ключ={key}, пример='{value["value"]}', тип={value["type"]}, формат={value["format"]}""", file=out)

            return out.getvalue()
        finally:
            out.close()

    @staticmethod
    def get_settings_json_value(value) -> any:
        _val = value['value']
        _type = value['type']
        _format = value['format']

        if _val is None:
            return None, False

        if _type == 'string' and len(_val) > 0:
            if _format is None:
                return _val, False
            if _format in ['json', 'list', 'dict']:
                # try as Python object
                try:
                    _python_val = ast.literal_eval(_val)
                    if _format in ['json', 'dict'] and not isinstance(_python_val, dict):
                        return _val, True
                    if _format in ['list'] and not isinstance(_python_val, list):
                        return _val, True
                    return _python_val, False
                except ValueError:
                    pass

                # try as json object
                try:
                    _json_value = json.loads(_val)
                    if _format in ['json', 'dict'] and not isinstance(_json_value, dict):
                        return _val, True
                    if _format in ['list'] and not isinstance(_json_value, list):
                        return _val, True
                    return _json_value, False
                except ValueError:
                    # wrong actual type (e.g. string)
                    return _val, True

        return _val, False

    @staticmethod
    def _get_valid_type(type, format):
        if type == "string":
            vt_dict = {
                "json": "str, list, set, tuple, dict",
                "list": "list, set, tuple",
                "dict": "dict"
            }
            valid_type = vt_dict.get(format, "str")

        elif type == "float":
            valid_type = "float, int"

        elif type == "integer":
            valid_type = "int"

        elif type == "boolean":
            valid_type = "bool"

        else:
            valid_type = "str"

        return valid_type

    @staticmethod
    def _make_settings_table(settings):
        table = []
        for key, value in settings['groups'].items():
            vt = MethodExtendedModel._get_valid_type(value['type'], value['format'])
            table.append([key, value['requirements'], value['description'], value['possibleValue'], value['example'],
                            value['defaultValue'], vt])

        field_names = ['Label', 'Required', 'Description', 'Possible Value', 'Example', 'Default Value', 'Valid type']

        return (table, field_names)

    def is_settings_exist(self):
        return self.settings and self.settings['groups'] and len(self.settings['groups']) > 0

    def __str__(self):
        return self.print_block()

    def _ipython_display_(self):
        from IPython.core.display import HTML
        from IPython.display import display
        display(HTML(self._create_html()))


class CustomMethodExtendedModel(MethodExtendedModel):
    """ Pre-validation extended method model for methods from list of methods in select methods.

    Attributes:
        info        method info
        columns     method columns requirements
        settings    method settings
        draft       flag 'draft method'
    """

    def _add_markup_requirements_html(self, out=''):
        out += "<h3>Требования к разметке</h3>"
        if len(self.columns) > 0:
            table = []
            for column in self.columns:
                table.append([column.role, column.required, column.types, column.description])

            field_names = ['Role', 'Required', 'Types', 'Description']
            out += _render_html(SimpleTable(table, field_names))
        else:
            out += "<p>Требования к разметке отсутствуют</p>"
        return out

    def add_settings_config(self, out=''):
        if self.is_settings_exist():
            out += "<p>Измените этот словарь своими настройками и подставьте " \
                   "в переменную settings в ячейке ниже:</p>"
            out += '<pre>' + MethodExtendedModel.get_settings_json(self.settings) + '</pre>'
        return out

    def _create_html(self) -> str:
        out = ''
        out += self.info.get_block_info_html()
        out += self._add_markup_requirements_html()
        out += self.add_settings_table()
        out += self.add_settings_config()
        return out


class MultipleMethodExtendedModel:
    """ Model that consist of MethodExtendedModel methods for output info about several method
    Attributes:
        methods     MethodExtendedModel objects with all info about methods
    """

    def __init__(self, methods: [MethodExtendedModel]):
        self.methods = methods  # MethodExtendedModels
        self.methods_info = [method.info for method in methods]  # MethodModels
        self.all_validators = {method.name: method.responsible_users for method in self.methods_info}  # Validators info
        self.settings = {}
        self.out = []

        # Additional fields for all methods, set by key to exclude duplicates
        self.translated_additional_fields = [method.info.translated_additional_fields for method in methods]
        self.all_additional_fields = self.get_union_additional_fields_keys()

        # Main characteristics for each method, we use them as main part of 1 table
        self.parameters = {
            'method_id': [[method.method_id for method in self.methods_info], None],
            'method_key': [[method.method_key for method in self.methods_info], None],
            'name': [[method.name for method in self.methods_info], None],
            'Версия': [[method.version if method.draft else None for method in self.methods_info], None],
            'Готово к активации': [[method.ready_to_activate if method.draft else None for method in self.methods_info], None],
            'description': [[shorten_description(method.description) for method in self.methods_info], False],
            'persistent volume': [[
                str(method.persistent_volume.get('pvSize', 0)) + ' GiB' if method.persistent_volume else None
                for method in self.methods_info
            ], None],
        }

        # concatenate additional part of 1 table with removing blank rows
        self.update_parameters_by_additional_fields()
        self.remove_null_parameters()

        # Collect validators and settings info
        self.get_validators_info()
        self.get_union_settings_dict()

    def get_method(self, method_id):
        for method in self.methods:
            if method_id == method.info.name:
                return method

    def get_union_additional_fields_keys(self):
        all_params = {}
        for additional_fields in self.translated_additional_fields:
            all_params.update(**additional_fields)
        return list(all_params.keys())

    def update_parameters_by_additional_fields(self):
        for field in self.all_additional_fields:
            addition_field = []
            for method in self.translated_additional_fields:
                if field in method.keys():
                    addition_field.append(method[field])
            self.parameters[field] = [addition_field, None]

    def remove_null_parameters(self):
        old_parameters = self.parameters
        new_parameters = {}
        for key in old_parameters:
            if any(self.parameters[key][0]):
                new_parameters[key] = old_parameters[key]
        self.parameters = new_parameters

    def get_validators_info(self):
        if self.all_validators and len(self.all_validators) > 0:
            validators_set = {}
            for method_name, validators in self.all_validators.items():
                for user in validators:
                    if not user.get('email', '') + user['fullName']:
                        continue
                    email = user.get('email', '')
                    val_name = user['fullName']
                    if email not in validators_set.keys():
                        validators_set[email] = {'name': val_name, 'methods': [method_name]}
                    else:
                        validators_set[email]['methods'].append(method_name)
            self.all_validators = validators_set

    def get_union_settings_dict(self):
        all_settings = {}
        for method_settings in [method.settings['groups'] for method in self.methods if method.is_settings_exist()]:
            all_settings.update(**method_settings)
        self.settings = {'groups': all_settings}

    def selected_method_info(self, out='', first_th='Name'):
        out += "<h2>Информация о выбранных методиках</h2>"
        out += '<table border="1" class="dataframe">'
        first_th = '<th>{}</th>'.format(first_th)
        main_ths = ''
        for method in self.methods_info:
            main_ths += '<th>{}</th>'.format(method.name)
        out += '<thead><tr>' + first_th + main_ths + '</tr></thead>'

        out += '<tbody>'
        for name, param in self.parameters.items():
            out = self.append_row(out, name, param[0], escape=param[1])
        out += '</tbody></table>'
        return out

    def markup_requirements(self) -> str:
        all_methods_columns = [len(method.columns) for method in self.methods]
        argmax = all_methods_columns.index(max(all_methods_columns))
        columns = self.methods[argmax].columns

        out = "<h3>Требования к разметке</h3>"
        if len(columns) > 0:
            table = []
            for column in columns:
                table.append([column.role, column.required, column.types, column.description])

            field_names = ['Role', 'Required', 'Types', 'Description']
            out += _render_html(SimpleTable(table, field_names))
        else:
            out += "<p>Требования к разметке отсутствуют</p>"
        return out

    def data_source_info(self, out=''):
        samples = self.methods_info[0].data_sources_sample
        if len(samples) > 0:
            out += f'<h3>Требования к источникам данных</h3>'
            out += '<table border="1" class="dataframe"><thead></thead>'
            out += '<thead><tr><th>Key</th><th>Required</th><th>Description</th></tr></thead>'
            out += '<tbody>'
            for sample in samples:
                out += self.row(sample.required, sample.description, header=sample)
            out += '</tbody></table>'
        return out

    def validators_info(self, out=''):
        if self.all_validators:
            out += f'<h3>Валидаторы, ответственные за методику</h3>'
            out += '<table border="1" class="dataframe"><thead></thead>'
            out += '<thead><tr><th>ФИО</th><th>Email</th><th>Method</th></tr></thead>'
            out += '<tbody>'
            for email, val_info in self.all_validators.items():
                out += self.row(val_info['name'], email, val_info['methods'])
            out += '</tbody></table>'
        return out

    def add_settings_tables(self, out=''):
        for extended_method in self.methods:
            out += extended_method.add_settings_table()
        return out

    def add_setting_config(self, out=''):
        if self.settings:
            out += "<p>Измените этот словарь своими настройками и подставьте " \
                   "в переменную settings в ячейке ниже:</p>"
            out += '<pre>' + MethodExtendedModel.get_settings_json(self.settings) + '</pre>'
        return out

    def _create_html(self, out='') -> str:
        out += self.table_start_script()
        out += self.selected_method_info()
        out += self.markup_requirements()
        out += self.data_source_info()
        out += self.validators_info()
        out += self.add_settings_tables()
        out += self.add_setting_config()

        return out

    def __str__(self) -> str:
        row = ''
        for method in self.methods:
            row += method.__str__()
        return row

    def _ipython_display_(self):
        from IPython.core.display import HTML
        from IPython.display import display
        display(HTML(self._create_html()))

    @staticmethod
    def table_start_script():
        out = """
           <script>
               function closeDetail(detailsElement) {
                   detailsElement.removeAttribute("open");
                   window.location = '#' + detailsElement.id;
               }
           </script>
           <div class='rendered_html'>
           <style scoped>
               .dataframe tbody tr th {
                   text-align: left;
               }
               .dataframe tbody tr td {
                   text-align: left;
               }
               .spoiler >  input + .box {
                   display: none;
               }
               .spoiler >  input:checked + .box {
                   display: block;
               }
           </style>
        """
        out += SUMMARY_CSS
        return out

    @staticmethod
    def row(*argv, header=None, escape=True):
        out = '<tr>'
        if header is not None:
            out += f'<th>{HtmlHelper.escape(header)}</th>'
        for cell in argv:
            if escape:
                out += f'<td>{HtmlHelper.escape(cell)}</td>'
            else:
                out += f'<td>{cell}</td>'
        out += '</tr>'
        return out

    @staticmethod
    def append_row(out, header, value, escape=True):
        if value:
            out += MultipleMethodExtendedModel.row(*value, header=header, escape=escape)
        return out
