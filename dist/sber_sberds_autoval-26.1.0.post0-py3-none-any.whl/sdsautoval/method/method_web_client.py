import json

from ..base_requester import BaseRequester, common_http_retry_condition
from ..utils.retry import withretry


class IMethodWebClient:
    def get_methods(self, project_area_type: str = None):
        """
        Get methods (GET /api/methods)

        :return: methods list
        """
        pass

    def get_draft_methods(self, project_area_type: str = None):
        """
        Get draft methods (GET /api/methods/draft)

        :return: methods list
        """
        pass

    def get_method_info(self, method_id):
        """
        Get method info (GET /api/methods/{method_id})

        :param method_id method id
        :return: method extended info
        """
        pass

    def get_draft_method_info(self, method_id):
        """
        Get draft method info (GET /api/methods/{method_id}/draft)

        :param method_id method id
        :return: method extended info
        """
        pass

    def get_dicts(self):

        """
        Get method dictionaries (GET /api/methods/dicts)

        :return: method extended info
        """
        pass

    def get_avm_links(self, avm_user_method_ids: list, status: str, team: str):
        """
        Get draft methods (GET /api/methods/find-by-avm)

        :return: methods list
        """
    pass


class MethodWebClient(IMethodWebClient):
    _SERVICE_PATH = 'template-selector'
    _END_POINT = '/api/methods'

    def __init__(self, host, session, token, is_internal=False):
        self._requester = BaseRequester(host, session, service_name=self.__class__._SERVICE_PATH)
        self._is_internal = is_internal
        self._token = token

    @withretry(retry_condition=common_http_retry_condition)
    def get_methods(self, project_area_type: str = None):
        response = self._requester.request(
            method='post',
            endpoint=f'{self._base_path()}/find?projectAreaType={project_area_type}',
            headers=self._headers(self._token),
        )

        return response.json()

    @withretry(retry_condition=common_http_retry_condition)
    def get_draft_methods(self, project_area_type: str = None):
        response = self._requester.request(
            method='post',
            endpoint=f'{self._base_path()}/find/draft?projectAreaType={project_area_type}',
            headers=self._headers(self._token),
        )

        return response.json()

    @withretry(retry_condition=common_http_retry_condition)
    def get_method_info(self, method_id):
        response = self._requester.request(
            method='get',
            endpoint=f"{self._base_path()}/{method_id}",
            headers=self._headers(self._token)
        )

        return response.json()

    @withretry(retry_condition=common_http_retry_condition)
    def get_draft_method_info(self, method_id):
        response = self._requester.request(
            method='get',
            endpoint=f"{self._base_path()}/{method_id}/draft",
            headers=self._headers(self._token)
        )

        return response.json()

    @withretry()
    def get_dicts(self):
        response = self._requester.request(
            method='get',
            endpoint=f"{self._base_path()}/dicts",
            headers=self._headers(self._token)
        )

        return response.json()

    @withretry()
    def get_avm_links(self, avm_user_method_ids: list, status: str, team: str):
        data = json.dumps({
            'avmUserMethodIds': avm_user_method_ids,
            'status': status,
            'team': team
        })

        response = self._requester.request(
            method='post',
            endpoint=f'{self._base_path()}/find-by-avm',
            headers=self._headers(self._token),
            data=data
        )

        return response.json()


    def _base_path(self):
        return self._SERVICE_PATH + self._END_POINT if not self._is_internal else self._END_POINT

    @staticmethod
    def _headers(token):
        return {
            'Accept': 'application/json',
            'Authorization': f'Bearer {token}',
            'Content-Type': 'application/json'
        }
