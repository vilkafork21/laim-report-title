from .method_models import MethodModel, MethodExtendedModel, Column, MethodList, DataSourceModel, DictionaryMapper
from .method_web_client import MethodWebClient

from ..util import print_table
from ..utils.misc import get_service_contacts, get_responsible_users


class MethodService:
    def __init__(self, host, session, token, is_internal=False):
        self._host = host
        self._session = session
        self._token = token
        self._client = MethodWebClient(host, session, token, is_internal)
        self.dicts = None

    def update_dicts(self):
        if self.dicts is None or len(self.dicts) <= 0:
            dicts_response = self._client.get_dicts()
            dicts = {}
            for raw_dict in dicts_response:
                new_dict = {}
                for item in raw_dict['items']:
                    new_dict[item['key']] = item['value']
                dicts[raw_dict['id']] = new_dict
            self.dicts = DictionaryMapper(dicts)

    def get_methods(self, project_area_type: str = None) -> MethodList:
        self.update_dicts()
        response = self._client.get_methods(project_area_type=project_area_type)
        methods = self.convert_methods_response(response, to_dict=False)
        return MethodList(methods)

    def get_draft_methods(self, project_area_type: str = None) -> MethodList:
        self.update_dicts()
        response = self._client.get_draft_methods(project_area_type=project_area_type)
        methods = self.convert_methods_response(response, to_dict=False)
        return MethodList(methods)

    def convert_methods_response(self, response, to_dict=False):
        methods = []
        for method in response:
            method_model = self.construct_method_model(method)
            if to_dict:
                methods.append(method_model.__dict__)
            else:
                methods.append(method_model)
        return methods

    def construct_method_model(self, method):
        sources = DataSourceModel.from_list([x for x in method['dataSource']])
        self.update_dicts()
        _ready_to_activate = method.get('readyToActivate', False)
        method_model = MethodModel(self.dicts,
                                   method['methodId'],
                                   method['userMethodId'],
                                   method['methodName'],
                                   method['methodDescription'],
                                   method.get('dataType', None),
                                   method.get('taskType', None),
                                   method.get('metricsName', None),
                                   method.get('cdsBlock', None),
                                   get_responsible_users(method),
                                   get_service_contacts(method),
                                   str(method.get('majorVersion', 0)) + '.' + str(method.get('minorVersion', 1)),
                                   'Да' if _ready_to_activate else 'Нет',
                                   sources,
                                   method.get('additionalFields', []),
                                   persistent_volume=method.get('persistentVolume', None))
        return method_model

    # noinspection PyMethodMayBeStatic
    def print_methods_response(self, methods):
        print("Список методик с требованиями к разметке\n")
        table = []
        for method in methods:
            table.append([method.method_key, method.get_block_info()])

        field_names = ['method_key', 'method_info']
        print_table(table, field_names)

    def get_method_info(self, method_id) -> MethodExtendedModel:
        response = self._client.get_method_info(method_id)
        return self._convert_to_method(response)

    def get_draft_method_info(self, method_id) -> MethodExtendedModel:
        response = self._client.get_draft_method_info(method_id)
        return self._convert_to_method(response, True)

    def _convert_to_method(self, response, draft=False):
        r_info = response['info']
        info = self.construct_method_model(r_info)
        columns = []
        for column in response['columns']:
            if column is not None:
                columns.append(
                    Column(column['role'], column['required'], column['type'], column['description']))
        settings = response.get('settings', {})
        return MethodExtendedModel(info, columns, settings, draft)

    def get_avm_links(self, avm_user_method_ids, status, team):
        return self._client.get_avm_links(avm_user_method_ids, status, team)
