import abc


class TableView:
    @abc.abstractmethod
    def to_table(self):
        pass

    def to_dataframe(self):
        self.to_table().to_dataframe()

    def _ipython_display_(self):
        self.to_table().ipython_display()

    def _repr_pretty_(self, p, cycle):
        self._ipython_display_()

    def __str__(self):
        return self.to_table().to_print_table().print_table()
