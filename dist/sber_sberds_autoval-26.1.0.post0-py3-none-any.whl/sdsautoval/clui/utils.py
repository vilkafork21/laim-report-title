import sys


def is_in_jupyter():
    """
    Проверить, что функция display есть в окружении.
    """
    try:
        from IPython import get_ipython
        if 'IPKernelApp' not in get_ipython().config:  # pragma: no cover
            return False
    except ImportError:
        return False
    except AttributeError:
        return False
    return True


def is_terminal_emulated():
    return is_in_jupyter() or sys.stdout.isatty()
