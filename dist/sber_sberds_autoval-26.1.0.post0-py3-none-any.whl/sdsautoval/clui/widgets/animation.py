import time


class Animation:
    def __init__(self, fps=10, frames=None):
        self._frame = 0
        if frames is None:
            frames = [
                '[   ]',
                '[.  ]',
                '[.. ]',
                '[...]',
                '[:..]',
                '[::.]',
                '[:::]',
                '[.::]',
                '[..:]',
                '[...]',
                '[ ..]',
                '[  .]',
            ]
        self._frames = frames
        self._fps = fps
        self._min_delta_time = 1 / self._fps
        self._last_frame_time = 0

    def next_frame(self):
        s = self.current_frame()
        self._frame += 1
        if self._frame >= len(self._frames):
            self._frame = 0
        return s

    def current_frame(self):
        return self._frames[self._frame]

    def frame(self):
        current_time = time.time()
        delta_time = current_time - self._last_frame_time
        if delta_time > self._min_delta_time:
            self._last_frame_time = current_time
            return self.next_frame()
        else:
            return self.current_frame()
