import datetime
import time
from concurrent.futures import ALL_COMPLETED, ThreadPoolExecutor, wait

import math

from sdsautoval.clui.widgets.animation import Animation
from sdsautoval.clui.utils import is_terminal_emulated


class ProgressWidget:

    def __init__(self, prefix: str = '', min_step=None,
                 overwrite=is_terminal_emulated(),
                 sync=False):
        if not min_step:
            if is_terminal_emulated():
                min_step = 0
            else:
                min_step = 0.1
        self.prefix = prefix
        self.started = time.time()
        self.previous_fraction = 0.0
        self.min_step = min_step
        self.overwrite = overwrite
        if self.overwrite:
            self.end_for_print = '\r'
        else:
            self.end_for_print = ''
        self.end_for_last_print = '\n\n'
        self.last_line_len = 0
        self._should_print_initial_remaining = True
        self.animation = Animation()
        self.current_fraction = 0
        self.sync = sync
        if not overwrite:
            self.sync = True
        self.ended = False
        self.executor = None
        self.future = None

    def start(self):
        self.started = time.time()
        last_line = self.start_text()
        print(last_line, end=self.end_for_print, flush=True)
        self.last_line_len = len(last_line)
        self._should_print_initial_remaining = True
        if not self.sync:
            self.executor = ThreadPoolExecutor(max_workers=1,
                                               thread_name_prefix='ProgressLogger')
            self.future = self.executor.submit(self._display_thread)

    def update(self, completed=None, total=None):
        if completed and total:
            self.current_fraction = (completed / total)
        else:
            self.current_fraction = 0
        if self.sync:
            self._display(self.current_fraction)

    def end(self):
        last_line = self.end_text()
        self._clear_line()
        print(last_line, end=self.end_for_last_print, flush=True)
        self.last_line_len = len(last_line)
        self._terminate()

    def start_text(self):
        return self.prefix + ' '

    def end_text(self):
        delta = datetime.timedelta(seconds=time.time() - self.started)
        delta_str = str(
            delta - datetime.timedelta(microseconds=delta.microseconds))
        text = ': завершено за ' + delta_str
        if self.overwrite:
            text = '\n' + self.prefix + text
        return text

    def update_text(self, current_fraction=None):
        if self.overwrite:
            return self.prefix + ' ' + self.animation.frame()
        else:
            return '.'

    def error(self, error: Exception = None):
        error_msg = ""
        if error:
            error_msg = str(error)
        print(self.error_text(error_msg),
              end=self.end_for_last_print, flush=True)
        self._terminate()

    def error_text(self, error_msg):
        if self.overwrite:
            return "\n" + self.prefix + ": произошла ошибка: " + error_msg
        else:
            return " произошла ошибка: " + error_msg

    def _display_thread(self):
        while not self.ended:
            self._display(self.current_fraction)
            time.sleep(0.2)

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type:
            self.error(exc_val)
        else:
            self.end()

    def _display(self, current_fraction):
        if self.should_redraw(current_fraction):
            self._should_print_initial_remaining = False
            last_line = self.update_text(current_fraction)
            self._clear_line()
            print(last_line, end=self.end_for_print, flush=True)
            self.previous_fraction = current_fraction
            self.last_line_len = len(last_line)

    def should_redraw(self, current_fraction):
        return True

    def _terminate(self):
        self.ended = True
        if not self.sync:
            if self.executor:
                if self.future:
                    wait([self.future], return_when=ALL_COMPLETED)

    def _clear_line(self):
        if self.overwrite:
            print(' ' * self.last_line_len + '\r', end='', flush=False)


class ProgressPercentWidget(ProgressWidget):

    def __init__(self, prefix: str = '', min_step=None,
                 overwrite=is_terminal_emulated(),
                 sync=False):
        super().__init__(prefix, min_step, overwrite, sync)
        if self.overwrite:
            self.end_for_print = '\r'
        else:
            self.end_for_print = '\n'

    def start_text(self):
        return self.prefix + ' 0%'

    def update_text(self, current_fraction=None):
        if current_fraction is None:
            return super().update_text(current_fraction)
        prev_fraction = current_fraction
        current_time = time.time()
        delta_seconds = current_time - self.started
        remaining = (delta_seconds / current_fraction) - delta_seconds
        delta = datetime.timedelta(seconds=remaining + 1)
        delta_str = str(
            delta - datetime.timedelta(microseconds=delta.microseconds))
        text = self.prefix + ' ' + \
               self.percent_text(prev_fraction) + \
               ': осталось примерно ' + \
               delta_str + self.animation_frame()
        return text

    def percent_text(self, fraction):
        return '[' + str(math.floor(fraction * 100)) + '%' + ']'

    def animation_frame(self):
        if self.overwrite:
            return ' ' + self.animation.frame()
        return ''

    def end_text(self):
        delta = datetime.timedelta(seconds=time.time() - self.started)
        delta_str = str(
            delta - datetime.timedelta(microseconds=delta.microseconds))
        text = self.prefix + ': завершено за ' + delta_str
        if self.overwrite:
            text = '\n' + text
        return text

    def error_text(self, error_msg):
        return "\n" + self.prefix + ": произошла ошибка: " + error_msg

    def should_redraw(self, current_fraction):
        return current_fraction is None or \
               current_fraction > 0 and \
               (current_fraction - self.previous_fraction >= self.min_step or
                self._should_print_initial_remaining)


class ProgressBarWidget(ProgressPercentWidget):
    def __init__(self, prefix: str = '',
                 segments=10,
                 show_percentage=False,
                 full_segment: str = '█',
                 empty_segment: str = '_',
                 min_step=None,
                 overwrite=is_terminal_emulated(),
                 sync=False):
        super().__init__(prefix, min_step, overwrite, sync)
        self.segments = segments
        self.full_segment = full_segment
        self.empty_segment = empty_segment
        self.show_percentage = show_percentage

    def start_text(self):
        return self.prefix

    def percent_text(self, fraction):
        bar = ''
        filled_segments = self.segments * fraction
        for i in range(self.segments):
            if i <= filled_segments:
                bar += self.full_segment
            else:
                bar += self.empty_segment
        if self.show_percentage:
            bar = super().percent_text(fraction) + ' ' + bar
        return bar
