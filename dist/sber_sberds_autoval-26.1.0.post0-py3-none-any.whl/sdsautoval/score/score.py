from sdsautoval.utils.addict import addict_snake
from sdsautoval.utils.dto import EazyDto


class Score(EazyDto):
    def __repr__(self):
        return f"Score(score_alias='{self.score_alias}', score_id='{self.score_id}', model_version={self.model_version_id})"
    def __str__(self):
        return self.__repr__()
    def __init__(self, score_alias: str, score_id: str, model_version_id: int):
        super().__init__({
            "score_alias": score_alias,
            "score_id": score_id,
            "model_version_id": model_version_id
        })

    def validate(self):
        """Проверяет, что все поля заполнены."""
        if not self.score_alias:
            raise ValueError(f"Параметр score_alias не заполнен для score_id='{self.score_id}', model_version_id={self.model_version_id}")
        if not self.score_id:
            raise ValueError(f"Параметр score_id не заполнен для score_alias='{self.score_alias}', model_version_id={self.model_version_id}")
        if not self.model_version_id:
            raise ValueError(f"Параметр model_version_id не заполнен для score_alias='{self.score_alias}', score_id='{self.score_id}'")

    def to_dict_camel(self):
        return {
            "scoreAlias": self.score_alias,
            "scoreId": self.score_id,
            "modelVersionId": self.model_version_id
        }

    @staticmethod
    def from_dict(score: dict):
        score = addict_snake(score)
        result = Score(score.get('score_alias', None), score.get('score_id', None), score.get('model_version_id', None))
        return result


class Scores:
    def __init__(self):
        self._scores = []

    def add(self, score_alias: str = None, score_id: str = None, model_version_id: int = None):
        """Добавляет score в список. Проверяет обязательные поля."""
        score = Score(score_alias, score_id, model_version_id)
        # score.validate()
        self._scores.append(score)

    def validate(self):
        for score in self._scores:
            score.validate()

    @staticmethod
    def from_dict(scores: dict):
        scores = addict_snake(scores)
        key = 'short_list_scores'
        if key in scores:
            return Scores.from_list(scores[key])
        raise ValueError(f"В словаре scores нет ключа '{key}'")

    @staticmethod
    def from_list(scores: list):
        result = Scores()
        for item in scores:
            if isinstance(item, dict):
                score = Score.from_dict(item)
                result.add(score.score_alias, score.score_id, score.model_version_id)
            elif isinstance(item, Score):
                result.add(item.score_alias, item.score_id, item.model_version_id)
            else:
                raise ValueError(f"Элемент списка scores должен быть словарем или объектом Score, а не {type(item)}")
        return result

    def to_dict_camel(self) -> dict:
        """Преобразует список scores в словарь для передачи в API."""
        return {
            "shortListScores": [
                s.to_dict_camel() for s in self._scores
            ]
        }

    @classmethod
    def sanitize(cls, scores):
        if isinstance(scores, dict):
            scores = Scores.from_dict(scores)
        elif isinstance(scores, list):
            scores = Scores.from_list(scores)
        return scores
