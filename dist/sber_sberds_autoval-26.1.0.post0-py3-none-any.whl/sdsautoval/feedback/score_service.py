from sdsautoval.feedback.score_model import ScoreModel
from sdsautoval.feedback.score_web_client import ScoreWebClient
from sdsautoval.jwt_util import parse_jwt


class ScoreService:
    def __init__(self, host, session, token):
        self._host = host
        self._session = session
        self._token = token
        self._parsed_token = parse_jwt(token)
        self._client = ScoreWebClient(host, session, token)

    def send_score(self, score, feedback_type, prevalidation_id, method_id):
        if score < 1:
            print('Оценка не может быть меньше 1. Исправьте значение и повторите снова.')
            return
        if score > 5:
            print('Оценка не может быть больше 5. Исправьте значение и повторите снова.')
            return

        self._client.create(ScoreModel(score=score, feedback_type=feedback_type, prevalidation_id=prevalidation_id,
                                       method_id=method_id))

