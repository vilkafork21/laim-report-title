from ..error_util import format_error
from ..prevalidation.prevalidation_converter import PreValidationConverter
from sdsautoval.context.user_context import UserContext
from ..colors import Colors


class FeedbackModel:
    """ Issue feedback model.

    Attributes:
        login        user login
        email        user email
        fio          user FIO
        url          url of host or project
        description  issue description
        subject      issue classificator
        context      current working context
    """

    def __init__(self, login, email, fio, description, subject, url):
        self.login = login
        self.email = email
        self.fio = fio
        self.description = description
        self.subject = subject
        self.url = url

    def convert(self) -> dict:
        return {
            "login": self.login,
            "email": self.email,
            "fio": self.fio,
            "url": self.url,
            "description": self.create_description()
        }

    def get_user_description(self):
        text = f'Subject: {self.subject}\n'
        text += f'{self.description}\n'
        return text

    def create_description(self):
        text = f'Subject: {self.subject}\n\n'
        text += f'{self.description}\n\n'
        text += '--------------------\n'
        text += 'User context\n'
        text += 'Внимание! Контекст заполняется автоматически и может быть не связан с обращением пользователя!!!\n\n'

        text += f'SDK Version: {UserContext.get().version}\n'
        text += f'Selected Method ID: {UserContext.get().current_method}\n\n'

        text += f'Last Run Result:\n'
        last_run = UserContext.get().last_run
        if last_run:
            text += f'Timestamp: {last_run.timestamp}\n'
            text += f'PreValidation ID: {last_run.prevalidation_id}\n'
            text += f'Model Version ID: {last_run.model_version_id}\n'
            text += f'Samples: {list(map(PreValidationConverter.convert_data_sample, last_run.samples))}\n'
            text += f'Settings: {last_run.settings}\n'
            text += f'Resources: {last_run.resources}\n\n'
        else:
            text += f'None\n\n'

        text += f'Last Error:\n'
        last_error = UserContext.get().last_error
        if last_error:
            text += f'Timestamp: {last_error.timestamp}\n'
            text += f'Header: {last_error.header}\n'
            text += f'Message: {last_error.message}\n'
            text += f'Solution advice: {last_error.advice}'
        else:
            text += f'None'

        return text
