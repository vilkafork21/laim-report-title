import json

from .score_model import ScoreModel
from ..base_requester import BaseRequester


class IScoreWebClient:
    def create(self, model: ScoreModel) -> str:
        """
        Create score feedback and send it to template-selector

        :param model: Score model
        :return: issue_id
        """
        pass


class ScoreWebClient(IScoreWebClient):
    _SERVICE_PATH = 'template-selector'
    _END_POINT = '/api/feedback'
    _SCORE_END_POINT = _SERVICE_PATH + _END_POINT

    def __init__(self, host, session, token):
        self._requester = BaseRequester(host, session, service_name=self.__class__._SERVICE_PATH)
        self._token = token

    def create(self, model: ScoreModel):
        end_point = f"{self._SCORE_END_POINT}"

        response = self._requester.request(
            method='post',
            endpoint=end_point,
            headers=self._headers(self._token),
            data=json.dumps(model.to_dict())
        )
        if response and response.is_ok() and response.text:
            return response.json()['id']
        else:
            return None

    @staticmethod
    def _headers(token):
        return {
            'Accept': 'application/json',
            'Authorization': f'Bearer {token}',
            'Content-Type': 'application/json'
        }
