from ..prevalidation.prevalidation_converter import PreValidationConverter
from sdsautoval.context.user_context import UserContext


class ScoreModel:

    def __init__(self,
                 score=None,
                 feedback_type=None,
                 prevalidation_id=None,
                 method_id=None
                 ):
        self.feedback_type = feedback_type
        self.score = score
        self.prevalidation_id = prevalidation_id
        self.method_id = method_id

    def to_dict(self) -> dict:
        return {
            'type': self.feedback_type,
            'score': self.score,
            'method_id': self.method_id,
            'prevalidation_id': self.prevalidation_id
        }
