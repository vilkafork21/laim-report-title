import json

from .feedback_model import FeedbackModel
from ..base_requester import BaseRequester


class IFeedbackWebClient:
    def create(self, model: FeedbackModel) -> str:
        """
        Create issue and send it to feedback-service

        :param model: feedback model
        :return: issue_id
        """
        pass


class FeedbackWebClient(IFeedbackWebClient):
    _SERVICE_PATH = 'user-feedback-service'
    _END_POINT = '/api/issues'
    _FEEDBACK_END_POINT = _SERVICE_PATH + _END_POINT

    def __init__(self, host, session, token):
        self._requester = BaseRequester(host, session, service_name=self.__class__._SERVICE_PATH)
        self._token = token

    def create(self, model: dict):
        end_point = f"{self._FEEDBACK_END_POINT}"

        response = self._requester.request(
            method='post',
            endpoint=end_point,
            headers=self._headers(self._token),
            files={
                'issueDto': (None, json.dumps(model), 'application/json')
            }
        )
        return response

    @staticmethod
    def _headers(token):
        return {
            'Authorization': f'Bearer {token}',
        }
