from .feedback_model import FeedbackModel
from .feedback_web_client import FeedbackWebClient
from sdsautoval.context.constants import SBERDS_MAIL
from ..exceptions.exceptions import ConnResetError, TimeOutError
from ..exceptions.sds_exceptions import SdsFeedbackError, SdsNotAuthorizedError
from ..jwt_util import parse_jwt
from ..modprop import ModelConstants


class FeedbackService:
    def __init__(self, host, session, token):
        self._host = host
        self._session = session
        self._token = token
        self._parsed_token = parse_jwt(token)
        self._client = FeedbackWebClient(host, session, token)

    def send_feedback(self, url: str, description: str, subject: str) -> None:
        if self._parsed_token.email is None or not self._parsed_token.email:
            raise SdsFeedbackError('Нет почтового адреса.', 'Проверьте, заполнен ли ваш почтовый адрес')
        if description is None or not description:
            raise SdsFeedbackError('Не заполнен параметр description.', 'Заполните параметр description')
        if subject is None or not subject:
            raise SdsFeedbackError('Не заполнен параметр subject.', 'Заполните параметр subject')
        if subject not in ModelConstants.fb_subjects:
            raise SdsFeedbackError(f"Параметр subject должен быть из списка {ModelConstants.fb_subjects}",
                                   'Заполните параметр subject одним из списка')

        model = FeedbackModel(self._parsed_token.login, self._parsed_token.email, self._parsed_token.fio,
                              description, subject, url)
        converted_model = model.convert()

        try:
            issue_id = self._client.create(converted_model).text
            print(f'Ваше обращение зарегистрировано под номером ID {issue_id}')
            print(f'Текст обращения:\n{model.get_user_description()}')
            print('\nКонсультант технической поддержки свяжется с вами в течение рабочего дня.')
            print(f'Если этого не произойдет, пожалуйста, напишите в тех.поддержку {SBERDS_MAIL}, указав ID вашего обращения.')
        except SdsNotAuthorizedError as err:
            raise err
        except (TimeOutError, ConnResetError) as _:
            raise SdsFeedbackError('Сервис не отвечает. Возможно ведутся технические работы.',
                                   f'Попробуйте немного позже или напишите в тех.поддержку {SBERDS_MAIL}, указав ID автовалидации.')
        except Exception:
            raise SdsFeedbackError('Ошибка при отправке обращения.',
                                   f'Попробуйте немного позже или напишите в тех.поддержку {SBERDS_MAIL}, указав ID автовалидации.')

