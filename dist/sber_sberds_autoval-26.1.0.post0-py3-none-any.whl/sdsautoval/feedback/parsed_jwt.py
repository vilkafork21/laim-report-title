class ParsedJwt:
    """ Parsed JWT token, contains user data.

     Attributes:
        login        user login
        email        user email
        fio          user FIO
    """

    def __init__(self, login, email, fio, zone):
        self.login = login
        self.email = email
        self.fio = fio
        self.zone = zone
