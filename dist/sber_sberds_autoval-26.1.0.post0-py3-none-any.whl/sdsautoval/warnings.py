from datetime import datetime

from sdsautoval.colors import Colors
from sdsautoval.utils.date_time import utc_to_local, pretty_date
from sdsautoval.utils.misc import pre_validation_status_order


def null_status_crutch(status) -> str:  # TODO: Костыль для отсутствия статуса, удалить после фикса на бэке
    if status is None or len(status) == 0:
        return 'DATA_VERIFIED'
    else:
        return status


def warning_date(d):
    if d is None:
        return None
    return utc_to_local(datetime.strptime(d, '%Y-%m-%dT%H:%M:%S.%fZ'))


class SdsWarningOrder:
    def __init__(self, warning):
        warning = SdsWarning.convert(warning)
        self.pre_validation_status = warning.pre_validation_status
        self.create_date = warning.create_date
        self.pre_validation_status_order = pre_validation_status_order(self.pre_validation_status)

    @staticmethod
    def check_compatibility(other):
        if not isinstance(other, SdsWarningOrder):
            raise ValueError('Expected value of type SdsWarningOrder, got  ' + str(type(other)))

    def __hash__(self):
        return hash((
            self.pre_validation_status,
            self.create_date,
            self.pre_validation_status_order,
        ))

    def __eq__(self, other):  # ==
        SdsWarningOrder.check_compatibility(other)
        return \
                self.pre_validation_status == other.pre_validation_status and \
                self.create_date == other.create_date

    def __ne__(self, other):  # !=
        return not self.__eq__(other)

    def __gt__(self, other):  # >
        SdsWarningOrder.check_compatibility(other)
        return \
                self.pre_validation_status_order >= other.pre_validation_status_order \
                and self.create_date > other.create_date

    def __lt__(self, other):  # <
        SdsWarningOrder.check_compatibility(other)
        return \
                self.pre_validation_status_order <= other.pre_validation_status_order \
                and self.create_date < other.create_date

    def __ge__(self, other):  # >=
        return self.__gt__(other) or self.__eq__(other)

    def __le__(self, other):  # <=
        return self.__lt__(other) or self.__eq__(other)


class SdsWarning:
    def __init__(self, warning):
        if isinstance(warning, SdsWarning):
            self.raw = warning.raw
        elif isinstance(warning, dict):
            self.raw = warning
        else:
            raise ValueError('Expected value of type SdsWarning or dict, got ' + str(type(warning)))
        self.pre_validation_status = null_status_crutch(self.get('preValidationStatus', default=''))
        self.message = self.get('message', default='')
        self.raw_create_date = self.get('createDate')
        self.create_date = warning_date(self.raw_create_date)
        self.order = SdsWarningOrder(self)

    def __repr__(self):
        return self.pretty_str()

    def pretty_str(self):
        return f"{pretty_date(self.create_date)} {Colors.WARNING}Обратите внимание{Colors.ENDC} - {self.message}"

    def __str__(self):
        return self.__repr__()

    @staticmethod
    def check_compatibility(other):
        if not isinstance(other, SdsWarning):
            raise ValueError('Expected value of type SdsWarning, got  ' + str(type(other)))

    def __eq__(self, other):  # ==
        SdsWarning.check_compatibility(other)
        return \
                self.pre_validation_status == other.pre_validation_status and \
                self.message == other.message and \
                self.raw_create_date == other.raw_create_date and \
                self.create_date == other.create_date and \
                self.order == other.order

    def __ne__(self, other):  # !=
        return not self.__eq__(other)

    def __hash__(self):
        return hash((
            self.pre_validation_status,
            self.message,
            self.raw_create_date,
            self.create_date,
            self.order
        ))

    def get(self, key, default=None):
        if self.raw:
            if default:
                return self.raw.get(key, default)
            else:
                if key in self.raw.keys():
                    value = self.raw.get(key)
                    if value:
                        return value
                    else:
                        return default
                else:
                    return default
        else:
            return default

    @staticmethod
    def convert(warning):
        """
        Converts dictionary to SdsWarning object.
        :rtype: SdsWarning
        """
        if warning is None:
            return None
        if isinstance(warning, SdsWarning):
            return warning
        else:
            return SdsWarning(warning)

    @staticmethod
    def convert_list(warnings: list) -> list:
        """
        Converts list of dictionaries to list of SdsWarnings if needed.
        :rtype: list
        """
        if warnings is None:
            return list()
        result = list()
        for item in warnings:
            result.append(SdsWarning.convert(item))
        return result
