from sdsautoval.context.user_context import UserContext
from .exceptions.exception_decorator import exception_logger, keyboard_interrupt_handler, return_self
from .exceptions.sds_exceptions import SdsExceptionLogPrinter
from .prevalidation.prevalidation_converter import PreValidationConverter
from .prevalidation.prevalidation_run import PreValidationRun
from sdsautoval.session.session_interface import SessionInterface
from .util import SimpleTable
from .utils import keyboard_interrupt_handlers as ki_handlers
from .utils.conjugating_word import ConjugatingWord, SimpleConjugatingWord

REFIT_WORD = SimpleConjugatingWord({
    # именительный
    0: ['дообучение', 'дообучения'],
    # родительный
    1: ['дообучения', 'дообучений'],
    # дательный
    2: ['дообучению', 'дообучениям'],
    # винительный
    3: ['дообучение', 'дообучения'],
    # творительный
    4: ['дообучением', 'дообучениями'],
    # предложный
    5: ['о дообучении', 'о дообучениях'],
})


class AutoRefit(SessionInterface):
    def __init__(self):
        super().__init__()
        self.project_area_type = 'refit'
        UserContext.get().job_name = self.get_job_name()
        self.method_columns = None

    def get_job_name(self) -> ConjugatingWord:
        return REFIT_WORD

    def default_object_name(self):
        return "refit"

    def prevalidation_id_name(self):
        return 'refit_id'

    def get_prevalidations_name(self):
        return 'get_refits()'

    def run(self, params: list):
        """ Валидация параметров и запуск дообучения.

        Parameters
        ----------
            params: dict

        Returns
        -------
        функция сохраняет параметры в объекте AutoRefit и создает запрос на проведение дообучения или группы
        возвращает идентификатор run_id

        Examples
        --------

        auto_refit.run(
            params=params,
        )
        """
        return self.run_refits(params)

    @return_self()
    @exception_logger(logger=SdsExceptionLogPrinter())
    @keyboard_interrupt_handler(ki_handler=ki_handlers.session_interface_run_job)
    def run_refits(self, params: list):
        """ Валидация параметров и запуск дообучения.

        Parameters
        ----------
            params: dict

        Returns
        -------
        функция сохраняет параметры в объекте AutoRefit и создает запрос на проведение дообучения или группы
        возвращает идентификатор run_id

        Examples
        --------

        auto_refit.run_refits(
            params=params,
        )
        """
        self._ensure_can_validate()

        request = []
        for param in params:
            model_version_id = param.get('model_version_id', 0)
            data = param.get('data', [])
            settings = param.get('settings', {})
            resources = param.get('resources', None)
            trigger_node_id = param.get('trigger_node_id', None)
            project_id = param.get('project_id', None)
            disable_pv = param.get('disable_pv', False)
            cpu_only = param.get('cpu_only', False)
            request.append(PreValidationConverter.convert_to_transport(model_version_id, None,
                                                                       data, settings, False,
                                                                       resources, False,
                                                                       trigger_node_id, project_id, cpu_only, disable_pv,
                                                                       'refit'))

        self._prevalidation_run = PreValidationRun(self._get_client(), self._host, request, self._zone)
        self._prevalidation_run.create_refits()
        self._content_keeper.update(run=self._prevalidation_run)


    @exception_logger(logger=SdsExceptionLogPrinter())
    def stop(self, refit_id=None, run_id=None, trigger_node_id=None, only_current=False):
        """Остановить процесс выполнения проекта или группы проектов

          Parameters
          ----------
          refit_id : str
              идентификатор запущенного дообучения
          run_id : str
              идентификатор группы запуска
          trigger_node_id : str
              идентификатор триггерной ноды запуска
          only_current : bool
              остановить только запущенный проект

          Returns
          -------
              функция возвращает результат остановки

          Examples
          --------
          auto_refit.stop(refit_id='65e92db8-7cd4-4cf4-95fa-adc00e61d6b1')
        """
        super().stop(refit_id, run_id, trigger_node_id, only_current=only_current)

    @exception_logger(logger=SdsExceptionLogPrinter())
    def resume(self, refit_id=None, run_id=None, trigger_node_id=None, resources=None, cpu_only=False,
               only_current=False):
        """
        Дозапустить процесс дообучения или группы.
        Актуально, если дообучение завершилось с ошибкой или стоит на паузе.

        Parameters
        ----------
        refit_id : str
            Идентификатор дообучения
        run_id : str
            Идентификатор запуска
        trigger_node_id : str
            Идентификатор триггерной ноды
        resources: str
            Ресурсы для дозапуска узлов дообучения.
            Допустимые значения: строки вида "{N}gb{M}cpu".format(N=N, M=M), где
                N - целое число от 1 до 512, M - целое число, от 1 до 16
            Пример: 32gb8cpu или 128gb2cpu

            Если нужно указать требования только к одному из параметров ресурсов (RAM или CPU), то можно задавать
                каждый из них по отдельности
            Пример: 32gb для RAM или 2cpu для CPU

            При выборе ресурсов, где число CPU > 3 или объем RAM > 7GB, запуск вычислений будет производиться
                в экспериментальном режиме на отдельном кластере, например, могут не показываться логи в realtime
            В случае проблем и непонятных ошибок напишите, пожалуйста, нам через метод auto_validator.create_issue
                или на почту mailto:AutoValidation@sberbank.ru, mailto:sberds@omega.sbrf.ru
        cpu_only: bool
            Дозапустить только на CPU
        only_current: bool
            Дозапустить только текущее дообучение, не запуская дочерние.

        Returns
        -------
            функция возвращает результат дозапуска дообучения

        Examples
        --------
        auto_refit.resume(refit_id='65e92db8-7cd4-4cf4-95fa-adc00e61d6b1', resources='16gb2cpu')
        """
        super()._resume_job(refit_id, run_id, trigger_node_id, resources, cpu_only=cpu_only, only_current=only_current)

    @exception_logger(logger=SdsExceptionLogPrinter())
    def get_refits(self, model_version_id=None, status=None, date_to=None, date_from=None, limit=200) -> SimpleTable:
        """ Показать основную информацию по дообучениям, запущенным
            пользователем (проверка пользователя по login), сортировка по дате
            создания от последней созданной к более ранней


        Parameters
        ----------

        model_version_id : str, list, опциональный параметр
            идентификатор из БМ или список идентификаторов
        status : str, list, опциональный параметр
            статус процесса дообучения
            доступные варианты: RUNNING, DONE, ERROR, PAUSED
        date_to : str, datetime-like, в формате "YYYY-MM-DD", опциональный параметр
            дата для фильтрации выборки, дата после которой автовалидации не попадут в выборку
        date_from : str, datetime-like, в формате "YYYY-MM-DD", опциональный параметр
            дата для фильтрации выборки, дата до которой автовалидации не попадут в выборку
        limit : int, опциональный параметр
            количество автовалидации в выборке, по умолчанию limit=200


        Returns
        -------

        функция возвращает информацию по дообучениям:

            create_date : str, datetime-like
                дата время создания автовалидации
            update_date : str, datetime-like
                дата время последнего изменения статуса автовалидации (если
                автовалидация завершена, то дата завершения автовалидации)
            prevalidation_id : str
                идентификатор автовалидации (является параметром для функций
                get_status или stop)
            model_version_id : str
                идентификатор из БМ
            status : str
                пользовательский статус автовалидации (RUNNING - автовалидация в
                процессе исполнения,  PAUSED - пользователь остановил автовалидацию,
                TECHNICAL_PAUSED - автовалидация преостановлена на время инцидента,
                DONE или ERROR - финальные статусы)
            main_traffic_light : str
                итоговый светофор
            error_message : str
                сообщение об ошибке (если автовалидация не завершилась успешно и не
                создан итоговый отчет)

        Examples
        --------

        auto_refit.get_refits(model_version_id=['34','123'])
        """
        return super()._get_jobs(model_version_id, status, date_to, date_from, limit)

    @exception_logger(logger=SdsExceptionLogPrinter())
    def get_release_notes(self, limit=5):
        """ Получить Release notes сервиса автовалидации.

        Parameters
        ----------
        limit: int
            сколько последних Release notes напечатать (по блоку / общие)

        Returns
        -------
        Возвращает Release notes сервиса автовалидации

        Examples
        --------
        auto_validator.get_release_notes(limit=5)
            если созданы Release notes для определенных проектных областей,
            то будут напечатаны 5 последних Release Notes для каждой проектной области
        """
        self._do_get_release_notes(limit)

    @keyboard_interrupt_handler()
    def send_feedback(self, usability: int = 5, valuability: int = 5, refit_id=None):
        """
        Оценить полезность сервиса превалидации

        Parameters
        ----------

        usability: int
            Для оценки удобства работы с сервисом, принимаются целые значения от 1 до 5, где 1 - совсем не удобно, а 5 - очень удобно

        valuability: int
            Для оценки полезности сервиса, принимаются целые значения от 1 до 5, где 1 - совсем не полезно, а 5 - очень полезно

        refit_id: str
            ID превалидации, если опустить, используется последняя проведенная превалидация

        Examples
        --------
        auto_validator.send_feedback(usability=5, valuability=5)
        auto_validator.send_feedback(usability=5, valuability=5, refit_id='2c3a06a2-3c70-496f-8626-21c304f285b5')
        """
        self._send_feedback(usability, valuability, refit_id)

    def stop_all(self, run_id=None, trigger_node_id=None):
        self._stop_all(run_id, trigger_node_id)

    @exception_logger(logger=SdsExceptionLogPrinter())
    def get_status(self, refit_id=None, run_id=None, trigger_node_id=None):
        """Показать всю информацию по одном дообучении запущенному пользователем,

        Если дообучение не исполнено, то функция будет запрашивать статус до
        тех пор пока процесс автовалидации остается в статусе RUNNING


        Parameters
        ----------

        refit_id : str
            идентификатор дообучения
        run_id : str
            идентификатор запуска
        trigger_node_id : str
            идентификатор триггерной ноды

        Returns
        -------

        функция возвращает информацию по дообучению:

        create_date : str
            дата время создания дообучения
        update_date : str
            дата время последнего изменения статуса дообучение (если
            дообучение завершена, то дата завершения дообучения)
        refit_id : str
            идентификатор дообучения (является параметром для функций get_status или stop)
        method_key : str
            идентификатор методики дообучения
        model_version_id : str
            идентификатор из БМ
        project_url : str
            ссылка на проект SberDS
        report_url : str
            ссылка на отчет SberDS
        status : str
            пользовательский статус дообучения (RUNNING - дообучение в
            процессе исполнения,  PAUSED - пользователь остановил дообучение,
            TECHNICAL_PAUSED - дообучение приостановлено на время инцидента,
            DONE или ERROR - финальные статусы)
        main_traffic_light : str
            итоговый светофор
        error : json
            сообщение об ошибке (если дообучение не завершилась успешно и не
            создан итоговый отчет)
        project_node_errors: list
            список ошибок исполнения нод проекта
        samples : list
            путь к источнику данных, типы выборок, разметка колонок, указанные
            при запуске автовалидации
        settings : list
            дополнительные настройки шаблона, указанные при
            запуске автовалидации


        Examples
        --------

        auto_refit.get_status(refit_id='65e92db8-7cd4-4cf4-95fa-adc00e61d6b1')
        """
        return self._do_get_status(refit_id, run_id, trigger_node_id)
