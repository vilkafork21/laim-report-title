import json
import os

from sdsautoval.context.constants import SBERDS_MAIL
from sdsautoval.context.user_context import UserContext
from sdsautoval.session.session_interface import SessionInterface
from ._publisher import _Publisher
from .exceptions.exception_decorator import exception_logger, keyboard_interrupt_handler
from .exceptions.sds_exceptions import *
from .util import SimpleTable
from .utils import keyboard_interrupt_handlers as ki_handlers
from .utils.args import is_dict_with_elements as is_dict_with_elements
from .utils.conjugating_word import ConjugatingWord, SimpleConjugatingWord, SynonymConjugatingWord
from .utils.method_dispatcher import method_dispatch

PREVALIDATION_VARIANT = 'превалидации'

AUTOVALIDATION_VARIANT = 'автовалидации'
AUTOVALIDATION_WORD = SimpleConjugatingWord({
    # именительный
    0: ['автовалидация', AUTOVALIDATION_VARIANT],
    # родительный
    1: [AUTOVALIDATION_VARIANT, 'автовалидаций'],
    # дательный
    2: [AUTOVALIDATION_VARIANT, 'автовалидациям'],
    # винительный
    3: ['автовалидацию', AUTOVALIDATION_VARIANT],
    # творительный
    4: ['автовалидацией', 'автовалидациями'],
    # предложный
    5: ['об автовалидации', 'об автовалидациях'],
})

PREVALIDATION_WORD = SimpleConjugatingWord({
    # именительный
    0: ['превалидация', PREVALIDATION_VARIANT],
    # родительный
    1: [PREVALIDATION_VARIANT, 'превалидаций'],
    # дательный
    2: [PREVALIDATION_VARIANT, 'превалидациям'],
    # винительный
    3: ['превалидацию', PREVALIDATION_VARIANT],
    # творительный
    4: ['превалидацией', 'превалидациями'],
    # предложный
    5: ['об превалидации', 'об превалидациях'],
})

AUTO_PRE_VALIDATION_WORD = SynonymConjugatingWord([PREVALIDATION_WORD, AUTOVALIDATION_WORD])


class AutoValidator(SessionInterface):
    """Основной объект - сессия автовалидации


    Examples
    --------
    auto_validator = AutoValidator()


    See Also
    --------
    Общая последовательность использования функций SDK
    0. создать обьект "сессия автовалидации"
    1. authorize: авторизация пользователя
    2.1 ModelProperties: ввод параметров для определения методики автовалидации
    2.2 ColumnsSelector, add: разметка колонок источников данных
    2.3 DataConnection, DataSample: определение источников данных
    2.4 PrevalidationProperties: формирование итоговых параметров для запуска автовалидации
    2.5 validate: локальная проверка параметров автовалидации
    3. run: запуск автовалидации
    """

    def __init__(self):
        super().__init__()
        self.publish_to_mms_response_error = False
        self.publish_to_mms_response = None
        self.project_area_type = 'autovalidation'
        UserContext.get().job_name = self.get_job_name()

    def get_job_name(self) -> ConjugatingWord:
        return AUTO_PRE_VALIDATION_WORD

    def default_object_name(self):
        return "auto_validator"

    def prevalidation_id_name(self):
        return 'prevalidation_id'

    def get_prevalidations_name(self):
        return 'get_prevalidations()'

    @exception_logger(logger=SdsExceptionLogPrinter())
    def stop(self, prevalidation_id=None, run_id=None, trigger_node_id=None, only_current=False):
        super().stop(prevalidation_id, run_id, trigger_node_id, only_current=only_current)

    @exception_logger(logger=SdsExceptionLogPrinter())
    def resume(self, prevalidation_id=None, run_id=None, trigger_node_id=None, resources=None, cpu_only=False,
               only_current=False):
        """
        Дозапустить процесс автовалидации или группы.
        Актуально, если превалидация завершилась с ошибкой или стоит на паузе.

        Parameters
        ----------
        prevalidation_id : str
            Идентификатор автовалидации
        run_id : str
            Идентификатор запуска
        trigger_node_id : str
            Идентификатор триггерной ноды
        resources: str
            Ресурсы для дозапуска узлов превалидации.
            Допустимые значения: строки виде "{N}gb{M}cpu".format(N=N, M=M), где
                N - целое число от 1 до 512, M - целое число, от 1 до 16
            Пример: 32gb8cpu или 128gb2cpu

            Если нужно указать требования только к одному из параметров ресурсов (RAM или CPU), то можно задавать
                каждый из них по отдельности
            Пример: 32gb для RAM или 2cpu для CPU

            При выборе ресурсов, где число CPU > 3 или объем RAM > 7GB, запуск вычислений будет производиться
                в экспериментальном режиме на отдельном кластере, например, могут не показываться логи в realtime
            В случае проблем и непонятных ошибок напишите, пожалуйста, нам через метод auto_validator.create_issue
                или на почту mailto:AutoValidation@sberbank.ru, mailto:sberds@omega.sbrf.ru
        cpu_only: bool
            Дозапустить только на CPU
        only_current: bool
            Дозапустить только текущую автовалидацию, не запуская дочерние.

        Returns
        -------
            функция возвращает результат дозапуска автовалидации

        Examples
        --------
        auto_validator.resume(prevalidation_id='65e92db8-7cd4-4cf4-95fa-adc00e61d6b1', resources='16gb2cpu')

        автовалидация '65e92db8-7cd4-4cf4-95fa-adc00e61d6be' успешно дозапущена
        """
        super()._resume_job(prevalidation_id, run_id, trigger_node_id, resources, cpu_only=cpu_only,
                            only_current=only_current)

    @method_dispatch("run_all", [list])
    def run(self, model_version_id, data=None, settings: dict = None, validate_settings=True, resources=None,
            trigger_node_id=None, cpu_only=False, **kwargs):
        """ Валидация параметров и запуск автовалидации.

        Parameters
        ----------
        model_version_id : int
            Идентификатор версии модели в библиотеки моделей

        data : list
            Источники данных и разметка колонок, определяются функцией DataSample
            Артефакты моделирования определяются функцией DataArtifact

        settings : dict [JSON settings of template SberDS]
            Настройки определенные в шаблоне автовалидации SberDS

        validate_settings : bool
            Проверять ли настройки, введенные пользователем (по умолчанию да)

        resources: str, default='7gb1cpu', если валидатор не задал иных внутри методики
            Ресурсы для запуска узлов превалидации.
            Допустимые значения: строки виде "{N}gb{M}cpu".format(N=N, M=M), где
                N - целое число от 1 до 512, M - целое число, от 1 до 16
            Пример: 32gb8cpu или 128gb2cpu

            Если нужно указать требования только к одному из параметров ресурсов (RAM или CPU), то можно задавать
                каждый из них по отдельности
            Пример: 32gb для RAM или 2cpu для CPU

            При выборе ресурсов, где число CPU > 3 или объем RAM > 7GB, запуск вычислений будет производиться
                в экспериментальном режиме на отдельном кластере, например, могут не показываться логи в realtime
            В случае проблем и непонятных ошибок напишите, пожалуйста, нам через метод auto_validator.create_issue
                или на почту mailto:AutoValidation@sberbank.ru, mailto:sberds@omega.sbrf.ru

        trigger_node_id: для вызова из триггерных нод

        cpu_only: bool
            Запустить только на CPU

        Returns
        -------
        функция сохраняет параметры в объекте AutoValidator и создает запрос на проведение автовалидации
        в случае, если все проверки прошли успешно, то создается проект превалидации и
        возвращается объект AutoValidator

        Examples
        --------
        # Валидация параметров и запуск автовалидации
        auto_validator.run(
            model_version_id=34,
            data=data,
            settings=settings
        )
        """
        disable_pv = False
        project_id = None
        if is_dict_with_elements(kwargs):
            disable_pv = kwargs.get('disable_pv', False)
            project_id = kwargs.get('project_id', None)
        if project_id is None:
            project_id = os.getenv("PROJECT_ID", None)
        return self._run_job(model_version_id,
                             data,
                             settings,
                             validate_settings,
                             resources,
                             trigger_node_id=trigger_node_id,
                             project_id=project_id,
                             disable_pv=disable_pv,
                             cpu_only=cpu_only)

    @exception_logger(logger=SdsExceptionLogPrinter())
    def get_prevalidations(self, model_version_id=None, status=None, date_to=None, date_from=None,
                           limit=200) -> SimpleTable:
        """Показать основную информацию по автовалидациям, запущенным
        пользователем (проверка пользователя по login), сортировка по дате
        создания от последней созданной к более ранней


        Parameters
        ----------

        model_version_id : str, list, опциональный параметр
            идентификатор из БМ или список идентификаторов
        status : str, list, опциональный параметр
            статус процесса автовалидации
            доступные варианты: RUNNING, DONE, ERROR, PAUSED, TECHNICAL_PAUSED
        date_to : str, datetime-like, в формате "YYYY-MM-DD", опциональный параметр
            дата для фильтрации выборки, дата после которой автовалидации не попадут в выборку
        date_from : str, datetime-like, в формате "YYYY-MM-DD", опциональный параметр
            дата для фильтрации выборки, дата до которой автовалидации не попадут в выборку
        limit : int, опциональный параметр
            количество автовалидации в выборке, по умолчанию limit=200


        Returns
        -------

        функция возвращает информацию по автовалидациям:

        create_date : str, datetime-like
            дата время создания автовалидации
        update_date : str, datetime-like
            дата время последнего изменения статуса автовалидации (если
            автовалидация завершена, то дата завершения автовалидации)
        prevalidation_id : str
            идентификатор автовалидации (является параметром для функций
            get_status или stop)
        method_key : str
            идентификатор методики автовалидации
        model_version_id : str
            идентификатор из БМ
        project_url : str
            ссылка на проект SberDS
        report_url : str
            ссылка на отчет SberDS
        status : str
            пользовательский статус автовалидации (RUNNING - автовалидация в
            процессе исполнения,  PAUSED - пользователь остановил автовалидацию,
            TECHNICAL_PAUSED - автовалидация преостановлена на время инцидента,
            DONE или ERROR - финальные статусы)
        main_traffic_light : str
            итоговый светофор
        error_message : str
            сообщение об ошибке (если автовалидация не завершилась успешно и не
            создан итоговый отчет)

        Examples
        --------

        auto_validator.get_prevalidations(model_version_id=['34','123']) - функция
            вернет общую информацию по 200 последним автовалидациям, запущенным
            пользователем, для которых model_version_id = '34' или  model_version_id = '123',
            сортировка по дате создания (сначала новые потом старые)
        """
        return super()._get_jobs(model_version_id, status, date_to, date_from, limit)

    def run_all(self, params: list, validate_settings=True):
        return self._run_job_all(params, validate_settings)

    @exception_logger(logger=SdsExceptionLogPrinter())
    @keyboard_interrupt_handler(ki_handler=ki_handlers.auto_validator_publish_to_mms)
    def publish_to_mms(self, prevalidation_id, wait_timeout=30):
        """Опубликовать результаты превалидации в библиотеке моделей

        Для успешно закончившихся превалидаций в статусе DONE можно опубликовать
        результаты в карточке версии модели.

        Parameters
        ----------

        prevalidation_id : str
            идентификатор превалидации
        wait_timeout : int, optional, default = 30
            время ожидания публикации превалидации (в секундах)

        Returns
        -------

        функция возвращает результат публикации
        """
        self.publish_to_mms_response_error = False
        self.publish_to_mms_response = None
        self._ensure_authorized()
        self._event_service.print_by_prevalidation(prevalidation_id)

        client = self._get_client()

        publisher = _Publisher(prevalidation_id, self._get_status_request, wait_timeout, self._host, self._zone,
                               self.get_job_name())
        response = client.publish(prevalidation_id)
        self.publish_to_mms_response = response

        if not publisher.process_response(response):
            self.publish_to_mms_response_error = True
            error_message, recommendation = self._get_error_message_and_recommendation(prevalidation_id)
            print(f"\nСообщение ошибки: {error_message}")
            print(f"Рекомендация: {recommendation}")

    def _get_error_message_and_recommendation(self, prevalidation_id):
        """
        Вызывает _get_status_request и находит сообщение
        ошибки от Библиотеки Моделей.

        Возвращает сообщение об ошибке и рекомендацию.
        """
        status = self._get_status_request(prevalidation_id)

        pr = status.get("publish_response")
        pr = json.loads(pr if pr else "{}")
        error_message = pr.get("payload", dict()).get("resultMessage", "")

        # ФИО пользователя для сообщений типа "Пользователь <ФИО найденного пользователя> не ..."
        # noinspection PyBroadException
        try:
            name = error_message[len("Пользователь "): error_message.index("не")].strip()
        except Exception as _:
            name = ""

        # Список фрагментов сообщений об ошибке от БМ.
        current_em = [
            "Версия модели ID",
            "Статус версии модели ID",
            "Пользователь не найден в mms-user-service",
            "Пользователь не найден в mms-core-service",
            " не активен, поэтому он",
            "не имеет роли разработчика моделей",
            "не входит в команду разработки"
        ]

        new_em = [
            f"Карточка версия модели ID={status.get('model_version_id')} не найдена в Библиотеке Моделей ",
            f"Статус версии модели ID={status.get('model_version_id')} не допускает публикацию результатов превалидации",
            f"Ваш логин '{self._login}' не найден в Библиотеке Моделей (mms-user-service)",
            f"Ваш логин '{self._login}' не найден в Библиотеке Моделей (mms-core-service)",
            f"Пользователь '{name}' не активен в Библиотеке Моделей, поэтому не может выполнять публикацию результатов превалидации",
            f"Пользователь '{name}' не имеет роли «Разработчик моделей (Data Scientist)», поэтому не может выполнять публикацию результатов превалидации",
            f"Пользователь '{name}' не входит в команду разработки версии модели ID={status.get('model_version_id')}, поэтому не может выполнять публикацию результатов превалидации"
        ]

        url = "https://confluence.sberbank.ru/pages/viewpage.action?pageId=7553654037#id-%F0%9F%93%9AFAQ-%D0%9A%D0%B0%D0%BA%D0%BC%D0%BD%D0%B5%D1%81%D1%82%D0%B0%D1%82%D1%8C%D0%BF%D0%BE%D0%BB%D1%8C%D0%B7%D0%BE%D0%B2%D0%B0%D1%82%D0%B5%D0%BB%D0%B5%D0%BC%D0%B2%D0%91%D0%9C(%D0%B8%D0%B4%D0%BB%D1%8F%D1%87%D0%B5%D0%B3%D0%BE%D0%BC%D0%BD%D0%B5%D1%8D%D1%82%D0%BE%D0%BD%D1%83%D0%B6%D0%BD%D0%BE)"
        default_rec = f"Обратитесь в службу поддержки через метод auto_validator.create_issue или на почту {SBERDS_MAIL}"
        recomendation = [
            "Проверьте ID версии модели в БМ на корректность. И перезапустите превалидацию с этим ID. Затем опубликуйте результаты новой превалидации.",
            f"Переведите версию модели на статус «Разработка» и повторите публикацию. Если перевести модель этот статус невозможно, обратитесь в службу поддержки через метод auto_validator.create_issue или на почту {SBERDS_MAIL} с просьбой публикации результатов превалидации. В обращении укажите ID превалидации, ссылку на проект и ссылку на отчёт.",
            f"Получите доступ к Библиотеке Моделей {url}. Если доступ получали, обратитесь в службу поддержки через метод auto_validator.create_issue или на почту {SBERDS_MAIL}",
            f"Получите доступ к Библиотеке Моделей {url}. Если доступ получали, обратитесь в службу поддержки через метод auto_validator.create_issue или на почту {SBERDS_MAIL}",
            f"Обратитесь в службу поддержки через метод auto_validator.create_issue или на почту {SBERDS_MAIL}",
            f"Получите в Библиотеке Моделей роль «Разработчик моделей (Data Scientist)» или обратитесь в службу поддержки через метод auto_validator.create_issue или на почту {SBERDS_MAIL}",
            f"Попросите своего Team Lead добавить вас в команду разработки версии модели или обратитесь в службу поддержки через метод auto_validator.create_issue или на почту {SBERDS_MAIL}"
        ]

        e_num = None
        for i, subs in enumerate(current_em):
            if error_message.find(subs) != -1:
                e_num = i

        # Выбрать сообщение об ошибке и рекоменацию.
        # Если ошибки от БМ нет в шаблоне, вернуть эту ошибку,
        # а рекомендацию выбрать по статусу.
        if e_num is None:
            ps = status.get("publish_status")
            status_rec = {
                "INVALID_REQUEST": "Проверьте параметры сообщения, типы данных и тип задачи. Если не поможет: ",
                "INVALID_STATE": "Проверьте версию модели в БМ, перезапустите превалидацию и повторите публикацию. Если не поможет: ",
                "INVALID_ZONE": "Проверьте зону модели, перезапустите превалидацию и повторите публикацию. Если не поможет: ",
            }
            get_em = error_message
            get_recomendation = status_rec.get(ps, "") + default_rec
        else:
            get_em = new_em[e_num]
            get_recomendation = recomendation[e_num]

        return get_em, get_recomendation

    @exception_logger(logger=SdsExceptionLogPrinter())
    def get_status(self, prevalidation_id=None, run_id=None, trigger_node_id=None):
        """Показать всю информацию по одной автовалидации запущенной пользователем,

        Если автовалидация не исполнена, то функция будет запрашивать статус до
        тех пор пока процесс автовалидации остается в статусе RUNNING


        Parameters
        ----------

        prevalidation_id : str
            идентификатор автовалидации
        run_id : str
            идентификатор запуска
        trigger_node_id : str
            идентификатор триггерной ноды

        Returns
        -------

        функция возвращает информацию по автовалидации

        create_date : str
            дата время создания автовалидации
        update_date : str
            дата время последнего изменения статуса автовалидации (если
            автовалидация завершена, то дата завершения автовалидации)
        prevalidation_id : str
            идентификатор автовалидации (является параметром для функций get_status или stop)
        method_key : str
            идентификатор методики автовалидации
        model_version_id : str
            идентификатор из БМ
        project_url : str
            ссылка на проект SberDS
        report_url : str
            ссылка на отчет SberDS
        status : str
            пользовательский статус автовалидации (RUNNING - автовалидация в
            процессе исполнения,  PAUSED - пользователь остановил автовалидацию,
            TECHNICAL_PAUSED - автовалидация приостановлена на время инцидента,
            DONE или ERROR - финальные статусы)
        main_traffic_light : str
            итоговый светофор
        error : json
            сообщение об ошибке (если автовалидация не завершилась успешно и не
            создан итоговый отчет)
        project_node_errors: list
            список ошибок исполнения нод проекта
        samples : list
            путь к источнику данных, типы выборок, разметка колонок, указанные
            при запуске автовалидации
        settings : list
            дополнительные настройки шаблона, указанные при
            запуске автовалидации


        Examples
        --------

        auto_validator.get_status(prevalidation_id='65e92db8-7cd4-4cf4-95fa-adc00e61d6b1')
        """
        return self._do_get_status(prevalidation_id, run_id, trigger_node_id)

    @exception_logger(logger=SdsExceptionLogPrinter())
    def get_release_notes(self, limit=5):
        """ Получить Release notes сервиса автовалидации.

        Parameters
        ----------
        limit: int
            сколько последних Release notes напечатать (по блоку / общие)

        Returns
        -------
        Возвращает Release notes сервиса автовалидации

        Examples
        --------
        auto_validator.get_release_notes(limit=5)
            если созданы Release notes для определенных проектных областей,
            то будут напечатаны 5 последних Release Notes для каждой проектной области
        """
        self._do_get_release_notes(limit)

    @keyboard_interrupt_handler()
    def send_feedback(self, usability: int, valuability: int, prevalidation_id=None):
        """
        Оценить полезность сервиса превалидации

        Parameters
        ----------

        usability: int
            Для оценки удобства работы с сервисом, принимаются целые значения от 1 до 5, где 1 - совсем не удобно, а 5 - очень удобно

        valuability: int
            Для оценки полезности сервиса, принимаются целые значения от 1 до 5, где 1 - совсем не полезно, а 5 - очень полезно

        prevalidation_id: bool
            ID превалидации, если опустить, используется последняя проведенная превалидация

        Examples
        --------
        auto_validator.send_feedback(usability=5, valuability=5)
        auto_validator.send_feedback(usability=5, valuability=5, prevalidation_id='2c3a06a2-3c70-496f-8626-21c304f285b5')
        """
        self._send_feedback(usability, valuability, prevalidation_id)
