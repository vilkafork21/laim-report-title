import contextlib
import json
import math
import os
import threading
import time
import uuid
from copy import deepcopy

from sdsautoval.method.method_models import MultipleMethodExtendedModel, CustomMethodExtendedModel
from .context.user_context import UserContext
from .exceptions.exception_decorator import exception_logger, keyboard_interrupt_handler, return_self
from .exceptions.sds_exceptions import SdsExceptionLogPrinter, SdsResourceError, SdsSettingsValidationError, \
    SdsParamValidationError
from .prevalidation.prevalidation import Prevalidation
from .prevalidation.prevalidation_converter import PreValidationConverter
from .prevalidation.prevalidation_settings import PreValidationSettings
from .prevalidation.print_log_progress import PrintBarProgress
from .rest_utils import UserSession
from .session.session_interface import SessionInterface
from .util import SimpleTable
from .utils import keyboard_interrupt_handlers as ki_handlers
from .utils.args import is_dict_with_elements
from .utils.conjugating_word import ConjugatingWord, SimpleConjugatingWord, SynonymConjugatingWord

METHOD_TASKS = {
    'Binary': [
        "AM_LIGHTAUTOML_WHITE_BOX", "AM_SASHA_ML_PIPELINE", "AM_WOE_LOGRISK", "AM_SOROCA_ML",
        "AM_LIGHTAUTOML_BLACK_BOX", "AM_OPTIML_PIPELINE", "AM_CATBOOST_PIPELINE",
        "AM_SOLID_CREDITING_PIPELINE", "AM_DREAMML_PIPELINE", "AM_RB_CUSTOM_PIPELINE", "AM_ROSOMAHA_ML"
    ],

    'Regression': [
        "AM_LIGHTAUTOML_WHITE_BOX",
        "AM_LIGHTAUTOML_BLACK_BOX", "AM_OPTIML_PIPELINE", "AM_CATBOOST_PIPELINE",
        "AM_SOLID_CREDITING_PIPELINE", "AM_DREAMML_PIPELINE", "AM_RB_CUSTOM_PIPELINE"
    ],

    'Multiclass': [
        "AM_LIGHTAUTOML_BLACK_BOX", "AM_CATBOOST_PIPELINE", "AM_OPTIML_PIPELINE", "AM_DREAMML_PIPELINE"
    ],

    'Uplift': [
        "AM_LIGHTAUTOML_UPLIFT", "AM_POWER_UPLIFT"
    ],

    'Time Series': [
        "AM_LIGHTAUTOML_AUTOTS", "AM_SARIMAX_TS", "AM_TIMESNET", "AM_KRISTINA_TS", "AM_PROPHET"
    ],

    'Multilabel': [
        "AM_LIGHTAUTOML_BLACK_BOX", "AM_CATBOOST_PIPELINE", "AM_PYBOOST", "AM_KDA_PIPELINE"
    ]
}

INFERENCE_LINKS = {
    "prom": {
        "AM_LIGHTAUTOML_BLACK_BOX": {
            "mef": "https://df-bitbucket.ca.sbrf.ru/scm/sdsval/lightautoml_mef.git",
            "pim": "https://df-bitbucket.ca.sbrf.ru/scm/sdsval/lightautoml_pim.git",
        },
        "AM_CATBOOST_PIPELINE": {
            "mef": "https://df-bitbucket.ca.sbrf.ru/scm/sdsval/catboost_mef.git",
            "pim": "https://df-bitbucket.ca.sbrf.ru/scm/sdsval/catboost_pim.git",
        },
        "AM_LIGHTAUTOML_WHITE_BOX": {
            "mef": "https://df-bitbucket.ca.sbrf.ru/scm/sdsval/autowoe_mef.git",
            "pim": "https://df-bitbucket.ca.sbrf.ru/scm/sdsval/autowoe_pim.git"
        },
        "AM_ROSOMAHA_ML": {
            "mef": "https://df-bitbucket.ca.sbrf.ru/scm/sdsval/rosomaha_mef.git",
            "pim": "https://df-bitbucket.ca.sbrf.ru/scm/sdsval/rosomaha_pim.git"
        },
        "AM_SASHA_ML_PIPELINE": {
            "mef": "https://df-bitbucket.ca.sbrf.ru/scm/sdsval/sashaml_mef.git",
            "pim": "https://df-bitbucket.ca.sbrf.ru/scm/sdsval/sashaml_pim.git"
        },
        "AM_SOLID_CREDITING_PIPELINE": {
            "mef": "https://df-bitbucket.ca.sbrf.ru/scm/sdsval/solid_crediting_mef.git",
            "pim": "https://df-bitbucket.ca.sbrf.ru/scm/sdsval/solid_crediting_pim.git"
        }
    },
    "ift": {
        "AM_LIGHTAUTOML_BLACK_BOX": {
            "mef": "https://stash.delta.sbrf.ru/scm/sdsdh/lightautoml_mef.git",
            "pim": "https://stash.delta.sbrf.ru/scm/sdsdh/lightautoml_pim.git"
        },
        "AM_CATBOOST_PIPELINE": {
            "mef": "https://stash.delta.sbrf.ru/scm/sdsdh/catboost_mef.git",
            "pim": "https://stash.delta.sbrf.ru/scm/sdsdh/catboost_pim.git"
        },
        "AM_LIGHTAUTOML_WHITE_BOX": {
            "mef": "https://stash.delta.sbrf.ru/scm/sdsdh/autowoe_mef.git",
            "pim": "https://stash.delta.sbrf.ru/scm/sdsdh/autowoe_pim.git"
        },
        "AM_ROSOMAHA_ML": {
            "mef": "https://stash.delta.sbrf.ru/scm/sdsdh/rosomaha_mef.git",
            "pim": "https://stash.delta.sbrf.ru/scm/sdsdh/rosomaha_pim.git"
        },
        "AM_SASHA_ML_PIPELINE": {
            "mef": "https://stash.delta.sbrf.ru/scm/sdsdh/sashaml_mef.git",
            "pim": "https://stash.delta.sbrf.ru/scm/sdsdh/sashaml_pim.git"
        },
        "AM_SOLID_CREDITING_PIPELINE": {
            "mef": "https://stash.delta.sbrf.ru/scm/sdsdh/solid_crediting_mef.git",
            "pim": "https://stash.delta.sbrf.ru/scm/sdsdh/solid_crediting_pim.git"
        }
    },
    "dev": {
        "AM_LIGHTAUTOML_BLACK_BOX": {
            "mef": "https://stash.sigma.sbrf.ru/scm/sdsval/lightautoml_mef.git",
            "pim": "https://stash.sigma.sbrf.ru/scm/sdsval/lightautoml_pim.git"
        },
        "AM_CATBOOST_PIPELINE": {
            "mef": "https://stash.sigma.sbrf.ru/scm/sdsval/catboost_mef.git",
            "pim": "https://stash.sigma.sbrf.ru/scm/sdsval/catboost_pim.git"
        },
        "AM_LIGHTAUTOML_WHITE_BOX": {
            "mef": "https://stash.sigma.sbrf.ru/scm/sdsval/autowoe_mef.git",
            "pim": "https://stash.sigma.sbrf.ru/scm/sdsval/autowoe_pim.git"
        },
        "AM_ROSOMAHA_ML": {
            "mef": "https://stash.sigma.sbrf.ru/scm/sdsval/rosomaha_mef.git",
            "pim": "https://stash.sigma.sbrf.ru/scm/sdsval/rosomaha_pim.git"
        },
        "AM_SASHA_ML_PIPELINE": {
            "mef": "https://stash.sigma.sbrf.ru/scm/sdsval/sashaml_mef.git",
            "pim": "https://stash.sigma.sbrf.ru/scm/sdsval/sashaml_pim.git"
        },
        "AM_SOLID_CREDITING_PIPELINE": {
            "mef": "https://stash.sigma.sbrf.ru/scm/sdsval/solid_crediting_mef.git",
            "pim": "https://stash.sigma.sbrf.ru/scm/sdsval/solid_crediting_pim.git"
        }
    }
}


DATA_PERMISSION_MESSAGE = """Продолжая запуск, Вы делаете загружаемые данные доступными в проекте SberDS команде SDS.R&D из подразделения Управления модельными рисками. 
Подтвердите действие (да / нет).

[Минутка просвещения] подробнее узнать о стандарте категорирования, передачи и хранения информации можно в ВНД 4727 ч.4
"""

PREVALIDATION_VARIANT = 'автомоделирования'

AUTOVALIDATION_VARIANT = 'автомоделирования'
AUTOVALIDATION_WORD = SimpleConjugatingWord({
    # именительный
    0: ['автомоделирования', AUTOVALIDATION_VARIANT],
    # родительный
    1: [AUTOVALIDATION_VARIANT, 'автомоделирований'],
    # дательный
    2: [AUTOVALIDATION_VARIANT, 'автомоделированиям'],
    # винительный
    3: ['автомоделирование', AUTOVALIDATION_VARIANT],
    # творительный
    4: ['автомоделированием', 'автомоделированиями'],
    # предложный
    5: ['об автомоделировании', 'об автомоделировании'],
})

PREVALIDATION_WORD = SimpleConjugatingWord({
    # именительный
    0: ['автомоделирование', PREVALIDATION_VARIANT],
    # родительный
    1: [PREVALIDATION_VARIANT, 'автомоделирования'],
    # дательный
    2: [PREVALIDATION_VARIANT, 'автомоделированиям'],
    # винительный
    3: ['автомоделирование', PREVALIDATION_VARIANT],
    # творительный
    4: ['автомоделированием', 'автомоделированиями'],
    # предложный
    5: ['об автомоделировании', 'об автомоделированиях'],
})

AUTO_PRE_VALIDATION_WORD = SynonymConjugatingWord([PREVALIDATION_WORD, AUTOVALIDATION_WORD])

METRIC_MAPPING = {
    'ROC_AUC': 'roc_auc_score',
    'GINI': 'gini',
    'PR_AUC': 'pr_auc',
    'F1': 'f1_score',
    'PRECISION': 'precision_score',
    'RECALL': 'recall_score',
    'ACCURACY': 'accuracy_score',
    'LOGLOSS': 'logloss',
    'BRIER_LOSS': 'brier_loss',
    'ECE': 'ece',
    'PRECISION@K': 'precision@k',
    'RECALL@K': 'recall@k',
    'AVERAGE_PRECISION@K': 'average_precision@k',
    'FBETA_SCORE': 'fbeta_score',
    'REC@SPEC': 'rec@spec',
    'AUCROC@FPR': 'aucroc@fpr',
    'MSE': 'MSE',
    'RMSE': 'RMSE',
    'MAE': 'MAE',
    'MAPE': 'MAPE',
    'SMAPE': 'SMAPE',
    'WAPE': '1-WAPE',
    'R2': 'r2_score',
    'R2_ADJ': 'r2_adj',
    'MSLE': 'mean_squared_log_error',
    'MDAE': 'median_absolute_error',
    'MDAPE': 'median_absolute_percentage_error',
    'RMSLE': 'rmsle',
    'MAX_ERROR': 'max_error',
    'MAPE_WITHOUT_ZEROS': 'mape_without_zeros',
    'MAE_TO_MODULE_MEAN': 'mae_to_module_mean',
    'MAE_TO_MEAN': 'mae_to_mean',
    'F1_MACRO': 'f1_macro',
    'F1_MICRO': 'f1_micro',
    'F1_WEIGHTED': 'f1_weighted',
    'RECALL_MACRO': 'recall_macro',
    'RECALL_MICRO': 'recall_micro',
    'PRECISION_MICRO': 'precision_micro',
    'PRECISION_MACRO': 'precision_macro',
    'ROC_AUC_OVR': 'roc_auc_score_ovr',
    'ROC_AUC_OVO': 'roc_auc_score_ovo',
    'QINI': 'qini_auc_score',
    'CUM_GAIN': 'uplift_auc_score',
    'ADJ_QINI': 'qini_auc_score',
    'UPLIFT@K': 'uplift@k',
    'GINI_WITH_NANS': 'gini_with_nans',
    'ROC_AUC_MACRO': 'roc_auc_score_macro',
    'ROC_AUC_SAMPLES': 'roc_auc_score_average_samples',
    'F1_SAMPLES': 'f1_average_samples',
    'RECALL_SAMPLES': 'recall_average_samples',
    'PRECISION_SAMPLES': 'precision_average_samples',
    'HAMMING_ACCURACY': 'hamming_accuracy',
    'JACCARD_SAMPLES': 'jaccard_average_samples',
    'JACCARD_MICRO': 'jaccard_micro',
    'JACCARD_MACRO': 'jaccard_macro',
    'NDCG': 'ndcg_score',
    'NDCG@K': 'ndcg@k',
    'MAP@K': 'map@k',
    'AP@K': 'ap@k',
    'AVERAGE_RECALL@K': 'average_recall@k',
    'MRR': 'mrr',
    'COVERAGE_ERROR': 'coverage_error',
    'LABEL_RANKING_LOSS': 'label_ranking_loss',
    'LABEL_RANKING_AVERAGE_PRECISION_SCORE': 'label_ranking_average_precision_score',
    'MEAN_MAE': 'mean_mae',
    'MEAN_MSE': 'mean_mse',
    'SPEARMAN': 'spearman',
    'POWERSTAT': 'powerstat'
}

ML_TASK_MAPPING = {
    "Binary": "BINARY_CLASS",
    "Time Series": "TS",
    "Uplift": "UPLIFT_BINARY_TARGET_TRIT",
    "Regression": "REG_ON_TABLE",
    "Multilabel": "MULTI_LABEL",
    "Multiclass": "MULTICLASS_TABULAR"
}

METRIC_COLS = [
    "method", "project_url", "modeling_id", "metric_name", "main_traffic_light", "automodel_traffic_light",
    "comparison_traffic_light", "altmod_stat_worse", "validation_url", "autorefit_info",
    "train_metric_baseline", "train_metric_automodel", "train_metric_prom_score",
    "val_metric_baseline", "val_metric_automodel", "val_metric_prom_score",
    "out_of_sample_metric_baseline", "out_of_sample_metric_automodel", "out_of_sample_metric_prom_score",
    "out_of_time_metric_baseline", "out_of_time_metric_automodel", "out_of_time_metric_prom_score",
    "automodel_pkl_location", "prevalidation_id", "inference_link"
]


class AutoModel(SessionInterface):
    """Основной объект - сессия автомоделирования


    Examples
    --------
    auto_model = AutoModel()


    See Also
    --------
    Общая последовательность использования функций SDK
    0. создать обьект "сессия автомоделирования"
    1. authorize: авторизация пользователя
    2.1 ModelProperties: ввод параметров для определения методики автомоделирования
    2.2 ColumnsSelector, add: разметка колонок источников данных
    2.3 DataConnection, DataSample: определение источников данных
    2.4 PrevalidationProperties: формирование итоговых параметров для запуска автомоделирования
    2.5 validate: локальная проверка параметров автомоделирования
    3. run: запуск автомоделирования
    """

    def __init__(self):
        super().__init__()
        self.project_area_type = 'automodeling'
        UserContext.get().job_name = self.get_job_name()
        self._timeout = None
        self._run_id = None
        self._run_id_dict = {}
        self._selected_methods = None
        self._correct_val_settings = None
        self.primary_metric = ""
        self.task = {}
        self.available_tasks = ["Binary", "Regression", "Multiclass", "Multilabel", "Multireg", "Uplift", "Time Series"]
        self.split_data_flag = False
        self.train_size = 0.8
        self.val_size = 0
        self.test_size = 0.2
        self.stratify = ""
        self.last_train_date = ""
        self.first_test_date = ""
        self.split_settings = {}
        self._inference_type = "mef"

    def get_job_name(self) -> ConjugatingWord:
        return AUTO_PRE_VALIDATION_WORD

    def default_object_name(self):
        return "auto_model"

    def prevalidation_id_name(self):
        return 'prevalidation_id'

    def get_prevalidations_name(self):
        return 'get_modeling()'

    @exception_logger(logger=SdsExceptionLogPrinter())
    @keyboard_interrupt_handler(ki_handler=ki_handlers.session_interface_stop)
    def stop(self, modeling_id, stop_all=False):
        """Остановить процесс выполнения проекта


        Parameters
        ----------
        modeling_id : str | list
            идентификатор запущенной методики или лист из идентификаторов
        stop_all : bool
            идентификатор полной остановки всех проектов при одновременном запуске нескольких проектов

        Returns
        -------
            функция возвращает результат остановки проекта

        Examples
        --------
        auto_model.stop(modeling_id='65e92db8-7cd4-4cf4-95fa-adc00e61d6b1')
        auto_model.stop(modeling_id=['65e92db8-7cd4-4cf4-95fa-adc00e61d6b1', '12f31vc6-4dd0-8ac5-33aa-gdc00e61d6b1'])

        проект автовалидации/фин.оценки/автомоделирования '65e92db8-7cd4-4cf4-95fa-adc00e61d6be' успешно остановлен
        """
        self._ensure_authorized()
        if stop_all and isinstance(modeling_id, list):
            for modeling in modeling_id:
                self._event_service.print_by_prevalidation(modeling)
                print(f'Проект автомоделирования \'{str(modeling)}\' успешно остановлен')

            self._stop_all_modeling()
            return

        if isinstance(modeling_id, str):
            self._stop_one_modeling(modeling_id)

    def _stop_all_modeling(self):
        client = self._get_client()
        client.stop_all(run_id=self._run_id, trigger_node_id=self._prevalidation.get_trigger_node_id())

    def _stop_one_modeling(self, modeling_id):
        self._event_service.print_by_prevalidation(modeling_id)
        client = self._get_client()
        client.stop(modeling_id)
        print(f'Проект автомоделирования \'{str(modeling_id)}\' успешно остановлен')

    @exception_logger(logger=SdsExceptionLogPrinter())
    def resume(self, modeling_id=None, run_id=None, trigger_node_id=None, resources=None):
        """
        Дозапустить процесс автомоделирования.
        Актуально, если автомоделирование завершилось с ошибкой или стоит на паузе.


        Parameters
        ----------
        modeling_id : str
            Идентификатор автомоделирования
        run_id : str
            Идентификатор запуска
        trigger_node_id : str
            Идентификатор триггерной ноды
        resources: str
            Ресурсы для дозапуска узлов автомоделирования.
            Допустимые значения: строки виде "{N}gb{M}cpu".format(N=N, M=M), где
                N - целое число от 1 до 512, M - целое число, от 1 до 16
            Пример: 32gb8cpu или 128gb2cpu

            Если нужно указать требования только к одному из параметров ресурсов (RAM или CPU), то можно задавать
                каждый из них по отдельности
            Пример: 32gb для RAM или 2cpu для CPU

            При выборе ресурсов, где число CPU > 3 или объем RAM > 7GB, запуск вычислений будет производиться
                в экспериментальном режиме на отдельном кластере, например, могут не показываться логи в realtime
            В случае проблем и непонятных ошибок напишите, пожалуйста, нам через метод auto_model.create_issue
                или на почту mailto:AutoValidation@sberbank.ru, mailto:sberds@omega.sbrf.ru

        Returns
        -------
            функция возвращает результат дозапуска автомоделирования

        Examples
        --------
        auto_model.resume(modeling_id='65e92db8-7cd4-4cf4-95fa-adc00e61d6b1', resources='16gb2cpu')

        автомоделирование '65e92db8-7cd4-4cf4-95fa-adc00e61d6be' успешно дозапущено
        """
        super()._resume_job(modeling_id, run_id, trigger_node_id, resources)

    def get_methods_with_kss(
        self,
        ml_task: str = None,
        device: str = None,
        tags: list = None
    ):
        """Выдает ранжированный лист методик автомоделирования при помощи KSS


        Parameters
        ----------

        ml_task: str, default = None
            Название ML-задачи. Можно использовать через auto_model.select_task().
            Возможны следующие варианты:
            1. Binary - для бинарной классификации
            2. Regression - для регресси
            3. Multiclass - для мультиклассовой классификации
            4. Multilabel - для мультилейбл классификации
            5. Multireg - для мультирегрессии
            6. Uplift - для аплифт моделирования
            7. Time Series - для временных рядов

        device: str
            Фильтр по использованию железа, принимает значения GPU или CPU

        tags: list
            Список тэгов для пайплайна KSS
            Как пример: ["boosting", "feature_selection", "neural_network", "catboost", "mef_inference"]

        Returns
        -------
        Функция возращает лист из ранжированных пайплайнов автомоделирования под определенные фильтры


         Examples
        --------
        auto_model.get_methods_with_kss(ml_tasks='Binary', device='GPU', tags=["boosting", "mef_inference"])
        """
        if "Objective" not in self.task and ml_task is None:
            print("Выберите ml_task или заполните ее через метод select_task")
            return

        if ml_task is None:
            ml_task = ML_TASK_MAPPING[self.task["Objective"]]
        else:
            ml_task = ML_TASK_MAPPING[ml_task]

        pipelines = self._kss_service.get_top_pipelines(ml_task=ml_task, hardware_solution=device, tags=tags)
        if len(pipelines) < 1:
            print("Нет выбранных методик под ml-задачу. Выберите методику через auto_model.get_methods")
            return None
        print(f"Выбранные методы: {pipelines}")
        return pipelines


    def select_method_with_kss(
        self,
        top_pipelines: int = 5,
        ml_task: str = None,
        device: str = None,
        tags: list = None
    ):
        """Выбрать методики автомоделирования при помощи KSS


        Parameters
        ----------
        top_pipelines: int
            Топ-лучших по рейтингу KSS пайплайнов для запуска автомоделирования

        ml_task: str, default = None
            Название ML-задачи. Можно использовать через auto_model.select_task().
            Возможны следующие варианты:
            1. Binary - для бинарной классификации
            2. Regression - для регресси
            3. Multiclass - для мультиклассовой классификации
            4. Multilabel - для мультилейбл классификации
            5. Multireg - для мультирегрессии
            6. Uplift - для аплифт моделирования
            7. Time Series - для временных рядов

        device: str
            Фильтр по использованию железа, принимает значения GPU или CPU

        tags: list
            Список тэгов для пайплайна KSS
            Как пример: ["boosting", "feature_selection", "neural_network", "catboost", "mef_inference"]

        Returns
        -------
        Функция сохраняет выбор методики в объекте сессии


         Examples
        --------
        auto_model.select_method_with_kss(top_pipelines=5, ml_tasks='Binary', device='GPU', tags=["boosting", "mef_inference"])
        """
        if "Objective" not in self.task and ml_task is None:
            print("Выберите ml_task или заполните ее через метод select_task")
            return

        if ml_task is None:
            ml_task = ML_TASK_MAPPING[self.task["Objective"]]
        else:
            ml_task = ML_TASK_MAPPING[ml_task]

        pipelines = self._kss_service.get_top_pipelines(ml_task=ml_task, hardware_solution=device, tags=tags)[:top_pipelines]
        if len(pipelines) < 1:
            print("Нет выбранных методик под ml-задачу. Выберите методику через auto_model.get_methods")
            return None
        print(f"Выбранные методы: {pipelines}")
        return self.select_method(pipelines)

    @exception_logger(logger=SdsExceptionLogPrinter())
    @keyboard_interrupt_handler(ki_handler=ki_handlers.session_interface_select_methods)
    def select_method(self, methods_id):
        """ Выбрать методику или сразу несколько методик.


        Parameters
        ----------
        methods_id : str | list[str]
            Уникальный идентификатор методики или лист из них.


        Returns
        -------
        Функция сохраняет выбор методики в объекте сессии,
        возвращает общую информацию о методике, требования к источникам данных и разметке, в том числе settings из шаблона SberDS


         Examples
        --------
        auto_validator.select_method()

        :return:
        """
        if isinstance(methods_id, str):
            return super().select_method(methods_id)
        elif isinstance(methods_id, list) and self.check_pipline(methods_id):
            methods_info = []
            for method_id in methods_id:
                selected_method = super().select_method(method_id)
                selected_method.__class__ = CustomMethodExtendedModel
                methods_info.append(selected_method)
            methods_model = MultipleMethodExtendedModel(methods_info)
            self._selected_methods = methods_model
            return methods_model
        else:
            SdsResourceError('Unexpected methods type', 'Expected to be str method or List of methods')

    def run(
            self,
            model_version_id=99999,
            data=None,
            settings=None,
            validate_settings=True,
            resources=None,
            cpu_only=False,
            trigger_node_id=None,
            run_id = None,
            **kwargs
    ):
        """ Валидация параметров и запуск автомоделирования.

        Parameters
        ----------

        model_version_id : int
            Идентификатор версии модели в библиотеки моделей

        data : list
            Источники данных и разметка колонок, определяются функцией DataSample
            Артефакты моделирования определяются функцией DataArtifact

        settings : dict [JSON settings of template SberDS]
            Настройки определенные в шаблоне автомоделирования SberDS

        validate_settings : bool
            Проверять ли настройки, введенные пользователем (по умолчанию да)

        methods: List[str]
            Названия методик для запуска

        resources: str, default='7gb1cpu', если разработчик не задал иных внутри методики
            Ресурсы для запуска узлов моделирования.
            Допустимые значения: строки виде "{N}gb{M}cpu".format(N=N, M=M), где
                N - целое число от 1 до 512, M - целое число, от 1 до 16
            Пример: 32gb8cpu или 128gb2cpu

            Если нужно указать требования только к одному из параметров ресурсов (RAM или CPU), то можно задавать
                каждый из них по отдельности
            Пример: 32gb для RAM или 2cpu для CPU

            При выборе ресурсов, где число CPU > 3 или объем RAM > 7GB, запуск вычислений будет производиться
                в экспериментальном режиме на отдельном кластере, например, могут не показываться логи в realtime
            В случае проблем и непонятных ошибок напишите, пожалуйста, нам через метод auto_model.create_issue
                или на почту mailto:AutoValidation@sberbank.ru, mailto:sberds@omega.sbrf.ru

        cpu_only: bool, default=False
            Запустить пайплайн на CPU вне зависимости от запрашиваемого GPU-ресурса.
            Подходит только для Any GPU/CPU пайплайнов.

        trigger_node_id: str uuid, default=None
            UUID ноды, из которой запускается автомоделирование

        Returns
        -------
        функция сохраняет параметры в объекте AutoModel и создает запрос на проведение автомоделирования
        в случае, если все проверки прошли успешно, то создается проект моделирования и
        возвращается объект AutoModel

        Examples
        --------
        # Валидация параметров и запуск автомоделирования
        auto_model.run(
            model_version_id=34,
            data=data,
            settings=settings
        )
        """
        if settings is None:
            settings = {}
        permission_data = None
        disable_pv = False
        if is_dict_with_elements(kwargs):
            disable_pv = kwargs.get('disable_pv', False)

        self.check_validation(settings)
        if not self._correct_val_settings:
            return

        if not self._internal_mode:
            permission_data = input(DATA_PERMISSION_MESSAGE)
            assert permission_data.lower() in ["да", "нет", "y", "yes", "n", "no", "not"], "Напишите 'Да' или 'Нет'"
            if permission_data.lower() in ["нет", "n", "no", "not"]:
                print("Согласие не было получено. Автомоделирование не будет запущено. Для уточнения обратитесь по почте mailto:AutoValidation@sberbank.ru, mailto:sberds@omega.sbrf.ru")
                return

        if run_id and self.check_running_settings(run_id=run_id, trigger_node_id=trigger_node_id, settings=settings,
                                                  data=data):
            print('Resume existed project')
            all_params = self._get_all_params(settings, model_version_id, data, resources, trigger_node_id, disable_pv,
                                              validate_settings)
            self._ensure_can_validate()
            self._ensure_authorized()
            user_session = UserSession(self._host, self._session, self._token)

            request = self._create_request(all_params, validate_settings, user_session, permission_data, cpu_only)
            self._create_multiple_prevalidation(request, all_params, run_id, trigger_node_id, check_existed=True)
            return self.get_metrics()

        if self._selected_methods is None:
            return self.run_job(
                model_version_id=model_version_id,
                data=data,
                settings=settings,
                validate_settings=validate_settings,
                resources=resources,
                permission_data=True,
                trigger_node_id=trigger_node_id,
                cpu_only=cpu_only,
                disable_pv=disable_pv
            )

        all_params = self._get_all_params(settings, model_version_id, data, resources, trigger_node_id, disable_pv,
                                          validate_settings)
        self._run_job_all(all_params, validate_settings, permission_data=True, cpu_only=cpu_only)
        return self.get_metrics()

    @return_self()
    @exception_logger(logger=SdsExceptionLogPrinter())
    def _run_job_all(self, all_params: list, validate_settings=False, permission_data=False,
                     cpu_only=False, finance=False):
        self._ensure_can_validate()
        self._ensure_authorized()
        user_session = UserSession(self._host, self._session, self._token)

        request = self._create_request(all_params, validate_settings, user_session, permission_data, cpu_only, finance)
        self._create_multiple_prevalidation(request, all_params)

    def _create_multiple_prevalidation(self, request: list, all_params: list, run_id: str = None,
                                       trigger_node_id: str = None, check_existed: bool = False):
        self._prevalidation = Prevalidation(
            self._get_client(),
            self._host,
            request,
            self._zone,
            self._internal_mode
        )

        if not check_existed:
            self._prevalidation.create_all()
        self._run_id = self._prevalidation.run_id
        self._run_id_dict[self._run_id] = []

        prevalidations_ids = self._prevalidation.get_prevalidations_id(run_id, trigger_node_id)
        lock = threading.Lock()
        threads = [
            threading.Thread(target=self._start_prevalidation, args=(prevalidation_id, params, settings, lock))
            for prevalidation_id, params, settings
            in zip(prevalidations_ids, all_params, request)
        ]

        for thread in threads:
            thread.start()

        for thread in threads:
            thread.join()

        time.sleep(90)

        all_models = list(self._method_prevalidation_map.keys())
        self.stop(all_models, stop_all=True)

    def _start_prevalidation(
            self,
            prevalidation_id: str,
            params: dict,
            settings: dict,
            lock=None
    ):
        lock = lock if lock is not None else contextlib.suppress()
        with lock:

            method = params.get('method', None)
            validate_settings = params.get('validate_settings', False)
            self.select_method(method)

            self._event_service.print_by_method(self._selected_method.info.method_id)
            logger = PrintBarProgress(self.get_job_name())
            self._reset_prevalidation(settings, params, logger, validate_settings, prevalidation_id)

            self._run_id_dict[self._run_id].append(self._prevalidation.prevalidation_id)
            self._method_prevalidation_map[self._prevalidation.prevalidation_id] = self._selected_method.info.name

        self._prevalidation.start(
            method_id=self._selected_method.info.name,
            widget=logger,
            job_name=self.get_job_name(),
            auto_model=True,
            timeout=self._timeout
        )
        return self

    def run_job(self, model_version_id, data, settings: dict, validate_settings=True, resources="7gb1cpu", cpu_only=False, lock=None, method=None, finance=False, permission_data=False, trigger_node_id=None, disable_pv=False):
        """ Валидация параметров и запуск проекта

        Parameters
        ----------
        model_version_id : int
            Идентификатор версии модели в библиотеки моделей

        data : list
            Источники данных и разметка колонок, определяются функцией DataSample
            Артефакты моделирования определяются функцией DataArtifact

        settings : dict [JSON settings of template SberDS]
            Настройки определенные в шаблоне проекта SberDS

        validate_settings : bool
            Проверять ли настройки, введенные пользователем (по умолчанию да)

        resources: str, default='7gb1cpu', если валидатор не задал иных внутри методики
            Ресурсы для запуска узлов моделирования.
            Допустимые значения: строки виде "{N}gb{M}cpu".format(N=N, M=M), где
                N - целое число от 1 до 512, M - целое число, от 1 до 16
            Пример: 32gb8cpu или 128gb2cpu

            Если нужно указать требования только к одному из параметров ресурсов (RAM или CPU), то можно задавать
                каждый из них по отдельности
            Пример: 32gb для RAM или 2cpu для CPU

            При выборе ресурсов, где число CPU > 3 или объем RAM > 7GB, запуск вычислений будет производиться
                в экспериментальном режиме на отдельном кластере, например, могут не показываться логи в realtime
            В случае проблем и непонятных ошибок напишите, пожалуйста, нам через метод auto_validator.create_issue
                или на почту mailto:AutoValidation@sberbank.ru, mailto:sberds@omega.sbrf.ru

        cpu_only: bool, default=False
            Запустить пайплайн на CPU вне зависимости от запрашиваемого GPU-ресурса.
            Подходит только для Any GPU/CPU пайплайнов.

        Returns
        -------
        функция сохраняет параметры в объекте AutoModel и создает запрос на запуск проекта
        в случае, если все проверки прошли успешно, то создается проект моделирования и
        возвращается объект SessionInterface

        Examples
        --------
        # Валидация параметров и запуск проекта
        auto_model.run(
            model_version_id=34,
            data=data,
            settings=settings
        )
        """
        lock = lock if lock is not None else contextlib.suppress()
        with lock:
            self._ensure_can_validate()

            if validate_settings:
                PreValidationSettings.validate_params(model_version_id, self._selected_method, data, settings, finance=finance)

            user_session = UserSession(self._host, self._session, self._token)

            for data_sample in data:
                data_sample.prepare(user_session, method=self._selected_method, event_service=self._event_service)

            self._event_service.print_by_method(self._selected_method.info.method_id)

            logger = PrintBarProgress(self.get_job_name())
            self._create_prevalidation(
                model_version_id, data, settings, validate_settings,
                resources, logger,
                permission_data=permission_data,
                trigger_node_id=trigger_node_id,
                project_id=os.getenv("PROJECT_ID", None),
                disable_pv=disable_pv,
                cpu_only=cpu_only
            )

            if self._run_id is None:
                self._run_id = str(uuid.uuid4())
                self._run_id_dict[self._run_id] = []

            self._run_id_dict[self._run_id].append(self._prevalidation.prevalidation_id)
            self._method_prevalidation_map[self._prevalidation.prevalidation_id] = method

        self._prevalidation.start(
            method_id=method if method is not None else self._selected_method_id, 
            widget=logger, 
            job_name=self.get_job_name(),
            auto_model=True,
            timeout=self._timeout
        )

        return self

    def split_data(
        self,
        train_size: float = 0.8,
        val_size: float = 0.0,
        test_size: float = 0.2,
        stratify: list = "",
        last_train_date: str = "",
        first_test_date: str = ""
    ):
        """ Разбивает трейн выборку на трейн-валид-тест

        Parameters
        ----------
        train_size : float
            Доля выборки для обучающей выборки
        val_size : float
            Доля выборки для обучающей выборки
        test_size : float
            Доля выборки для тестовой выборки
        stratify : list
            Лист с именами колонок для стратификации
        last_train_date : str
            Последняя дата в обучающей выборке
        first_test_date : str
            Первая дата в тестовой выборке

        Returns
        -------
        функция сохраняет параметры разбиения.

        Examples
        --------
        auto_model.split_data(
            train_size=0.8, val_size=0, test_size=0.2, stratify=['target', 'split_col']
        )

        auto_model.split_data(
            last_train_date="2024-01-01"
        )

        auto_model.split_data(
            first_test_date="2024-01-01"
        )
        """
        if (last_train_date is not None and last_train_date != "") or (first_test_date is not None and first_test_date != ""):
            self.split_data_flag = True
            self.split_method = "By date"
            self.last_train_date = last_train_date
            self.first_test_date = first_test_date
        elif not math.isclose(train_size + val_size + test_size, 1, abs_tol=1e-4):
            print("Заданы неверные параметры разбиения. В сумме они должны давать 1. При дальнейшем запуске разбиение производиться не будет.")
            return
        else:
            self.split_data_flag = True
            self.split_method = "Random with stratification" if (stratify is not None and stratify != "") else "Random"
            self.train_size, self.val_size, self.test_size = train_size, val_size, test_size
            self.stratify = str(stratify) if (stratify is not None and stratify != "") else ""

        self.split_settings = {
            "Split": self.split_data_flag,
            "Train Size": self.train_size,
            "Val Size": self.val_size,
            "Test Size": self.test_size,
            "Split Method": self.split_method,
            "Stratify Columns": self.stratify,
            "First Test Date": self.first_test_date,
            "Last Train Date": self.last_train_date
        }

    def set_timeout(self, timeout: int):
        """Глобальный тайм-аут для проектов автомоделирования.
        Если его задать, то незавершенные пайплайны будут оставлены

        Parameters
        ----------
        timeout : int
            Тайм-аут в секундах

        Returns
        -------
        функция сохраняет тайм-аут и передает ее внутри SDK.

        Examples
        --------
        auto_model.set_timeout(
            timeout=1000
        )
        """
        self._timeout = timeout

    def set_inference_type(self, inference_type: str = "mef"):
        """Задание типа инференса модели (mef/pim или online/offline)
        
        Parameters
        ----------
        inference_type : str
            Тип инференса - mef/pim | online/offline

        Returns
        -------
        функция сохраняет тип инференса и передает ее внутри SDK.

        Examples
        --------
        auto_model.set_inference_type(
            inference_type="mef"
        )
        """
        if inference_type.lower() in ["mef", "online", "меф"]:
            self._inference_type = "mef"
        elif inference_type.lower() in ["pim", "offline", "пим"]:
            self._inference_type = "pim"
        else:
            raise ValueError(f"Неизвестный тип инференса {inference_type}. Выберите либо mef, либо pim")

    def select_task(self, task: str):
        """Позволяет выбрать тип ML-задачи для запуска методики автомоделирования
        Parameters
        ----------
        task : str
            Название ML-задачи. Возможны следующие варианты:

            1. Binary - для бинарной классификации
            2. Regression - для регресси
            3. Multiclass - для мультиклассовой классификации
            4. Multilabel - для мультилейбл классификации
            5. Multireg - для мультирегрессии
            6. Uplift - для аплифт моделирования
            7. Time Series - для временных рядов

        Returns
        -------
        функция сохраняет название задачи в объекте AutoModel и передает ее как параметр запуска.

        Examples
        --------
        auto_model.select_task(
            task='Binary'
        )
        """
        if task not in self.available_tasks:
            raise ValueError(f"Selected task is not available. Select one from {self.available_tasks}")
        self.task["Objective"] = task

    def select_metric(self, metric: str, metric_params: dict = None):
        """Позволяет выбрать метрику для запуска методики автомоделирования
        Parameters
        ----------
        metric : str
            Название метрики. Возможные варианты ниже.
        metric_params : dict
            Дополнительные параметры для метрики. Например, для метрики PRECISION@K metric_params={'k': 100}

            1. Для бинарной классификации:
                - ROC_AUC
                - GINI
                - PR_AUC
                - F1_SCORE
                - PRECISION
                - RECALL
                - LOGLOSS
                - BRIER_LOSS
                - ECE
                - ACCURACY
                - PRECISION@K
                - RECALL@K
                - AVERAGE_PRECISION@K
                - REC@SPEC
                - AUCROC@FPR
            2. Для регрессии и временных рядов:
                - MSE
                - RMSE
                - MAE
                - MAPE
                - MDAE
                - MDAPE
                - RMSLE
                - MSLE
                - WAPE
                - SMAPE
                - R2
                - R2_ADJ
                - MAX_ERROR
                - SPEARMAN
                - POWERSTAT
            3. Для мультиклассовой классификации
                - ACCURACY
                - F1_MACRO
                - F1_MICRO
                - F1_WEIGHTED
                - RECALL_MACRO
                - RECALL_MICRO
                - PRECISION_MICRO
                - PRECISION_MACRO
                - ROC_AUC_OVR
                - ROC_AUC_OVO
            4. Для аплифт-моделирования
                - QINI
                - CUM_GAIN
                - ADJ_QINI
                - UPLIFT@K
            5. Для мультилейбл классификации
                - ACCURACY
                - ROC_AUC_OVR
                - ROC_AUC_OVO
                - ROC_AUC_MACRO
                - PRECISION_MACRO
                - PRECISION_MICRO
                - PRECISION_SAMPLES
                - RECALL_MICRO
                - RECALL_MACRO
                - RECALL_SAMPLES
                - F1_MACRO
                - F1_MICRO
                - F1_WEIGHTED
                - F1_SAMPLES
                - HAMMING_ACCURACY
                - GINI_WITH_NANS
                - JACCARD_MACRO
                - JACCARD_MICRO
                - JACCARD_SAMPLES
                - NDCG
                - NDCG@K
                - MAP@K
                - AP@K
                - AVERAGE_RECALL@K
                - MRR
                - COVERAGE_ERROR
                - LABEL_RANKING_LOSS
                - LABEL_RANKING_AVERAGE_PRECISION_SCORE
            6. Для временных рядов
                - MEAN_MAE
                - MEAN_MSE

        Returns
        -------
        функция сохраняет название метрики в объекте AutoModel и передает ее как параметр запуска.
        внутри проходит соответствие метрики и задаче

        Examples
        --------
        auto_model.select_metric(
            metric='ROC_AUC'
        )
        --------
        auto_model.select_metric(
            metric='RECALL@K', metric_params={"k": 10}
        )
        """
        if len(self.task) < 1:
            raise ValueError(f"Firstly, you must select your task.")

        metric = METRIC_MAPPING[metric]
        self.primary_metric = metric

        if self.task["Objective"] == "Binary":
            self.task["Binary Metric"] = metric
        elif self.task["Objective"] in ["Regression", "Time Series"]:
            self.task["Regression Metric"] = metric
        elif self.task["Objective"] == "Multiclass":
            self.task["Multiclass Metric"] = metric
        elif self.task["Objective"] == "Multilabel":
            self.task["Multilabel Metric"] = metric
        elif self.task["Objective"] == "Uplift":
            self.task["Uplift Metric"] = metric
        else:
            self.task["Multiregression Metric"] = metric

        if metric_params is not None:
            self.task["Metric Params"] = metric_params

    @staticmethod
    def setting_dict_checking(fact_set_dict: dict, set_from_sdk: dict) -> dict:
        return {key: fact_set_dict[key] if key in fact_set_dict else set_from_sdk[key] for key in set_from_sdk.keys()}

    @exception_logger(logger=SdsExceptionLogPrinter())
    def check_validation(self, settings):
        """ Валидация параметров для автовалидации

           Parameters
           ----------
           settings : dict [JSON settings of template SberDS]
               Настройки определенные в шаблоне проекта SberDS

        """
        self._correct_val_settings = False

        val_settings = settings.get('Validation Settings', None)
        val_method_name = settings.get('Validation Method Name', None)

        if not val_method_name and not val_settings:
            print('Start without validation settings')
            self._correct_val_settings = True
            return

        elif not val_method_name and val_settings:
            raise SdsSettingsValidationError(message="Incorrect settings for validation: '{}': '{}'"
                                             .format(val_method_name, val_settings),
                                             advice='Set Validation Method Name and settings, or remove them')
        if val_method_name:
            self._ensure_authorized()
            validation_method = self._method_service.get_method_info(val_method_name)
            if not validation_method.settings.get('groups') and val_settings:
                raise SdsSettingsValidationError(message="This method don't need validation settings: '{}': '{}'"
                                                 .format(val_method_name, val_settings),
                                                 advice='Remove validation settings')
            elif validation_method.settings.get('groups') and val_settings:
                if not isinstance(val_settings, dict):
                    print('Try to get settings from string')
                    try:
                        val_settings = json.loads(val_settings.replace("*", "").replace("\'", "\""))
                    except json.decoder.JSONDecodeError:
                        print("Json Decoder error. Try simple json.loads")
                        val_settings = json.loads(val_settings)
                    except AttributeError:
                        raise SdsParamValidationError(param="Validation settings",
                                                      advice="Check your validation settings. Need to be JSON serializable")
                if not isinstance(val_settings, dict):
                    raise SdsParamValidationError(param="Validation settings",
                                                  advice="Check your validation settings need to be 'dict' "
                                                         "after JSON serialization")

                PreValidationSettings.check_setting(validation_method.settings, val_settings)
                print('All validation parameters are correct')
            else:
                print('Start with common validation settings')

            self._correct_val_settings = True

    def _get_all_params(self, settings, model_version_id, data,
                       resources, trigger_node_id, disable_pv, validate_settings):
        all_params = []
        for method_model in self._selected_methods.methods:

            settings_copy = deepcopy(settings)
            if method_model.settings["groups"] is None:
                settings_copy = {}
            else:
                settings_copy = {} if isinstance(settings_copy, str) else settings_copy
                settings_copy = {**settings_copy, **self.task}
                settings_copy = {**settings_copy, **self.split_settings}
                settings_copy = self._add_common_val_method(settings_copy, method_model.info.name)
                settings_copy = self.setting_dict_checking(settings_copy, eval(
                    method_model.get_settings_json(method_model.settings).replace('settings=', ''))
                    )

            print(f"Method: {method_model.info.name} with settings={settings_copy}")
            print()

            all_params.append({
                'method_model': self._selected_methods.get_method(method_model.info.name),
                'method': method_model.info.name,
                'model_version_id': model_version_id,
                'data': data,
                'settings': settings_copy,
                'resources': resources,
                'trigger_node_id': trigger_node_id,
                'project_id': os.getenv("PROJECT_ID", None),
                'disable_pv': disable_pv,
                'validate_settings': validate_settings,
            })
        return all_params

    def _create_request(self, all_params, validate_settings, user_session, permission_data, cpu_only, finance=False):
        request = []
        for params in all_params:
            model_version_id = params.get('model_version_id', 0)
            data = params.get('data', [])
            settings = params.get('settings', {})
            resources = params.get('resources', None)
            trigger_node_id = params.get('trigger_node_id', None)
            project_id = params.get('project_id', None)
            disable_pv = params.get('disable_pv', False)
            method_id = params.get('method_id', None)
            method_model = params.get('method_model', None)

            if validate_settings:
                PreValidationSettings.validate_params(model_version_id, method_model, data, settings,
                                                      finance=finance)
            for data_sample in data:
                data_sample.prepare(user_session, method=method_model, event_service=self._event_service)

            request.append(PreValidationConverter.convert_to_transport(
                model_version_id,
                method_model.info.method_id if method_id is None else method_id,
                data, settings, validate_settings,
                resources,
                trigger_node_id=trigger_node_id,
                permission_data=permission_data,
                project_id=project_id,
                cpu_only=cpu_only,
                disable_pv=disable_pv))

        return request

    def get_metrics(self, modeling_id: str = None, run_id = None, method_id: str = None):
        """
        Возвращает таблицу с метриками

        Parameters
        ----------

        modeling_id : str
            идентификатор автомоделирования
        run_id : str или dict
            идентификатор запуска автомоделирования
        method_id : str
            название методики, которая запускалась

        Returns
        -------

        функция возвращает таблицу со всеми метриками
        """
        metric_list = []

        if modeling_id is not None:
            metric_list.append(self._get_metric(modeling_id))

        if run_id is not None and isinstance(run_id, str):
            for modeling_id in self._run_id_dict[run_id]:
                metric_list.append(self._get_metric(modeling_id))
        
        elif run_id is not None and isinstance(run_id, list):
            for run in run_id:
                for modeling_id in self._run_id_dict[run]:
                    metric_list.append(self._get_metric(modeling_id))

        elif run_id is not None and isinstance(run_id, dict):
            for prevalidation_list in run_id.values():
                for modeling_id in prevalidation_list:
                    metric_list.append(self._get_metric(modeling_id))

        if method_id is not None:
            prevalidation_list = [key for key, value in self._method_prevalidation_map.items() if value == method_id]
            for modeling_id in prevalidation_list:
                    metric_list.append(self._get_metric(modeling_id))

        if modeling_id is None and run_id is None and method_id is None:
            for prevalidation_list in self._run_id_dict.values():
                for modeling_id in prevalidation_list:
                    metric_list.append(self._get_metric(modeling_id))

        values = []
        for row in metric_list:
            if row is not None:
                values.append(list(row.values()))

        st = SimpleTable(values, METRIC_COLS, max_width=80)
        return st

    def _get_metric(self, modeling_id: str):
        paused_comment = "Проект поставлен на паузу"
        error_comment = "Проект выполнен с ошибкой"
        running_comment = "Проект еще выполняется"
        zone_comment = "Доступно в зоне null"
        metrics_sample_names = [
            "train_metric_baseline", "train_metric_automodel", "train_metric_prom_score",
            "val_metric_baseline", "val_metric_automodel", "val_metric_prom_score",
            "out_of_sample_metric_baseline", "out_of_sample_metric_automodel", "out_of_sample_metric_prom_score",
            "out_of_time_metric_baseline", "out_of_time_metric_automodel", "out_of_time_metric_prom_score",
        ]

        results = self._get_status_request(modeling_id)
        metric_dict = {}

        metric_dict['method'] = results['method_key']
        metric_dict["project_url"] = results["project_url"]
        metric_dict['modeling_id'] = results['prevalidation_id']
        metric_dict['metric_name'] = self.primary_metric
        
        ## TODO: fix links for different types of benches
        metric_dict['inference_link'] = (
            INFERENCE_LINKS
            .get("prom", {})
            .get(results.get('method_key', ''), {})
            .get(self._inference_type)
        )

        if results["status"] in ["TECHNICAL_PAUSED", "PAUSED"]:
            
            for name in metrics_sample_names:
                metric_dict[name] = paused_comment
            metric_dict['main_traffic_light'] = paused_comment
            metric_dict['automodel_traffic_light'] = paused_comment
            metric_dict['comparison_traffic_light'] = paused_comment
            metric_dict['altmod_stat_worse'] = paused_comment
            metric_dict['validation_url'] = paused_comment
            metric_dict['autorefit_info'] = paused_comment
            metric_dict["automodel_pkl_location"] = paused_comment
            metric_dict["prevalidation_id"] = paused_comment

        elif results["status"] == "ERROR":

            for name in metrics_sample_names:
                metric_dict[name] = error_comment
            metric_dict['main_traffic_light'] = error_comment
            metric_dict['automodel_traffic_light'] = error_comment
            metric_dict['comparison_traffic_light'] = error_comment
            metric_dict['altmod_stat_worse'] = error_comment
            metric_dict['validation_url'] = error_comment
            metric_dict['autorefit_info'] = error_comment
            metric_dict["automodel_pkl_location"] = error_comment
            metric_dict["prevalidation_id"] = error_comment

        elif results["status"] == "RUNNING":

            for name in metrics_sample_names:
                metric_dict[name] = running_comment
            metric_dict['main_traffic_light'] = running_comment
            metric_dict['automodel_traffic_light'] = running_comment
            metric_dict['comparison_traffic_light'] = running_comment
            metric_dict['altmod_stat_worse'] = running_comment
            metric_dict['validation_url'] = running_comment
            metric_dict['autorefit_info'] = running_comment
            metric_dict["automodel_pkl_location"] = running_comment
            metric_dict["prevalidation_id"] = running_comment

        elif results["status"] in ["DONE", "PUBLISHED"]:

            if results["mtl_info"]["rawValue"] == "Доступно в зоне null":
                for name in metrics_sample_names:
                    metric_dict[name] = zone_comment
                metric_dict['main_traffic_light'] = zone_comment
                metric_dict['automodel_traffic_light'] = zone_comment
                metric_dict['comparison_traffic_light'] = zone_comment
                metric_dict['altmod_stat_worse'] = zone_comment
                metric_dict['validation_url'] = zone_comment
                metric_dict['autorefit_info'] = zone_comment
                metric_dict["automodel_pkl_location"] = zone_comment
                metric_dict["prevalidation_id"] = zone_comment
            else:
                try:
                    metric_dict['main_traffic_light'] = results['mtl_info']['rawValue']['tl_value']["autovalidation_info"]["value"]
                    metric_dict['automodel_traffic_light'] = results['mtl_info']['rawValue']['tl_value']["autovalidation_info"]["results_aggregator_check_altmod"]
                    metric_dict['comparison_traffic_light'] = results['mtl_info']['rawValue']['tl_value']["autovalidation_info"]["model_comparison"]
                    metric_dict['altmod_stat_worse'] = results['mtl_info']['rawValue']['tl_value']["autovalidation_info"]["altmod_stat_worse"]
                    metric_dict['validation_url'] = results['mtl_info']['rawValue']['tl_value']["autovalidation_info"]["url"]
                    metric_dict['autorefit_info'] = results['mtl_info']['rawValue']['tl_value']["autovalidation_info"]["autorefit_info"]
                    metric_dict["automodel_pkl_location"] = results['mtl_info']['rawValue']['tl_value']['automodel_pkl_location']
                    metric_dict["prevalidation_id"] = results['mtl_info']['rawValue']['tl_value']["autovalidation_info"]['prevalidation_id']
                except:
                    metric_dict['main_traffic_light'] = "gray"
                    metric_dict['automodel_traffic_light'] = "gray"
                    metric_dict['comparison_traffic_light'] = "gray"
                    metric_dict['altmod_stat_worse'] = False
                    metric_dict['validation_url'] = "Ссылка недоступна"
                    metric_dict['autorefit_info'] = "Данные по дообучению не были получены"
                    metric_dict["automodel_pkl_location"] = "Путь до pkl-файла модели недоступен"
                    metric_dict["prevalidation_id"] = "prevalidation_id недоступен"
                for metric in results['mtl_info']['rawValue']['tl_value']['automodeling_metrics']:
                    metric_dict[f"{metric['sample_name']}_metric_baseline"] = metric['baseline_metric_value']
                    metric_dict[f"{metric['sample_name']}_metric_automodel"] = metric['primary_metric_value']
                    metric_dict[f"{metric['sample_name']}_metric_prom_score"] = metric['prom_metric_value']

                for name in metrics_sample_names:
                    if name not in metric_dict:
                        metric_dict[name] = "None"

        metric_dict = sorted(metric_dict.items(), key=lambda pair: METRIC_COLS.index(pair[0]))
        me_d = {}
        for val in metric_dict:
            me_d[val[0]] = val[1]

        return me_d

    @exception_logger(logger=SdsExceptionLogPrinter())
    def get_status(self, modeling_id):
        """Показать всю информацию по одному автомоделированию запущенному пользователем,

        Если автомоделирование не исполнено, то функция будет запрашивать статус до
        тех пор пока процесс автомоделирования остается в статусе RUNNING


        Parameters
        ----------

        modeling_id : str
        идентификатор автомоделирования


        Returns
        -------

        функция возвращает информацию по автомоделированию

        create_date : str
            дата время создания проекта автомоделирования
        update_date : str
            дата время последнего изменения статуса автомоделирования (если
            автомоделирование завершено, то дата завершения автомоделирования)
        modeling_id : str
            идентификатор автомоделирования (является параметром для функций
             get_status или stop)
        method_key : str
            идентификатор методики автомоделирования
        model_version_id : str
            идентификатор из БМ
        project_url : str
            ссылка на проект SberDS
        report_url : str
            ссылка на отчет SberDS
        status : str
            пользовательский статус автомоделирования (RUNNING - автомоделирование в
            процессе исполнения,  PAUSED - пользователь остановил автомоделирование,
            TECHNICAL_PAUSED - автомоделирование преостановлена на время инцидента,
            DONE или ERROR - финальные статусы)
        main_traffic_light : str
            итоговый светофор
        error : json
            сообщение об ошибке (если автомоделирование не завершилась успешно и не
            создан итоговый отчет)
        project_node_errors: list
            список ошибок исполнения нод проекта
        samples : list
            путь к источнику данных, типы выборок, разметка колонок, указанные
            при запуске автомоделирования
        settings : list
            дополнительные настройки шаблона автомоделирования, указанные при
            запуске автомоделирования


        Examples
        --------

        auto_model.get_status(modeling_id='65e92db8-7cd4-4cf4-95fa-adc00e61d6b1')
        """
        self._do_get_status(prevalidation_id=modeling_id, auto_model=True)

    @exception_logger(logger=SdsExceptionLogPrinter())
    def create_issue(self, description: str, subject: str = 'Auto_Model'):
        """ Отправить отчет об ошибке.

        Загрузка данных K1 и K2 запрещена.


        Parameters
        ----------
        description : str
            Описание ошибки в свободной форме.

        subject : str
            Классификатор ошибок, указать: Auto_Model


        Returns
        -------
        issueId идентификатор обращения


        Examples
        --------
        auto_model.create_issue('Описание ошибки', 'Auto_Model')

        """
        super().create_issue(description, subject)

    @exception_logger(logger=SdsExceptionLogPrinter())
    def get_modeling(self, model_version_id=None, status=None, date_to=None, date_from=None, limit=200):
        """Показать основную информацию по автомоделированиям, запущенным
        пользователем (проверка пользователя по login), сортировка по дате
        создания от последнего созданного к более ранним


        Parameters
        ----------

        model_version_id : str, list, опциональный параметр
            идентификатор из БМ или список идентификаторов
        status : str, list, опциональный параметр
            статус процесса автомоделирования
            доступные варианты: RUNNING, DONE, ERROR, PAUSED, TECHNICAL_PAUSED
        date_to : str, datetime-like, в формате "YYYY-MM-DD", опциональный параметр
            дата для фильтрации выборки, дата после которой автомоделирования не попадут в выборку
        date_from : str, datetime-like, в формате "YYYY-MM-DD", опциональный параметр
            дата для фильтрации выборки, дата до которой автомоделирования не попадут в выборку
        limit : int, опциональный параметр
            количество автомоделирований в выборке, по умолчанию limit=200


        Returns
        -------

        функция возвращает информацию по автомоделированию:

        create_date : str, datetime-like
            дата время создания автомоделирования
        update_date : str, datetime-like
            дата время последнего изменения статуса автомоделирования (если
            автомоделирование завершено, то дата завершения автомоделирования)
        prevalidation_id : str
            идентификатор автомоделирования (является параметром для функций
            get_status или stop)
        method_key : str
            идентификатор методики автомоделирования
        model_version_id : str
            идентификатор из БМ
        project_url : str
            ссылка на проект SberDS
        report_url : str
            ссылка на отчет SberDS
        status : str
            пользовательский статус автомоделирования (RUNNING - автомоделирование в
            процессе исполнения,  PAUSED - пользователь остановил автомоделирование,
            TECHNICAL_PAUSED - автомоделирование преостановлено на время инцидента,
            DONE или ERROR - финальные статусы)
        main_traffic_light : str
            итоговый светофор
        error_message : str
            сообщение об ошибке (если автомоделирование не завершилось успешно и не
            создан итоговый отчет)

        Examples
        --------

        auto_model.get_modeling(model_version_id=['34','123']) - функция
            вернет общую информацию по 200 последним автомоделированиям, запущенным
            пользователем, для которых model_version_id = '34' или  model_version_id = '123',
            сортировка по дате создания (сначала новые потом старые)
        """
        return super()._get_jobs(model_version_id, status, date_to, date_from, limit)

    def check_pipline(self, selected_methods):
        if self.task and 'Objective' in self.task:
            chosen_task = self.task['Objective']
        else:
            for method in selected_methods:
                task_categories = []
                for task_name, category in METHOD_TASKS.items():
                    if method in category:
                        task_categories.append(task_name)
                if len(task_categories) == 1:
                    chosen_task = task_categories[0]
                    break
            else:
                return True

        if chosen_task:
            for method in selected_methods:
                if method not in METHOD_TASKS[chosen_task]:
                    print(f"Wrong methods list, method {method} not in {chosen_task} task")
                    return False
            else:
                return True
