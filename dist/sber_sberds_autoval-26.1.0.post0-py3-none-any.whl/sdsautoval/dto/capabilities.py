from sdsautoval.clui.interfaces import TableView


def parse_configuration(item):
    return Configuration(project_area_id=item['project_area_id'], cpu=item['cpu'], ram=item['ram'], gpu=item['gpu'])


def parse_project_area(item):
    return ProjectArea(item['id'], item['name'])


def parse_project_areas(json: list):
    result = list()
    for item in json:
        result.append(parse_project_area(item))
    return result


def parse_configurations(json: list):
    result = list()
    for item in json:
        result.append(parse_configuration(item))
    return result


class ProjectArea(object):
    def __init__(self, _id, name):
        self.id = _id
        self.name = name

    def __str__(self):
        return self.__repr__()

    def __repr__(self):
        return str(self.name) + ' (' + str(self.id) + ')'

    def to_dict(self):
        return {'id': self.id, 'name': self.name}


class Configuration(object):
    def __init__(self, project_area_id=None, cpu=None, ram=None, gpu=False):
        self.project_area_id = project_area_id
        self.cpu = cpu
        self.ram = ram
        self.gpu = gpu

    def __str__(self):
        return self.__repr__()

    def __repr__(self):
        return str(self.cpu) + 'cpu' + str(self.ram) + 'gb' + self.gpu_str()

    def to_dict(self):
        return {'project_area_id': self.project_area_id, 'cpu': self.cpu, 'ram': self.ram, 'gpu': self.gpu}

    def gpu_str(self):
        if self.gpu:
            return 'gpu'
        return ''


class CapabilitiesList(TableView):
    def __init__(self, json=None):
        self.project_areas = parse_project_areas(json['project_areas'])
        self.configurations = parse_configurations(json['configurations'])
        self.project_areas_by_id = self.arrange_project_areas_by_id()
        self.configurations_by_project_area = self.arrange_by_project_area_id()

    def arrange_project_areas_by_id(self):
        project_areas = dict()
        for project_area in self.project_areas:
            project_areas[project_area.id] = project_area
        return project_areas

    def arrange_by_project_area_id(self):
        configurations_by_project_area = dict()
        for configuration in self.configurations:
            tmp = configurations_by_project_area.get(configuration.project_area_id, [])
            tmp.append(configuration)
            configurations_by_project_area[configuration.project_area_id] = tmp
        return configurations_by_project_area

    def to_table_list(self, columns):
        result = list()
        l = sorted(self.project_areas_by_id.items(), key=lambda i: i[1].name)
        for project_area_id, project_area in l:
            configurations = self.configurations_by_project_area.get(project_area_id)
            project_area = self.project_areas_by_id[project_area_id]
            for config in configurations:
                tmp = dict()
                self.append_column(columns, tmp, 'project_area_name', project_area.name)
                self.append_column(columns, tmp, 'project_area_id', project_area.id)
                self.append_column(columns, tmp, 'cpu', self.cpu(config))
                self.append_column(columns, tmp, 'ram', self.ram_gb(config))
                self.append_column(columns, tmp, 'gpu', config.gpu)
                item = list()
                for column in columns:
                    item.append(tmp.get(column, '-'))
                result.append(item)
        return result

    def ram_gb(self, config):
        if config.ram:
            return str(config.ram) + ' GB'
        return 'N/A'

    def cpu(self, config):
        if config.cpu:
            return str(config.cpu) + ' CPU'
        return 'N/A'

    def append_column(self, columns, item, key, value):
        if key in columns:
            item[key] = value


    def to_table(self):
        columns = ['project_area_name', 'cpu', 'ram', 'gpu']
        print_columns = ['Проектная область', 'CPU', 'RAM', 'GPU']
        from sdsautoval.util import SimpleTable
        return SimpleTable(self.to_table_list(columns), print_columns)
