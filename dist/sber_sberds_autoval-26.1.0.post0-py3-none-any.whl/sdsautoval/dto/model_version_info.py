from sdsautoval.utils.dto import EazyDto
from sdsautoval.utils.text import substitute_block_names


class ModelVersionInfo(EazyDto):
    """ Информация о модели.

    Attributes:
        model_version_id             ID версии модели
        data_type                    Тип данных
        task_type                    Тип задачи
        modeling_method              Метод моделирования
        weights_in_command_space     Ссылка на веса модели в командном пространстве
        model_code_bitbucket         Ссылка на код модели в BitBucket
        artifacts_repository_bb      Ссылка на репозиторий, содержащий артефакты в Bitbucket
        branch_bitbucket             Ветка репозитория, содержащего артефакты в Bitbucket
        model_code_refit_bb          Ссылка на репозиторий, содержащий артефакты код дообучения модели в Bitbucket
        model_code_refit_branch_bb   Ветка репозитория, содержащего код дообучения в Bitbucket
        pkl_link                     Ссылка на prod-репозиторий в MLStorage (.pkl)
        data_set_link                Ссылка на датасеты в MLStorage
        model_version_status         Статус версии модели
        developer_block              Наименование блока разработчиков
        cds_block                    Наименование блока центра валидации
        importance_umr               Степень значимости
        new_importance_umr           Новая степень значимости
        feature_store_id             ID проекта в FeatureStore
    """

    def __init__(self, data=None):
        super(ModelVersionInfo, self).__init__(data)

    @classmethod
    def from_dict(cls, data):
        return cls(
            data
        )

    def header(self):
        return ['Название параметра', 'Значение']

    def field_descriptions(self):
        return {
            'model_version_id': 'ID версии модели',
            'data_type': 'Тип данных',
            'task_type': 'Тип задачи',
            'modeling_method': 'Метод моделирования',
            'weights_in_command_space': 'Ссылка на веса модели в командном пространстве',
            'model_code_bitbucket': 'Ссылка на код модели в BitBucket',
            'artifacts_repository_bb': 'Ссылка на репозиторий, содержащий артефакты в Bitbucket',
            'branch_bitbucket': 'Ветка репозитория, содержащего артефакты в Bitbucket',
            'model_code_refit_bb': 'Ссылка на репозиторий, содержащий артефакты код дообучения модели в Bitbucket',
            'model_code_refit_branch_bb': 'Ветка репозитория, содержащего код дообучения в Bitbucket',
            'pkl_link': 'Ссылка на prod-репозиторий в MLStorage (.pkl)',
            'data_set_link': 'Ссылка на датасеты в MLStorage',
            'model_version_status': 'Статус версии модели',
            'developer_block': 'Наименование блока разработчиков',
            'cds_block': 'Наименование блока центра валидации',
            'importance_umr': 'Степень значимости',
            'new_importance_umr': 'Новая степень значимости',
            'feature_store_id': 'ID проекта в FeatureStore',
            'ensemble_driver': 'ID модели драйвера',
            'ensemble_calibration': 'ID модели калибровки',
            'ensemble_link_ensemble': 'ID связанной интегральной модели',
        }

    def field_display(self, key, value):
        return super().field_display(key, substitute_block_names(key, value))
