import html
import io
import json
from collections import UserList
from uuid import UUID

from .modprop import DataSample, DataConnection, ColumnsSelector, DataArtifact
from .utils.args import is_dict_with_elements as is_dict_with_elements

SUMMARY_CSS = '''
            <script>
                function closeDetail(detailsElement) {
                    detailsElement.removeAttribute("open");
                    window.location = '#' + detailsElement.id;
                }
            </script>
            <style>
                summary {
                    text-decoration: underline;
                }                 
                details summary {
                    visibility: visible;
                }
                ::marker{ display:none; } summary{ list-style: none }
                details[open] > summary > .summary-text {
                    display: inline;
                }  
                details[open] > summary {                                                            
                }
                details[open] > summary > .summary-text {
                    display: none;
                }                
                summary:after {
                   content: "... Показать больше";
                   font-weight: bold;
                   margin: -5px 5px 0 0;
                 
                }
                details[open] > summary:after {
                   content: "Свернуть";
                   font-weight: bold;   
                   margin: -5px 5px 0 0;
                   display: inline-block;
                }
                .summary-close-button {
                    text-color:inherit;                    
                    border:none;
                    background:none;
                    outline:none;
                    font-weight: bold;
                    margin:0;
                    padding:0;
                }                                
            </style>
            '''


def make_list(value):
    if value is None:
        return None
    else:
        if type(value) is list:
            return value
        else:
            return [value]


def pretty_json(json_value):
    return json.dumps(json_value, indent=4, ensure_ascii=False)


def json_to_ld_datasource(json):
    if is_dict_with_elements(json):
        return DataConnection(host=json['host'], schema=json['schemaName'], port=json['port'])
    else:
        return None


def json_to_columns_selector(json, default_role, default_type):
    if json:
        columns = ColumnsSelector(default_role, default_type)
        for c in json:
            columns.add(columns=c['name'], role=c['role'], column_type=c['type'])
        return columns

    return None


def _convert_sample_type(sample_type: str):
    if sample_type:
        return sample_type.lower()
    return sample_type


def json_to_datasample(json):
    _type = json['type']
    if _type == 'sample':
        return DataSample(key=json['key'],
                          sql=json['sql'],
                          file=json['file'],
                          selector=json_to_columns_selector(json['columns'], json['defaultRole'], "auto"),
                          connection=json_to_ld_datasource(json['connection']))
    elif _type == 'artifact':
        return DataArtifact(key=json['key'],
                            file=json['file'],
                            connection=json_to_ld_datasource(json['connection']))
    else:
        raise ValueError(f'Unknown data sample type {_type}')


def json_to_datasamples(json):
    datasamples = []
    if json is not None:
        for ds in json:
            datasamples.append(json_to_datasample(ds))
    return datasamples


def print_table(table, columns, max_width=60):
    print(text_table(table, columns, max_width))


def text_table(table, columns, max_width=60):
    return PrintTable(table, columns, ).print_table(max_width)


class CellDisplayStyle:
    def __init__(self, max_characters: int = -1, ):
        self.max_characters = max_characters

    def process_content(self, content: str) -> str:
        if self.max_characters > 3:
            if len(content) > self.max_characters:
                content = content[:self.max_characters - 3] + '...'
        return content


class TableDisplayStyle:
    def __init__(self, cell_style: CellDisplayStyle = CellDisplayStyle()):
        self.cell_style = cell_style


class SimpleTable:
    def __init__(self,
                 table: list,
                 columns,
                 max_width=60,
                 display_style: TableDisplayStyle = TableDisplayStyle()):
        self.table = table
        self.columns = columns
        self.max_width = max_width
        self.display_style = display_style

    def filter_empty(self):
        keep_index = []
        for row in self.table:
            if isinstance(row, list):
                for i in range(len(row)):
                    if row[i] is not None and i not in keep_index:
                        keep_index.append(i)
        if len(keep_index) <= 0:
            return self
        keep_columns = []
        for i in keep_index:
            keep_columns.append(self.columns[i])
        return self.filter(keep_columns=keep_columns)

    def replace_empty(self, replacement='-'):
        for row in self.table:
            if isinstance(row, list):
                for i in range(len(row)):
                    if row[i] is None:
                        row[i] = replacement
        return self

    def filter(self, keep_columns):
        if keep_columns is None or len(keep_columns) <= 0:
            return self
        keep_index = []
        new_columns = []
        for i in range(0, len(self.columns)):
            if self.columns[i] in keep_columns:
                keep_index.append(i)
                new_columns.append(self.columns[i])
        new_table = []
        for row in self.table:
            new_row = []
            for i in range(0, len(row)):
                if i in keep_index:
                    new_row.append(row[i])
            new_table.append(new_row)
        return SimpleTable(new_table, new_columns, self.max_width, display_style=self.display_style)

    @staticmethod
    def from_records(records, columns):
        array = []
        for record in records:
            row = []
            for col in columns:
                if col in record.keys():
                    row.append(record[col])
                else:
                    row.append(None)
            array.append(row)

        return SimpleTable(array, columns)

    def __repr__(self):
        return text_table(self.table, self.columns, self.max_width)

    def __len__(self):
        if self.table:
            return len(self.table)
        else:
            return 0

    def __getitem__(self, key):
        values = self.table[key]
        if values:
            return dict(zip(self.columns, values))
        else:
            return None

    def _ipython_display_(self):
        self.ipython_display()

    def ipython_display(self):
        from IPython.core.display import HTML
        from IPython.display import display
        display(HTML(_render_html(self)))

    def to_dataframe(self):
        from pandas import DataFrame
        return DataFrame(self.table, columns=self.columns)

    def to_print_table(self):
        return PrintTable(self.table, self.columns)


class PrintTable:

    def __init__(self, table, columns):
        self.max_width = 60
        # Символы переноса строк.
        self.table = table
        self.columns = columns
        self.col_space = '  '
        self.col_trim = '...'
        self.pref = ' '
        self.postf = ''

    def print_table(self, max_width=None) -> str:
        """
        Напечатать таблицу.
        """
        out = io.StringIO()
        try:
            self.max_width = max_width if max_width is not None else self.max_width
            # Найти ширину каждого столбца.
            col_width = self._find_col_widths()
            # Напечатать названия столбцов.
            self._print_columns(out, col_width)
            # Напечатать содержимое столбцов с учётом "\n"
            self._print_data(out, col_width)
            return out.getvalue()
        finally:
            out.close()

    def _split_long_sentence2(self, width: int, value: object):
        line = str(value)
        if len(line) <= width:
            return [line]

        first = True
        c_width = width - len(self.postf)
        lines = []
        index = 0
        part = ''

        while True:
            if index >= len(line):
                if not first:
                    part = self.pref + part

                lines.append(part)
                break

            c = line[index]
            index += 1
            if c == '\n':
                lines.append(part)
                part = ''
                first = True
                continue

            part += c

            if len(part) >= c_width:
                if not first:
                    part = self.pref + part
                else:
                    first = False

                c_width = width - len(self.pref) - len(self.postf)
                lines.append(part + self.postf)
                part = ''
                continue

        return lines

    def _find_col_widths(self):
        """
        Определить максимальную ширину столбца.
        """
        col_width = dict()
        for col_index, col in enumerate(self.columns):
            col_width[col_index] = min(len(col), self.max_width)
            for row in self.table:
                lines = str(row[col_index]).split("\n")
                width = len(max(lines, key=lambda x: len(x)))
                if col_width[col_index] < width < self.max_width:
                    col_width[col_index] = width
                elif width >= self.max_width:
                    col_width[col_index] = self.max_width
        return col_width

    def _print_columns(self, file, col_width: dict):
        """
        Напечатать названия столбцов.
        """
        ret = ""
        for col_index, col in enumerate(self.columns):
            tmp = col
            if len(col) > col_width[col_index]:
                tmp = col[:col_width[col_index] - len(self.col_trim)] + self.col_trim
            print("{0:<{1}}".format(tmp, col_width[col_index]), end=self.col_space, file=file)
        print(file=file)

        for col_index in range(len(self.columns)):
            print("-" * col_width[col_index], end=self.col_space, file=file)
        print(file=file)

    def _print_data(self, file, col_width: dict):
        """
        Напечатать содержимое таблицы.
        """
        for row in self.table:
            row_parts = dict()
            max_lines = self._split_row_to_parts(row, row_parts, col_width)

            for depth in range(max_lines):
                for col_index, col in enumerate(self.columns):
                    col_ = row_parts[col_index]
                    if depth >= len(col_):
                        line = ''
                    else:
                        line = col_[depth]

                    if len(line) > col_width[col_index]:
                        line = line[:col_width[col_index] - len(self.col_trim)] + self.col_trim

                    print("{0:<{1}}"
                          .format(line, col_width[col_index]), end=self.col_space, file=file)
                print(file=file)

    def _split_row_to_parts(self, row, row_parts: dict, col_width: dict) -> []:
        """
        Разбивает строку на столбцы по длинам столбцов.
        Если строка длиннее ширины столбца, разделяет строку.
        Возвращает максимальное число строк в столбце.
        """
        max_lines = 0

        for col_index in range(len(self.columns)):
            row_parts[col_index] = self._split_long_sentence2(col_width[col_index], row[col_index])

            if len(row_parts[col_index]) > max_lines:
                max_lines = len(row_parts[col_index])

        return max_lines


def _render_html(table: SimpleTable):
    return _DisplayTable(table, style=table.display_style).to_html_string()


class _DisplayTable:

    def __init__(self, table: SimpleTable, style: TableDisplayStyle = TableDisplayStyle()):
        self.table = table
        self.style = style

    """
    Преобразует таблицу в HTML-таблицу и печатет её с помощью display().

    Если функции display() нет, выдаёт ошибку.
    """

    def to_html_string(self):
        """
        Создаёт строку формата html из таблицы.
        """
        data = self.table.table
        column_heads = self.table.columns
        css = SUMMARY_CSS
        out = css + \
              '<div class="output_subarea output_html rendered_html" dir="auto">'
        out += self._styles()
        out += '<table border="1" class="dataframe">'

        if column_heads is not None:
            out += '<thead>'
            out += self._row_to_html(row=column_heads, tag="th")
            out += '</thead>'

        non_truncate_idx = list()
        for i, v in enumerate(column_heads):
            if v == 'description':
                non_truncate_idx.append(i)

        # Добавить записи.
        out += '<tbody>'
        for i, row in enumerate(data):
            out += self._row_to_html(row=row, tag="td", non_truncate_idx=non_truncate_idx)
        out += '</tbody>'

        out += '</table>'
        out += '</div>'
        return out

    def _row_to_html(self, row: [], tag: str, style="", th_value=None, non_truncate_idx=None):
        """
        Преобразует список к строке таблицы, где каждый элемент списка это запись.
        """
        if non_truncate_idx is None:
            non_truncate_idx = []
        out = f'<tr {style}>'
        if th_value is not None:
            out += f'<th>{html.escape(th_value)}</th>'

        for i, cell in enumerate(row):
            if isinstance(cell, HtmlItem):
                cell = cell.html()
            else:
                cell = str(cell)
                if i not in non_truncate_idx:
                    cell = self.truncate_cell(cell)
                    cell = '<br>'.join(html.escape(str(cell)).split('\n'))
                else:
                    cell = '<br>'.join(str(cell).split('\n'))
            out += f'<{tag}>{cell}</{tag}>'

        out += "</tr>"
        return out

    # noinspection PyMethodMayBeStatic
    def _styles(self):
        """
        Инициализирует стили таблицы.
        """
        return """
            <style scoped="">
                .dataframe tbody tr th:only-of-type {
                    vertical-align: middle;
                }

                .dataframe tbody tr th {
                    vertical-align: top;
                }
                
                .dataframe tbody tr td {
                    text-align: left;
                }

                .dataframe thead th {
                    text-align: left;
                }
                .spoiler >  input + .box {
                    display: none;
                }
                .spoiler >  input:checked + .box {
                    display: block;
                }
.spoiler >  input + .box > blockquote{
    display: none;
}
.spoiler >  input:checked + .box > blockquote {
    display: block;
}
.spoiler >  input[type="checkbox"] {
    cursor: pointer;
    border-color:transparent!important;
    border-style:none!important;
    background:transparent none!important;
    position:relative;z-index:1;
    margin:-10px 0 -30px -230px;
}                
.spoiler span.close {
	padding-left:22px;
	text-decoration: underline;
}
.spoiler span.open {
	padding-left:22px;
	text-decoration: underline;
}
.spoiler >  input +  .box > span.close {
	display: none;
}
.spoiler >  input:checked +  .box > span.close {	
	background: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='0.8em' font-size='100'>-</text></svg>"); 4px 60% no-repeat;
	display: inline;
}
.spoiler >  input:checked  + .box > span.open {
	display: none;
}
.spoiler >  input +  .box >  span.open {
	background: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='0.8em' font-size='100'>+</text></svg>"); 4px 60% no-repeat;
	display: inline;
}
            </style>
        """

    def truncate_cell(self, cell):
        if self.style.cell_style:
            cell = self.style.cell_style.process_content(cell)
        return cell


class HtmlHelper:

    @staticmethod
    def escape(value):
        if value is None:
            return ''
        else:
            return html.escape(str(value))


class HtmlItem:
    def html(self):
        return 'HtmlItem'

    def __str__(self):
        return self.html()

    def __repr__(self):
        return self.html()


class HRef(HtmlItem):
    def __init__(self, text, url):
        self.url = url
        self.text = text

    def html(self):
        if self.url is None:
            return HtmlHelper.escape(self.text)
        text = self.text
        if text is None:
            text = self.url
        return f'<a href="{self.url}">{HtmlHelper.escape(text)}</a>'

class PrettyFormatter:
    def list_to_str(self, lst) -> str:
        return str(lst)


class CommaSeparatedListFormatter(PrettyFormatter):
    def list_to_str(self, lst) -> str:
        return ', '.join([str(item) for item in lst])


class PrettyList(UserList):
    def __init__(self, init_list=None, formatter: PrettyFormatter = None):
        super().__init__(init_list)
        self.formatter = formatter

    def __str__(self):
        if self.formatter:
            return self.formatter.list_to_str(self)
        return super().__str__()


def convert_bool(bool_param: bool) -> str:
    return "true" if bool_param else "false"

def safe_int_conversion(value):
    try:
        return int(value)
    except (ValueError, TypeError):
        return value

def is_valid_uuid(uuid_to_test, version=4):
    try:
        uuid_obj = UUID(uuid_to_test, version=version)
    except ValueError:
        return False
    return str(uuid_obj) == uuid_to_test


# DEPRECATED: backward compatibility with mod-py-run-autovalidation
class Colors:
    @classmethod
    def disable(cls):
        from sdsautoval.colors import Colors as NewColors
        NewColors.disable()
